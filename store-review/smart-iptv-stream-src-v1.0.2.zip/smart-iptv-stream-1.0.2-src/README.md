# Smart IPTV Stream — webOS (LG) & Tizen (Samsung)

Android TV (Flutter) uygulamasının **tek kod tabanlı** web (React + TypeScript) yeniden inşası.
Aynı kod hem **LG webOS** hem **Samsung Tizen** TV'lere paketlenir; arayüz, focus/D-pad
navigasyonu ve Xtream/M3U/EPG mantığı kaynak uygulamayla birebir eşleşir.

## Komutlar

```bash
npm install          # bağımlılıklar
npm run dev          # tarayıcıda geliştirme (http://localhost:5173) — 1280x720 sahne
npm run build        # üretim derlemesi -> dist/
npm run package      # dist'i build/webos ve build/tizen klasörlerine hazırlar
```

### webOS (.ipk)
```bash
npm run package
ares-package build/webos -o build           # .ipk üretir
ares-install build/<paket>.ipk -d <cihaz>   # TV'ye kur
ares-launch com.discoverapp.iptvplayer -d <cihaz>
```

### Tizen (.wgt)
```bash
npm run package
tizen package -t wgt -- build/tizen          # Tizen Studio CLI ile .wgt üretir
tizen install -n build/<paket>.wgt -t <cihaz>
```

## Mimari

| Katman | Konum | Açıklama |
|--------|-------|----------|
| Platform tespiti | `src/platform/device.ts` | webOS / Tizen / browser |
| Video player | `src/platform/player/` | webOS+browser → HTML5 `<video>` + hls.js · Tizen → AVPlay |
| Depolama | `src/platform/storage.ts` | localStorage (her iki platformda kalıcı) |
| Focus/D-pad | `src/navigation/` | Geometri tabanlı spatial navigasyon (harici bağımlılık yok) |
| Veri | `src/data/` | Xtream Codes API client, M3U parser, XMLTV EPG parser |
| Durum | `src/store/` | zustand (oturum, katalog, ayarlar, favoriler, devam-izleme) |
| i18n | `src/i18n/` | Kaynaktaki 48 dil (`.arb` → JSON), tembel yüklenir |
| Ekranlar | `src/screens/` | splash, login, userlist, home, livetv, movies, series, detay, player, settings, catchup, multiscreen, installepg, speedtest, about, account, paywall |

## Tasarım

Tüm ölçüler kaynaktaki Flutter `_Scale` referansı (1280×720) ile birebir; `Stage` bileşeni
sahneyi TV çözünürlüğüne (1280×720 / 1920×1080) ölçekler. Renkler ve degradeler
`src/styles/theme.ts` içinde kaynaktan port edildi.

## Uzaktan kumanda tuşları

Ok tuşları + Enter (seç) + Back (geri) her iki platformda da çalışır. Medya tuşları
(play/pause/stop/ileri/geri) player ekranında haritalanmıştır
(`src/navigation/keys.ts`).

## Uygulama kimliği
- webOS: `com.discoverapp.iptvplayer`
- Ad: **Smart IPTV Stream**
