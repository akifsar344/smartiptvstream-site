// One-shot webOS deploy loop: build -> package -> .ipk -> install -> launch.
//
//   node scripts/deploy-webos.mjs [deviceName]
//
// deviceName defaults to the device marked default in `ares-setup-device`.
import { execSync } from "node:child_process";
import { readdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");
const APP_ID = "com.discoverapp.iptvplayer";
const device = process.argv[2] || "tv";
const deviceFlag = ` -d ${device}`;

function run(cmd) {
  console.log(`\n$ ${cmd}`);
  execSync(cmd, { stdio: "inherit", cwd: root });
}

run("npm run build");
run("node scripts/prepare-packages.mjs");
run("ares-package build/webos -o build");

const ipk = readdirSync(resolve(root, "build")).find((f) => f.endsWith(".ipk"));
if (!ipk) {
  console.error("No .ipk produced.");
  process.exit(1);
}

run(`ares-install "build/${ipk}"${deviceFlag}`);
run(`ares-launch ${APP_ID}${deviceFlag}`);
console.log("\n✓ Deployed & launched on TV.");
