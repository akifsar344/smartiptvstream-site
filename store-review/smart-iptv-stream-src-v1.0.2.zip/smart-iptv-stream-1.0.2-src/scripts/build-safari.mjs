// Keeps the Safari (macOS + iOS) Xcode project in sync with the Chromium package.
//
//   npm run build:safari
//     1. `npm run build:ext` → build-ext/chrome (shared MV3 package)
//     2. this script:
//        - creates build-safari/ with Apple's converter on first run
//        - replaces the extension targets' shared Resources/ with build-ext/chrome
//          so Safari never ships a stale bundle
//        - keeps bundle ids, versions, icons, deployment targets and signing in sync
//
// Only generated content is regenerated: the container app's Swift source lives
// in this repo (safari-app/) and is copied over the converter's placeholder, and
// the build number is kept in safari-app/build-number so it survives a project
// regeneration (App Store Connect rejects a build number it has already seen).
import {
  readFileSync,
  writeFileSync,
  existsSync,
  mkdirSync,
  rmSync,
  cpSync,
  readdirSync,
} from "node:fs";
import { dirname, resolve, relative } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const APP_NAME = "Smart IPTV Stream";
const BUNDLE_ID = "com.discoverapp.smartiptvstream";
const TEAM_ID = "AQGW7RTF7B";
// StoreKit 2 and the SwiftUI used by the container app need these; anything
// lower fails to compile, anything higher shuts out users for no reason.
const MACOS_MIN = "12.0";
const IOS_MIN = "15.0";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");
const chromeDir = resolve(root, "build-ext", "chrome");
const safariRoot = resolve(root, "build-safari");
const projectDir = resolve(safariRoot, APP_NAME);
const pbxproj = resolve(projectDir, `${APP_NAME}.xcodeproj`, "project.pbxproj");
const resourcesDir = resolve(projectDir, "Shared (Extension)", "Resources");
const appDir = resolve(projectDir, "Shared (App)");
const buildNumberFile = resolve(root, "safari-app", "build-number");

if (!existsSync(resolve(chromeDir, "manifest.json"))) {
  console.error("build-ext/chrome not found. Run `npm run build:ext` first.");
  process.exit(1);
}

const pkg = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8"));
const version = pkg.version || "1.0.0";

// ── 1) First run: generate the Xcode project ────────────────────────────────
if (!existsSync(pbxproj)) {
  const converter = spawnSync(
    "xcrun",
    [
      "safari-web-extension-converter",
      chromeDir,
      "--project-location",
      safariRoot,
      "--app-name",
      APP_NAME,
      "--bundle-identifier",
      BUNDLE_ID,
      "--swift",
      "--copy-resources",
      "--no-open",
      "--no-prompt",
      "--force",
    ],
    { stdio: "inherit" }
  );
  if (converter.status !== 0) {
    console.error("safari-web-extension-converter failed (needs macOS + Xcode).");
    process.exit(1);
  }
}

// ── 2) Mirror the Chromium package into the extension targets ───────────────
rmSync(resourcesDir, { recursive: true, force: true });
mkdirSync(resourcesDir, { recursive: true });
cpSync(chromeDir, resourcesDir, { recursive: true });

// assets/ and icons/ are folder references, so hashed filenames inside them
// need no project edit. Fixed-name entries do, so flag anything unexpected.
let project = readFileSync(pbxproj, "utf8");
const unreferenced = readdirSync(resourcesDir).filter(
  (name) => !project.includes(`Resources/${name}`)
);
if (unreferenced.length) {
  console.warn(
    `⚠ not referenced by the Xcode project: ${unreferenced.join(", ")}\n` +
      `  Drag them into the "Shared (Extension)" group once.`
  );
}

// ── 3) Container app source (shared by both platforms) ──────────────────────
// The converter ships a web-view placeholder; ours adds the account sign-in and
// the StoreKit purchase Apple requires (guideline 3.1.1). Same file name and
// target membership, so no project edit is needed.
const appSource = resolve(root, "safari-app", "ViewController.swift");
if (existsSync(appSource)) {
  cpSync(appSource, resolve(appDir, "ViewController.swift"));
} else {
  console.warn("⚠ safari-app/ViewController.swift not found - keeping the converter's placeholder.");
}

// Rewrites a PNG without its alpha channel, compositing on black. sips can't do
// it in one pass, so go through an intermediate JPEG at full quality.
function flattenAlpha(file) {
  const tmp = `${file}.jpg`;
  const toJpeg = spawnSync(
    "sips",
    ["-s", "format", "jpeg", "-s", "formatOptions", "best", file, "--out", tmp],
    { stdio: "ignore" }
  );
  if (toJpeg.status !== 0) {
    console.warn(`⚠ could not flatten ${file}; the App Store may reject it (error 90717).`);
    return;
  }
  spawnSync("sips", ["-s", "format", "png", tmp, "--out", file], { stdio: "ignore" });
  rmSync(tmp, { force: true });
}

// ── 4) App icons from the 1024px master ─────────────────────────────────────
// The converter upscales the extension's 128px icon, which is too soft for the
// App Store, so redraw every size from androidlogo.png.
const logo = resolve(root, "androidlogo.png");
const iconSet = resolve(appDir, "Assets.xcassets", "AppIcon.appiconset");
if (existsSync(logo) && existsSync(iconSet)) {
  const sizes = [
    [16, "mac-icon-16@1x.png"],
    [32, "mac-icon-16@2x.png"],
    [32, "mac-icon-32@1x.png"],
    [64, "mac-icon-32@2x.png"],
    [128, "mac-icon-128@1x.png"],
    [256, "mac-icon-128@2x.png"],
    [256, "mac-icon-256@1x.png"],
    [512, "mac-icon-256@2x.png"],
    [512, "mac-icon-512@1x.png"],
    [1024, "mac-icon-512@2x.png"],
    // iOS/iPadOS use the single universal slot.
    [1024, "universal-icon-1024@1x.png"],
    // Shown inside the container app's window.
    [512, resolve(appDir, "Resources", "Icon.png")],
  ];
  for (const [px, target] of sizes) {
    const out = target.startsWith("/") ? target : resolve(iconSet, target);
    spawnSync("sips", ["-z", String(px), String(px), logo, "--out", out], { stdio: "ignore" });
  }
  // The App Store rejects an iOS app icon that carries an alpha channel (upload
  // error 90717); macOS icons keep theirs. The logo is opaque anyway, so
  // dropping the channel changes nothing visually.
  flattenAlpha(resolve(iconSet, "universal-icon-1024@1x.png"));
} else {
  console.warn("⚠ androidlogo.png not found - keeping the converter's upscaled icons.");
}

// ── 5) Keep identifiers, versions and platforms aligned ─────────────────────
const buildNumber = existsSync(buildNumberFile)
  ? Number(readFileSync(buildNumberFile, "utf8").trim()) + 1
  : 1;
writeFileSync(buildNumberFile, `${buildNumber}\n`);

project = project
  .replace(/PRODUCT_BUNDLE_IDENTIFIER = "?com\.discoverapp\.Smart-IPTV-Stream"?;/g, `PRODUCT_BUNDLE_IDENTIFIER = ${BUNDLE_ID};`)
  .replace(/MARKETING_VERSION = [^;]+;/g, `MARKETING_VERSION = ${version};`)
  .replace(/CURRENT_PROJECT_VERSION = \d+;/g, `CURRENT_PROJECT_VERSION = ${buildNumber};`)
  // Xcode defaults new projects to the SDK's own OS, which would ship an app
  // only the newest macOS can install.
  .replace(/MACOSX_DEPLOYMENT_TARGET = [^;]+;/g, `MACOSX_DEPLOYMENT_TARGET = ${MACOS_MIN};`)
  .replace(/IPHONEOS_DEPLOYMENT_TARGET = [^;]+;/g, `IPHONEOS_DEPLOYMENT_TARGET = ${IOS_MIN};`);

// The Mac App Store refuses archives without a category (upload error 90242)
// and the converter doesn't set one. NSMainStoryboardFile only exists in the
// macOS app target, so it anchors the insertion to the right configurations.
if (!project.includes("INFOPLIST_KEY_LSApplicationCategoryType")) {
  project = project.replace(
    /(\n(\t*)INFOPLIST_KEY_NSMainStoryboardFile = Main;)/g,
    `$1\n$2INFOPLIST_KEY_LSApplicationCategoryType = "public.app-category.entertainment";`
  );
}

// The converter marks the appex ad-hoc ("-"), which Xcode rejects once the app
// itself signs with a real certificate ("Embedded binary is not signed with the
// same certificate as the parent app"). Drop it so both inherit automatic signing.
project = project.replace(/\n\t*"CODE_SIGN_IDENTITY\[sdk=macosx\*\]" = "-";/g, "");

// Pin the signing team so Archive works without touching Xcode's UI.
if (!project.includes("DEVELOPMENT_TEAM")) {
  project = project.replace(
    /(\n(\t*)CODE_SIGN_STYLE = Automatic;)/g,
    `$1\n$2DEVELOPMENT_TEAM = ${TEAM_ID};`
  );
}
writeFileSync(pbxproj, project);

console.log(`✓ Safari project synced (v${version}, build ${buildNumber})`);
console.log(`  • Xcode project: ${relative(root, resolve(projectDir, `${APP_NAME}.xcodeproj`))}`);
console.log(`  • Schemes:     "${APP_NAME} (macOS)" and "${APP_NAME} (iOS)"`);
console.log(`  • Local test:  open it, Run, then enable the extension in Safari`);
console.log(`  • App Store:   Product → Archive → Distribute App (once per platform)`);
