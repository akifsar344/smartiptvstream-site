// Post-processes the browser (WEB_BUILD=1) Vite output into the exact shape the
// smartiptvstream.com Node server expects, and generates the SEO marketing site.
//
//   npm run build:web
//     1. `WEB_BUILD=1 vite build`  → dist/index.html (SPA shell, absolute /assets)
//     2. this script:
//        - moves the SPA shell to dist/app.html (served at /app, noindex)
//        - generates localised, SEO-optimised landing pages at dist/index.html
//          and dist/<lang>/index.html (served at / and /<lang>)
//        - writes robots.txt, sitemap.xml and site.webmanifest
//
// It NEVER touches the webOS/Tizen packaging pipeline (that uses `npm run build`
// with the default relative base and keeps index.html as the app entry).
import { readFileSync, writeFileSync, existsSync, mkdirSync, renameSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const dist = resolve(__dirname, "..", "dist");

if (!existsSync(resolve(dist, "index.html"))) {
  console.error("dist/index.html not found. Run `WEB_BUILD=1 vite build` first.");
  process.exit(1);
}

const SITE = "https://smartiptvstream.com";
const APP = "/app"; // where the SPA is served
const PRICE = "$5.99";
const OG_IMAGE = `${SITE}/assets/appicon.png`;
const LOGO = "/assets/brand-logo.png";
const FAVICON = "/assets/androidlogo.png";

// ── Languages we publish (each gets its own indexable, TRANSLATED URL) ──────
// Only languages with genuine, hand-written copy are published, so we never
// serve English text under a localised URL (which would be duplicate content
// in Google's eyes). Add a new entry here AND its S[code] copy below to expand,
// then mirror the code in server/src/index.js → LANDING_LANGS.
const LANGS = [
  { code: "en", hreflang: "en", locale: "en_US", dir: "ltr" },
  { code: "tr", hreflang: "tr", locale: "tr_TR", dir: "ltr" },
  { code: "es", hreflang: "es", locale: "es_ES", dir: "ltr" },
  { code: "de", hreflang: "de", locale: "de_DE", dir: "ltr" },
  { code: "fr", hreflang: "fr", locale: "fr_FR", dir: "ltr" },
  { code: "pt", hreflang: "pt", locale: "pt_BR", dir: "ltr" },
  { code: "it", hreflang: "it", locale: "it_IT", dir: "ltr" },
  { code: "ru", hreflang: "ru", locale: "ru_RU", dir: "ltr" },
  { code: "ar", hreflang: "ar", locale: "ar_AR", dir: "rtl" },
];

const urlFor = (code) => (code === "en" ? `${SITE}/` : `${SITE}/${code}/`);
const outFor = (code) => (code === "en" ? resolve(dist, "index.html") : resolve(dist, code, "index.html"));

// ── Copy (professional marketing content per language) ──────────────────────
// Keys: brand, tagline, metaTitle, metaDesc, nav*, hero*, features[], how*,
// steps[], price*, faq[], cta*, footer*.
const S = {
  en: {
    metaTitle: "Smart IPTV Stream — Watch IPTV on any TV, phone & browser",
    metaDesc:
      "Smart IPTV Stream is a fast, beautiful IPTV player for LG webOS, Samsung TV, Android TV, phones and the web. Load Xtream or M3U playlists, get EPG, movies, series, catch-up, multi-screen and subtitles. One-time payment, no subscription.",
    keywords:
      "IPTV player, Smart IPTV, Xtream player, M3U player, LG webOS IPTV, Samsung TV IPTV, watch IPTV online, IPTV web player, EPG, VOD, series",
    skip: "Skip to content",
    navFeatures: "Features",
    navHow: "How it works",
    navPricing: "Pricing",
    navFaq: "FAQ",
    navOpen: "Open App",
    heroBadge: "Works on every screen",
    heroTitle: "Your IPTV, beautifully organised — on any TV, phone or browser.",
    heroSub:
      "Load your Xtream Codes or M3U playlist and enjoy live TV, movies, series, EPG, catch-up, multi-screen and subtitles in a fast, modern player. Start free, upgrade once — no subscription.",
    heroCta: "Start watching free",
    heroCta2: "Sign in",
    heroNote: "1-day free trial · One-time Pro upgrade · Cancel anytime (there's nothing to cancel)",
    featuresTitle: "Everything you need to watch, in one place",
    features: [
      { t: "Live TV with EPG", d: "Browse channels with a full electronic programme guide, favourites and instant zapping." },
      { t: "Movies & Series (VOD)", d: "Rich catalogues with posters, seasons and episodes, resume-where-you-left-off and continue watching." },
      { t: "Xtream & M3U", d: "Connect any Xtream Codes login or M3U/M3U8 playlist URL in seconds. Multiple profiles supported." },
      { t: "Subtitles & audio tracks", d: "Built-in OpenSubtitles search plus embedded subtitle and multi-audio track selection." },
      { t: "Catch-up & Multi-screen", d: "Watch past programmes and up to four channels at once on a single screen." },
      { t: "Private & secure", d: "Your playlists sync to your own account. HTTP streams are proxied to HTTPS so they play safely in any browser." },
    ],
    howTitle: "Up and running in under a minute",
    steps: [
      { t: "Create your free account", d: "Sign up with an email — no credit card needed for the trial." },
      { t: "Add your playlist", d: "Paste your Xtream login or M3U URL. Your channels, movies and series appear instantly." },
      { t: "Press play", d: "Watch on your TV, phone or browser. Upgrade to Pro once to unlock everything for life." },
    ],
    priceTitle: "Simple, honest pricing",
    priceSub: "One payment. Lifetime Pro. No subscriptions, no renewals, ever.",
    priceName: "Lifetime Pro",
    pricePer: "one-time",
    priceFeatures: [
      "Unlimited playlists & profiles",
      "Live TV, VOD, EPG & catch-up",
      "Subtitles, multi-audio & multi-screen",
      "Works on TV, phone & browser",
      "Free updates forever",
    ],
    priceCta: "Get Lifetime Pro",
    priceTrial: "…or start with a free 1-day trial",
    faqTitle: "Frequently asked questions",
    faq: [
      { q: "Does Smart IPTV Stream provide channels or content?", a: "No. Smart IPTV Stream is a player only. You bring your own Xtream Codes login or M3U playlist from your provider; we don't sell, host or supply any channels or media." },
      { q: "Which devices are supported?", a: "LG (webOS) and Samsung (Tizen) smart TVs, Android TV, and any modern web browser on phones, tablets and computers at this site." },
      { q: "Is it really a one-time payment?", a: "Yes. Pay once for Lifetime Pro — there are no subscriptions or recurring fees. You also get a free 1-day trial to try everything first." },
      { q: "Can I use HTTP-only playlists in the browser?", a: "Yes. Insecure HTTP streams are automatically proxied over HTTPS so they play safely in the browser without mixed-content errors." },
      { q: "Do my favourites and progress sync?", a: "Yes. Your playlists, favourites, continue-watching and settings are tied to your account and follow you across devices." },
    ],
    ctaTitle: "Ready to watch?",
    ctaSub: "Create a free account and start streaming in under a minute.",
    ctaBtn: "Open the app",
    footerTagline: "A fast, modern IPTV player for every screen.",
    footerDisclaimer:
      "Smart IPTV Stream is a media player. It does not provide, sell or host any channels, streams or content. Users must supply their own legal IPTV playlist.",
    footerProduct: "Product",
    footerLegal: "Legal",
    footerLang: "Language",
    linkOpenApp: "Open App",
    linkSignIn: "Sign in",
    rights: "All rights reserved.",
  },
  tr: {
    metaTitle: "Smart IPTV Stream — Her TV, telefon ve tarayıcıda IPTV izleyin",
    metaDesc:
      "Smart IPTV Stream; LG webOS, Samsung TV, Android TV, telefon ve web için hızlı ve şık bir IPTV oynatıcıdır. Xtream veya M3U listenizi yükleyin; EPG, filmler, diziler, geri sarma, çoklu ekran ve altyazı. Tek seferlik ödeme, abonelik yok.",
    keywords:
      "IPTV oynatıcı, Smart IPTV, Xtream oynatıcı, M3U oynatıcı, LG webOS IPTV, Samsung TV IPTV, online IPTV izle, web IPTV, EPG, film, dizi",
    skip: "İçeriğe geç",
    navFeatures: "Özellikler",
    navHow: "Nasıl çalışır",
    navPricing: "Fiyatlandırma",
    navFaq: "SSS",
    navOpen: "Uygulamayı Aç",
    heroBadge: "Her ekranda çalışır",
    heroTitle: "IPTV'niz, şık ve düzenli — her TV, telefon veya tarayıcıda.",
    heroSub:
      "Xtream Codes veya M3U listenizi yükleyin; canlı TV, filmler, diziler, EPG, geri sarma, çoklu ekran ve altyazının keyfini hızlı, modern bir oynatıcıda çıkarın. Ücretsiz başlayın, bir kez yükseltin — abonelik yok.",
    heroCta: "Ücretsiz izlemeye başla",
    heroCta2: "Giriş yap",
    heroNote: "1 günlük ücretsiz deneme · Tek seferlik Pro yükseltmesi · İstediğiniz zaman iptal (iptal edilecek bir şey yok)",
    featuresTitle: "İzlemek için ihtiyacınız olan her şey tek yerde",
    features: [
      { t: "EPG ile Canlı TV", d: "Tam elektronik program rehberi, favoriler ve anında kanal geçişiyle kanallara göz atın." },
      { t: "Filmler & Diziler (VOD)", d: "Afişler, sezon ve bölümlerle zengin katalog; kaldığınız yerden devam ve izlemeye devam et." },
      { t: "Xtream & M3U", d: "Saniyeler içinde herhangi bir Xtream Codes girişi veya M3U/M3U8 liste bağlantısı ekleyin. Çoklu profil desteği." },
      { t: "Altyazı & ses kanalları", d: "Dahili OpenSubtitles araması, gömülü altyazı ve çoklu ses kanalı seçimi." },
      { t: "Geri sarma & Çoklu ekran", d: "Geçmiş yayınları izleyin ve tek ekranda aynı anda dört kanala kadar açın." },
      { t: "Gizli & güvenli", d: "Listeleriniz kendi hesabınıza senkronlanır. HTTP yayınları HTTPS'e proxy'lenir, her tarayıcıda güvenle oynar." },
    ],
    howTitle: "Bir dakikadan kısa sürede hazır",
    steps: [
      { t: "Ücretsiz hesabınızı oluşturun", d: "E-posta ile kaydolun — deneme için kredi kartı gerekmez." },
      { t: "Listenizi ekleyin", d: "Xtream girişinizi veya M3U bağlantınızı yapıştırın. Kanal, film ve dizileriniz anında görünür." },
      { t: "Oynat'a basın", d: "TV, telefon veya tarayıcıda izleyin. Her şeyi ömür boyu açmak için bir kez Pro'ya yükseltin." },
    ],
    priceTitle: "Basit ve dürüst fiyatlandırma",
    priceSub: "Tek ödeme. Ömür boyu Pro. Abonelik veya yenileme yok, asla.",
    priceName: "Ömür Boyu Pro",
    pricePer: "tek seferlik",
    priceFeatures: [
      "Sınırsız liste & profil",
      "Canlı TV, VOD, EPG & geri sarma",
      "Altyazı, çoklu ses & çoklu ekran",
      "TV, telefon & tarayıcıda çalışır",
      "Sonsuza dek ücretsiz güncelleme",
    ],
    priceCta: "Ömür Boyu Pro Al",
    priceTrial: "…ya da ücretsiz 1 günlük deneme ile başlayın",
    faqTitle: "Sıkça sorulan sorular",
    faq: [
      { q: "Smart IPTV Stream kanal veya içerik sağlıyor mu?", a: "Hayır. Smart IPTV Stream yalnızca bir oynatıcıdır. Kendi sağlayıcınızdan aldığınız Xtream Codes girişini veya M3U listesini siz getirirsiniz; biz hiçbir kanal veya içerik satmaz, barındırmaz veya sağlamayız." },
      { q: "Hangi cihazlar destekleniyor?", a: "LG (webOS) ve Samsung (Tizen) akıllı TV'ler, Android TV ve bu sitede telefon, tablet ve bilgisayarlardaki tüm modern web tarayıcıları." },
      { q: "Gerçekten tek seferlik ödeme mi?", a: "Evet. Ömür Boyu Pro için bir kez ödeyin — abonelik veya tekrarlayan ücret yoktur. Ayrıca her şeyi önce denemeniz için 1 günlük ücretsiz deneme sunulur." },
      { q: "Tarayıcıda yalnızca HTTP olan listeleri kullanabilir miyim?", a: "Evet. Güvenli olmayan HTTP yayınları otomatik olarak HTTPS üzerinden proxy'lenir; tarayıcıda karışık içerik hatası olmadan güvenle oynar." },
      { q: "Favorilerim ve ilerlemem senkronlanıyor mu?", a: "Evet. Listeleriniz, favorileriniz, izlemeye devam ve ayarlarınız hesabınıza bağlıdır ve cihazlar arasında sizi takip eder." },
    ],
    ctaTitle: "İzlemeye hazır mısınız?",
    ctaSub: "Ücretsiz hesap oluşturun ve bir dakikadan kısa sürede yayına başlayın.",
    ctaBtn: "Uygulamayı aç",
    footerTagline: "Her ekran için hızlı, modern bir IPTV oynatıcı.",
    footerDisclaimer:
      "Smart IPTV Stream bir medya oynatıcıdır. Hiçbir kanal, yayın veya içerik sağlamaz, satmaz veya barındırmaz. Kullanıcılar kendi yasal IPTV listelerini kendileri sağlamalıdır.",
    footerProduct: "Ürün",
    footerLegal: "Yasal",
    footerLang: "Dil",
    linkOpenApp: "Uygulamayı Aç",
    linkSignIn: "Giriş yap",
    rights: "Tüm hakları saklıdır.",
  },
  es: {
    metaTitle: "Smart IPTV Stream — Ve IPTV en cualquier TV, móvil y navegador",
    metaDesc:
      "Smart IPTV Stream es un reproductor IPTV rápido y elegante para LG webOS, Samsung TV, Android TV, móviles y web. Carga listas Xtream o M3U y disfruta de EPG, películas, series, catch-up, multipantalla y subtítulos. Pago único, sin suscripción.",
    keywords:
      "reproductor IPTV, Smart IPTV, reproductor Xtream, reproductor M3U, LG webOS IPTV, Samsung TV IPTV, ver IPTV online, IPTV web, EPG, VOD, series",
    skip: "Ir al contenido",
    navFeatures: "Funciones",
    navHow: "Cómo funciona",
    navPricing: "Precio",
    navFaq: "FAQ",
    navOpen: "Abrir app",
    heroBadge: "Funciona en cualquier pantalla",
    heroTitle: "Tu IPTV, perfectamente organizado — en cualquier TV, móvil o navegador.",
    heroSub:
      "Carga tu lista Xtream Codes o M3U y disfruta de TV en directo, películas, series, EPG, catch-up, multipantalla y subtítulos en un reproductor rápido y moderno. Empieza gratis, mejora una sola vez — sin suscripción.",
    heroCta: "Empieza gratis",
    heroCta2: "Iniciar sesión",
    heroNote: "Prueba gratis de 1 día · Mejora Pro única · Cancela cuando quieras (no hay nada que cancelar)",
    featuresTitle: "Todo lo que necesitas para ver, en un solo lugar",
    features: [
      { t: "TV en directo con EPG", d: "Explora canales con guía electrónica completa, favoritos y cambio instantáneo." },
      { t: "Películas y series (VOD)", d: "Catálogos con carátulas, temporadas y episodios, reanudar y continuar viendo." },
      { t: "Xtream y M3U", d: "Conecta cualquier acceso Xtream Codes o URL de lista M3U/M3U8 en segundos. Varios perfiles." },
      { t: "Subtítulos y audios", d: "Búsqueda integrada en OpenSubtitles y selección de subtítulos y pistas de audio." },
      { t: "Catch-up y multipantalla", d: "Mira programas pasados y hasta cuatro canales a la vez en una sola pantalla." },
      { t: "Privado y seguro", d: "Tus listas se sincronizan con tu cuenta. Los flujos HTTP se enrutan por HTTPS para reproducirse sin problemas." },
    ],
    howTitle: "Listo en menos de un minuto",
    steps: [
      { t: "Crea tu cuenta gratis", d: "Regístrate con un email — no necesitas tarjeta para la prueba." },
      { t: "Añade tu lista", d: "Pega tu acceso Xtream o URL M3U. Tus canales, películas y series aparecen al instante." },
      { t: "Dale a reproducir", d: "Mira en TV, móvil o navegador. Mejora a Pro una vez para desbloquear todo de por vida." },
    ],
    priceTitle: "Precio simple y honesto",
    priceSub: "Un solo pago. Pro de por vida. Sin suscripciones ni renovaciones, nunca.",
    priceName: "Pro de por vida",
    pricePer: "pago único",
    priceFeatures: [
      "Listas y perfiles ilimitados",
      "TV en directo, VOD, EPG y catch-up",
      "Subtítulos, multi-audio y multipantalla",
      "Funciona en TV, móvil y navegador",
      "Actualizaciones gratis para siempre",
    ],
    priceCta: "Obtener Pro de por vida",
    priceTrial: "…o empieza con una prueba gratis de 1 día",
    faqTitle: "Preguntas frecuentes",
    faq: [
      { q: "¿Smart IPTV Stream ofrece canales o contenido?", a: "No. Smart IPTV Stream es solo un reproductor. Tú aportas tu propio acceso Xtream Codes o lista M3U de tu proveedor; no vendemos, alojamos ni suministramos ningún canal ni contenido." },
      { q: "¿Qué dispositivos son compatibles?", a: "TVs LG (webOS) y Samsung (Tizen), Android TV y cualquier navegador moderno en móviles, tablets y ordenadores en este sitio." },
      { q: "¿Es realmente un pago único?", a: "Sí. Paga una vez por Pro de por vida — sin suscripciones ni cuotas recurrentes. Además tienes una prueba gratis de 1 día." },
      { q: "¿Puedo usar listas solo HTTP en el navegador?", a: "Sí. Los flujos HTTP no seguros se enrutan automáticamente por HTTPS para reproducirse sin errores de contenido mixto." },
      { q: "¿Se sincronizan mis favoritos y progreso?", a: "Sí. Tus listas, favoritos, continuar viendo y ajustes están ligados a tu cuenta y te siguen entre dispositivos." },
    ],
    ctaTitle: "¿Listo para ver?",
    ctaSub: "Crea una cuenta gratis y empieza a ver en menos de un minuto.",
    ctaBtn: "Abrir la app",
    footerTagline: "Un reproductor IPTV rápido y moderno para cada pantalla.",
    footerDisclaimer:
      "Smart IPTV Stream es un reproductor multimedia. No proporciona, vende ni aloja canales, flujos ni contenido. Los usuarios deben aportar su propia lista IPTV legal.",
    footerProduct: "Producto",
    footerLegal: "Legal",
    footerLang: "Idioma",
    linkOpenApp: "Abrir app",
    linkSignIn: "Iniciar sesión",
    rights: "Todos los derechos reservados.",
  },
  de: {
    metaTitle: "Smart IPTV Stream — IPTV auf jedem TV, Handy & Browser ansehen",
    metaDesc:
      "Smart IPTV Stream ist ein schneller, eleganter IPTV-Player für LG webOS, Samsung TV, Android TV, Handys und das Web. Lade Xtream- oder M3U-Playlists und genieße EPG, Filme, Serien, Catch-up, Multiscreen und Untertitel. Einmalzahlung, kein Abo.",
    keywords:
      "IPTV Player, Smart IPTV, Xtream Player, M3U Player, LG webOS IPTV, Samsung TV IPTV, IPTV online ansehen, IPTV Web Player, EPG, VOD, Serien",
    skip: "Zum Inhalt springen",
    navFeatures: "Funktionen",
    navHow: "So funktioniert's",
    navPricing: "Preis",
    navFaq: "FAQ",
    navOpen: "App öffnen",
    heroBadge: "Läuft auf jedem Bildschirm",
    heroTitle: "Dein IPTV, wunderbar organisiert — auf jedem TV, Handy oder Browser.",
    heroSub:
      "Lade deine Xtream-Codes- oder M3U-Playlist und genieße Live-TV, Filme, Serien, EPG, Catch-up, Multiscreen und Untertitel in einem schnellen, modernen Player. Kostenlos starten, einmal upgraden — kein Abo.",
    heroCta: "Kostenlos starten",
    heroCta2: "Anmelden",
    heroNote: "1 Tag gratis testen · Einmaliges Pro-Upgrade · Jederzeit kündbar (es gibt nichts zu kündigen)",
    featuresTitle: "Alles zum Ansehen an einem Ort",
    features: [
      { t: "Live-TV mit EPG", d: "Durchsuche Sender mit vollständigem Programmführer, Favoriten und sofortigem Umschalten." },
      { t: "Filme & Serien (VOD)", d: "Umfangreiche Kataloge mit Postern, Staffeln und Episoden, Fortsetzen und Weiterschauen." },
      { t: "Xtream & M3U", d: "Verbinde in Sekunden jeden Xtream-Codes-Login oder jede M3U/M3U8-Playlist-URL. Mehrere Profile." },
      { t: "Untertitel & Tonspuren", d: "Integrierte OpenSubtitles-Suche sowie Auswahl von Untertiteln und mehreren Tonspuren." },
      { t: "Catch-up & Multiscreen", d: "Sieh vergangene Sendungen und bis zu vier Sender gleichzeitig auf einem Bildschirm." },
      { t: "Privat & sicher", d: "Deine Playlists werden mit deinem Konto synchronisiert. HTTP-Streams werden über HTTPS geleitet." },
    ],
    howTitle: "In unter einer Minute startklar",
    steps: [
      { t: "Kostenloses Konto erstellen", d: "Mit E-Mail registrieren — keine Kreditkarte für die Testphase nötig." },
      { t: "Playlist hinzufügen", d: "Füge deinen Xtream-Login oder deine M3U-URL ein. Sender, Filme und Serien erscheinen sofort." },
      { t: "Auf Wiedergabe drücken", d: "Schau auf TV, Handy oder Browser. Einmal auf Pro upgraden und alles lebenslang freischalten." },
    ],
    priceTitle: "Einfacher, fairer Preis",
    priceSub: "Eine Zahlung. Lebenslang Pro. Keine Abos, keine Verlängerungen, niemals.",
    priceName: "Lebenslang Pro",
    pricePer: "einmalig",
    priceFeatures: [
      "Unbegrenzte Playlists & Profile",
      "Live-TV, VOD, EPG & Catch-up",
      "Untertitel, Multi-Audio & Multiscreen",
      "Läuft auf TV, Handy & Browser",
      "Kostenlose Updates für immer",
    ],
    priceCta: "Lebenslang Pro holen",
    priceTrial: "…oder starte mit einer kostenlosen 1-Tages-Testphase",
    faqTitle: "Häufige Fragen",
    faq: [
      { q: "Bietet Smart IPTV Stream Sender oder Inhalte an?", a: "Nein. Smart IPTV Stream ist nur ein Player. Du bringst deinen eigenen Xtream-Codes-Login oder deine M3U-Playlist deines Anbieters mit; wir verkaufen, hosten oder liefern keine Sender oder Inhalte." },
      { q: "Welche Geräte werden unterstützt?", a: "LG (webOS) und Samsung (Tizen) Smart-TVs, Android TV und jeder moderne Browser auf Handys, Tablets und Computern auf dieser Seite." },
      { q: "Ist es wirklich eine Einmalzahlung?", a: "Ja. Zahle einmal für Lebenslang Pro — keine Abos oder wiederkehrenden Gebühren. Du erhältst außerdem eine kostenlose 1-Tages-Testphase." },
      { q: "Kann ich reine HTTP-Playlists im Browser nutzen?", a: "Ja. Unsichere HTTP-Streams werden automatisch über HTTPS geleitet, sodass sie ohne Mixed-Content-Fehler abspielen." },
      { q: "Werden Favoriten und Fortschritt synchronisiert?", a: "Ja. Deine Playlists, Favoriten, Weiterschauen und Einstellungen sind an dein Konto gebunden und folgen dir über Geräte hinweg." },
    ],
    ctaTitle: "Bereit zum Ansehen?",
    ctaSub: "Erstelle ein kostenloses Konto und streame in unter einer Minute.",
    ctaBtn: "App öffnen",
    footerTagline: "Ein schneller, moderner IPTV-Player für jeden Bildschirm.",
    footerDisclaimer:
      "Smart IPTV Stream ist ein Medienplayer. Er stellt keine Sender, Streams oder Inhalte bereit, verkauft oder hostet sie. Nutzer müssen ihre eigene legale IPTV-Playlist bereitstellen.",
    footerProduct: "Produkt",
    footerLegal: "Rechtliches",
    footerLang: "Sprache",
    linkOpenApp: "App öffnen",
    linkSignIn: "Anmelden",
    rights: "Alle Rechte vorbehalten.",
  },
  fr: {
    metaTitle: "Smart IPTV Stream — Regardez l'IPTV sur TV, mobile et navigateur",
    metaDesc:
      "Smart IPTV Stream est un lecteur IPTV rapide et élégant pour LG webOS, Samsung TV, Android TV, mobiles et le web. Chargez des listes Xtream ou M3U et profitez de l'EPG, films, séries, catch-up, multi-écran et sous-titres. Paiement unique, sans abonnement.",
    keywords:
      "lecteur IPTV, Smart IPTV, lecteur Xtream, lecteur M3U, LG webOS IPTV, Samsung TV IPTV, regarder IPTV en ligne, IPTV web, EPG, VOD, séries",
    skip: "Aller au contenu",
    navFeatures: "Fonctions",
    navHow: "Comment ça marche",
    navPricing: "Tarif",
    navFaq: "FAQ",
    navOpen: "Ouvrir l'app",
    heroBadge: "Fonctionne sur tous les écrans",
    heroTitle: "Votre IPTV, parfaitement organisé — sur TV, mobile ou navigateur.",
    heroSub:
      "Chargez votre liste Xtream Codes ou M3U et profitez de la TV en direct, films, séries, EPG, catch-up, multi-écran et sous-titres dans un lecteur rapide et moderne. Commencez gratuitement, améliorez une seule fois — sans abonnement.",
    heroCta: "Commencer gratuitement",
    heroCta2: "Se connecter",
    heroNote: "Essai gratuit d'1 jour · Passage Pro unique · Annulez quand vous voulez (rien à annuler)",
    featuresTitle: "Tout ce qu'il faut pour regarder, au même endroit",
    features: [
      { t: "TV en direct avec EPG", d: "Parcourez les chaînes avec un guide électronique complet, favoris et zapping instantané." },
      { t: "Films & séries (VOD)", d: "Catalogues riches avec affiches, saisons et épisodes, reprise et continuer à regarder." },
      { t: "Xtream & M3U", d: "Connectez tout identifiant Xtream Codes ou URL de liste M3U/M3U8 en quelques secondes. Plusieurs profils." },
      { t: "Sous-titres & pistes audio", d: "Recherche OpenSubtitles intégrée et sélection de sous-titres et de pistes audio multiples." },
      { t: "Catch-up & multi-écran", d: "Regardez les programmes passés et jusqu'à quatre chaînes à la fois sur un seul écran." },
      { t: "Privé & sécurisé", d: "Vos listes se synchronisent avec votre compte. Les flux HTTP sont relayés en HTTPS pour une lecture sûre." },
    ],
    howTitle: "Prêt en moins d'une minute",
    steps: [
      { t: "Créez votre compte gratuit", d: "Inscrivez-vous avec un e-mail — pas de carte requise pour l'essai." },
      { t: "Ajoutez votre liste", d: "Collez votre identifiant Xtream ou URL M3U. Vos chaînes, films et séries apparaissent aussitôt." },
      { t: "Appuyez sur lecture", d: "Regardez sur TV, mobile ou navigateur. Passez à Pro une fois pour tout débloquer à vie." },
    ],
    priceTitle: "Tarif simple et honnête",
    priceSub: "Un paiement. Pro à vie. Aucun abonnement, aucun renouvellement, jamais.",
    priceName: "Pro à vie",
    pricePer: "unique",
    priceFeatures: [
      "Listes et profils illimités",
      "TV en direct, VOD, EPG et catch-up",
      "Sous-titres, multi-audio et multi-écran",
      "Fonctionne sur TV, mobile et navigateur",
      "Mises à jour gratuites à vie",
    ],
    priceCta: "Obtenir Pro à vie",
    priceTrial: "…ou commencez par un essai gratuit d'1 jour",
    faqTitle: "Questions fréquentes",
    faq: [
      { q: "Smart IPTV Stream fournit-il des chaînes ou du contenu ?", a: "Non. Smart IPTV Stream n'est qu'un lecteur. Vous apportez votre propre identifiant Xtream Codes ou liste M3U de votre fournisseur ; nous ne vendons, n'hébergeons ni ne fournissons aucune chaîne ni contenu." },
      { q: "Quels appareils sont pris en charge ?", a: "Les TV LG (webOS) et Samsung (Tizen), Android TV, et tout navigateur moderne sur mobile, tablette et ordinateur sur ce site." },
      { q: "Est-ce vraiment un paiement unique ?", a: "Oui. Payez une fois pour Pro à vie — sans abonnement ni frais récurrents. Vous bénéficiez aussi d'un essai gratuit d'1 jour." },
      { q: "Puis-je utiliser des listes HTTP seulement dans le navigateur ?", a: "Oui. Les flux HTTP non sécurisés sont automatiquement relayés en HTTPS pour une lecture sans erreur de contenu mixte." },
      { q: "Mes favoris et ma progression sont-ils synchronisés ?", a: "Oui. Vos listes, favoris, reprise de lecture et réglages sont liés à votre compte et vous suivent sur tous vos appareils." },
    ],
    ctaTitle: "Prêt à regarder ?",
    ctaSub: "Créez un compte gratuit et commencez à diffuser en moins d'une minute.",
    ctaBtn: "Ouvrir l'app",
    footerTagline: "Un lecteur IPTV rapide et moderne pour chaque écran.",
    footerDisclaimer:
      "Smart IPTV Stream est un lecteur multimédia. Il ne fournit, ne vend ni n'héberge aucune chaîne, flux ou contenu. Les utilisateurs doivent fournir leur propre liste IPTV légale.",
    footerProduct: "Produit",
    footerLegal: "Légal",
    footerLang: "Langue",
    linkOpenApp: "Ouvrir l'app",
    linkSignIn: "Se connecter",
    rights: "Tous droits réservés.",
  },
  pt: {
    metaTitle: "Smart IPTV Stream — Assista IPTV em qualquer TV, celular e navegador",
    metaDesc:
      "Smart IPTV Stream é um player IPTV rápido e elegante para LG webOS, Samsung TV, Android TV, celulares e web. Carregue listas Xtream ou M3U e aproveite EPG, filmes, séries, catch-up, multitela e legendas. Pagamento único, sem assinatura.",
    keywords:
      "player IPTV, Smart IPTV, player Xtream, player M3U, LG webOS IPTV, Samsung TV IPTV, assistir IPTV online, IPTV web, EPG, VOD, séries",
    skip: "Ir para o conteúdo",
    navFeatures: "Recursos",
    navHow: "Como funciona",
    navPricing: "Preço",
    navFaq: "FAQ",
    navOpen: "Abrir app",
    heroBadge: "Funciona em qualquer tela",
    heroTitle: "Sua IPTV, lindamente organizada — em qualquer TV, celular ou navegador.",
    heroSub:
      "Carregue sua lista Xtream Codes ou M3U e aproveite TV ao vivo, filmes, séries, EPG, catch-up, multitela e legendas em um player rápido e moderno. Comece grátis, faça upgrade uma vez — sem assinatura.",
    heroCta: "Começar grátis",
    heroCta2: "Entrar",
    heroNote: "Teste grátis de 1 dia · Upgrade Pro único · Cancele quando quiser (não há o que cancelar)",
    featuresTitle: "Tudo o que você precisa para assistir, num só lugar",
    features: [
      { t: "TV ao vivo com EPG", d: "Navegue pelos canais com guia eletrônico completo, favoritos e troca instantânea." },
      { t: "Filmes e séries (VOD)", d: "Catálogos ricos com pôsteres, temporadas e episódios, retomar e continuar assistindo." },
      { t: "Xtream e M3U", d: "Conecte qualquer login Xtream Codes ou URL de lista M3U/M3U8 em segundos. Vários perfis." },
      { t: "Legendas e faixas de áudio", d: "Busca integrada no OpenSubtitles e seleção de legendas e múltiplas faixas de áudio." },
      { t: "Catch-up e multitela", d: "Assista programas passados e até quatro canais ao mesmo tempo numa só tela." },
      { t: "Privado e seguro", d: "Suas listas sincronizam com sua conta. Streams HTTP são encaminhados por HTTPS para tocar com segurança." },
    ],
    howTitle: "Pronto em menos de um minuto",
    steps: [
      { t: "Crie sua conta grátis", d: "Cadastre-se com um e-mail — sem cartão para o teste." },
      { t: "Adicione sua lista", d: "Cole seu login Xtream ou URL M3U. Seus canais, filmes e séries aparecem na hora." },
      { t: "Aperte play", d: "Assista na TV, celular ou navegador. Faça upgrade para Pro uma vez e desbloqueie tudo para sempre." },
    ],
    priceTitle: "Preço simples e honesto",
    priceSub: "Um pagamento. Pro vitalício. Sem assinaturas nem renovações, nunca.",
    priceName: "Pro Vitalício",
    pricePer: "único",
    priceFeatures: [
      "Listas e perfis ilimitados",
      "TV ao vivo, VOD, EPG e catch-up",
      "Legendas, multi-áudio e multitela",
      "Funciona em TV, celular e navegador",
      "Atualizações grátis para sempre",
    ],
    priceCta: "Obter Pro Vitalício",
    priceTrial: "…ou comece com um teste grátis de 1 dia",
    faqTitle: "Perguntas frequentes",
    faq: [
      { q: "O Smart IPTV Stream fornece canais ou conteúdo?", a: "Não. O Smart IPTV Stream é apenas um player. Você traz seu próprio login Xtream Codes ou lista M3U do seu provedor; não vendemos, hospedamos nem fornecemos nenhum canal ou conteúdo." },
      { q: "Quais dispositivos são suportados?", a: "TVs LG (webOS) e Samsung (Tizen), Android TV, e qualquer navegador moderno em celulares, tablets e computadores neste site." },
      { q: "É mesmo pagamento único?", a: "Sim. Pague uma vez pelo Pro Vitalício — sem assinaturas ou taxas recorrentes. Você ainda ganha um teste grátis de 1 dia." },
      { q: "Posso usar listas só HTTP no navegador?", a: "Sim. Streams HTTP inseguros são encaminhados automaticamente por HTTPS para tocar sem erros de conteúdo misto." },
      { q: "Meus favoritos e progresso sincronizam?", a: "Sim. Suas listas, favoritos, continuar assistindo e configurações ficam vinculados à sua conta e acompanham você entre dispositivos." },
    ],
    ctaTitle: "Pronto para assistir?",
    ctaSub: "Crie uma conta grátis e comece a transmitir em menos de um minuto.",
    ctaBtn: "Abrir o app",
    footerTagline: "Um player IPTV rápido e moderno para cada tela.",
    footerDisclaimer:
      "Smart IPTV Stream é um reprodutor de mídia. Não fornece, vende nem hospeda nenhum canal, stream ou conteúdo. Os usuários devem fornecer sua própria lista IPTV legal.",
    footerProduct: "Produto",
    footerLegal: "Legal",
    footerLang: "Idioma",
    linkOpenApp: "Abrir app",
    linkSignIn: "Entrar",
    rights: "Todos os direitos reservados.",
  },
  it: {
    metaTitle: "Smart IPTV Stream — Guarda l'IPTV su TV, telefono e browser",
    metaDesc:
      "Smart IPTV Stream è un player IPTV veloce ed elegante per LG webOS, Samsung TV, Android TV, telefoni e web. Carica liste Xtream o M3U e goditi EPG, film, serie, catch-up, multi-schermo e sottotitoli. Pagamento unico, senza abbonamento.",
    keywords:
      "player IPTV, Smart IPTV, player Xtream, player M3U, LG webOS IPTV, Samsung TV IPTV, guardare IPTV online, IPTV web, EPG, VOD, serie",
    skip: "Vai al contenuto",
    navFeatures: "Funzioni",
    navHow: "Come funziona",
    navPricing: "Prezzo",
    navFaq: "FAQ",
    navOpen: "Apri app",
    heroBadge: "Funziona su ogni schermo",
    heroTitle: "La tua IPTV, splendidamente organizzata — su TV, telefono o browser.",
    heroSub:
      "Carica la tua lista Xtream Codes o M3U e goditi TV in diretta, film, serie, EPG, catch-up, multi-schermo e sottotitoli in un player veloce e moderno. Inizia gratis, aggiorna una sola volta — senza abbonamento.",
    heroCta: "Inizia gratis",
    heroCta2: "Accedi",
    heroNote: "Prova gratuita di 1 giorno · Upgrade Pro unico · Annulla quando vuoi (non c'è nulla da annullare)",
    featuresTitle: "Tutto ciò che serve per guardare, in un unico posto",
    features: [
      { t: "TV in diretta con EPG", d: "Sfoglia i canali con guida elettronica completa, preferiti e cambio istantaneo." },
      { t: "Film e serie (VOD)", d: "Cataloghi ricchi con locandine, stagioni ed episodi, riprendi e continua a guardare." },
      { t: "Xtream e M3U", d: "Collega qualsiasi login Xtream Codes o URL di lista M3U/M3U8 in pochi secondi. Più profili." },
      { t: "Sottotitoli e tracce audio", d: "Ricerca OpenSubtitles integrata e selezione di sottotitoli e più tracce audio." },
      { t: "Catch-up e multi-schermo", d: "Guarda programmi passati e fino a quattro canali insieme su un solo schermo." },
      { t: "Privato e sicuro", d: "Le tue liste si sincronizzano con il tuo account. Gli stream HTTP passano via HTTPS per riprodursi in sicurezza." },
    ],
    howTitle: "Pronto in meno di un minuto",
    steps: [
      { t: "Crea il tuo account gratuito", d: "Registrati con un'email — nessuna carta per la prova." },
      { t: "Aggiungi la tua lista", d: "Incolla il tuo login Xtream o URL M3U. Canali, film e serie appaiono all'istante." },
      { t: "Premi play", d: "Guarda su TV, telefono o browser. Passa a Pro una volta per sbloccare tutto a vita." },
    ],
    priceTitle: "Prezzo semplice e onesto",
    priceSub: "Un pagamento. Pro a vita. Nessun abbonamento, nessun rinnovo, mai.",
    priceName: "Pro a vita",
    pricePer: "una tantum",
    priceFeatures: [
      "Liste e profili illimitati",
      "TV in diretta, VOD, EPG e catch-up",
      "Sottotitoli, multi-audio e multi-schermo",
      "Funziona su TV, telefono e browser",
      "Aggiornamenti gratuiti per sempre",
    ],
    priceCta: "Ottieni Pro a vita",
    priceTrial: "…oppure inizia con una prova gratuita di 1 giorno",
    faqTitle: "Domande frequenti",
    faq: [
      { q: "Smart IPTV Stream fornisce canali o contenuti?", a: "No. Smart IPTV Stream è solo un player. Sei tu a fornire il tuo login Xtream Codes o la lista M3U del tuo provider; non vendiamo, ospitiamo né forniamo alcun canale o contenuto." },
      { q: "Quali dispositivi sono supportati?", a: "TV LG (webOS) e Samsung (Tizen), Android TV, e qualsiasi browser moderno su telefoni, tablet e computer su questo sito." },
      { q: "È davvero un pagamento unico?", a: "Sì. Paghi una volta per Pro a vita — nessun abbonamento o costo ricorrente. Hai anche una prova gratuita di 1 giorno." },
      { q: "Posso usare liste solo HTTP nel browser?", a: "Sì. Gli stream HTTP non sicuri passano automaticamente via HTTPS così da riprodursi senza errori di contenuto misto." },
      { q: "I miei preferiti e progressi si sincronizzano?", a: "Sì. Liste, preferiti, continua a guardare e impostazioni sono legati al tuo account e ti seguono su tutti i dispositivi." },
    ],
    ctaTitle: "Pronto a guardare?",
    ctaSub: "Crea un account gratuito e inizia a guardare in meno di un minuto.",
    ctaBtn: "Apri l'app",
    footerTagline: "Un player IPTV veloce e moderno per ogni schermo.",
    footerDisclaimer:
      "Smart IPTV Stream è un lettore multimediale. Non fornisce, vende né ospita alcun canale, stream o contenuto. Gli utenti devono fornire la propria lista IPTV legale.",
    footerProduct: "Prodotto",
    footerLegal: "Note legali",
    footerLang: "Lingua",
    linkOpenApp: "Apri app",
    linkSignIn: "Accedi",
    rights: "Tutti i diritti riservati.",
  },
  ru: {
    metaTitle: "Smart IPTV Stream — Смотрите IPTV на любом ТВ, телефоне и в браузере",
    metaDesc:
      "Smart IPTV Stream — быстрый и красивый IPTV-плеер для LG webOS, Samsung TV, Android TV, телефонов и веба. Загружайте плейлисты Xtream или M3U и получайте EPG, фильмы, сериалы, архив, мультиэкран и субтитры. Разовая оплата, без подписки.",
    keywords:
      "IPTV плеер, Smart IPTV, Xtream плеер, M3U плеер, LG webOS IPTV, Samsung TV IPTV, смотреть IPTV онлайн, IPTV в браузере, EPG, VOD, сериалы",
    skip: "Перейти к содержимому",
    navFeatures: "Возможности",
    navHow: "Как это работает",
    navPricing: "Цена",
    navFaq: "Вопросы",
    navOpen: "Открыть приложение",
    heroBadge: "Работает на любом экране",
    heroTitle: "Ваше IPTV, красиво упорядоченное — на любом ТВ, телефоне или в браузере.",
    heroSub:
      "Загрузите плейлист Xtream Codes или M3U и наслаждайтесь эфиром, фильмами, сериалами, EPG, архивом, мультиэкраном и субтитрами в быстром современном плеере. Начните бесплатно, обновитесь один раз — без подписки.",
    heroCta: "Смотреть бесплатно",
    heroCta2: "Войти",
    heroNote: "1 день бесплатно · Разовое обновление до Pro · Отмена в любой момент (отменять нечего)",
    featuresTitle: "Всё для просмотра в одном месте",
    features: [
      { t: "Эфир с EPG", d: "Просматривайте каналы с полной телепрограммой, избранным и мгновенным переключением." },
      { t: "Фильмы и сериалы (VOD)", d: "Богатые каталоги с постерами, сезонами и сериями, продолжение с места остановки." },
      { t: "Xtream и M3U", d: "Подключите любой вход Xtream Codes или ссылку на плейлист M3U/M3U8 за секунды. Несколько профилей." },
      { t: "Субтитры и аудиодорожки", d: "Встроенный поиск OpenSubtitles и выбор субтитров и нескольких аудиодорожек." },
      { t: "Архив и мультиэкран", d: "Смотрите прошедшие передачи и до четырёх каналов одновременно на одном экране." },
      { t: "Приватно и безопасно", d: "Плейлисты синхронизируются с вашим аккаунтом. HTTP-потоки проксируются через HTTPS для безопасного воспроизведения." },
    ],
    howTitle: "Готово меньше чем за минуту",
    steps: [
      { t: "Создайте бесплатный аккаунт", d: "Зарегистрируйтесь по e-mail — карта для пробного периода не нужна." },
      { t: "Добавьте плейлист", d: "Вставьте вход Xtream или ссылку M3U. Каналы, фильмы и сериалы появятся мгновенно." },
      { t: "Нажмите воспроизведение", d: "Смотрите на ТВ, телефоне или в браузере. Обновитесь до Pro один раз и откройте всё навсегда." },
    ],
    priceTitle: "Простая и честная цена",
    priceSub: "Одна оплата. Pro навсегда. Никаких подписок и продлений, никогда.",
    priceName: "Pro навсегда",
    pricePer: "разово",
    priceFeatures: [
      "Неограниченные плейлисты и профили",
      "Эфир, VOD, EPG и архив",
      "Субтитры, мультиаудио и мультиэкран",
      "Работает на ТВ, телефоне и в браузере",
      "Бесплатные обновления навсегда",
    ],
    priceCta: "Получить Pro навсегда",
    priceTrial: "…или начните с бесплатного 1-дневного периода",
    faqTitle: "Частые вопросы",
    faq: [
      { q: "Предоставляет ли Smart IPTV Stream каналы или контент?", a: "Нет. Smart IPTV Stream — только плеер. Вы приносите собственный вход Xtream Codes или плейлист M3U от вашего провайдера; мы не продаём, не размещаем и не предоставляем каналы или контент." },
      { q: "Какие устройства поддерживаются?", a: "Смарт-ТВ LG (webOS) и Samsung (Tizen), Android TV и любой современный браузер на телефонах, планшетах и компьютерах на этом сайте." },
      { q: "Это действительно разовая оплата?", a: "Да. Заплатите один раз за Pro навсегда — без подписок и регулярных платежей. Также есть бесплатный 1-дневный пробный период." },
      { q: "Можно ли использовать только HTTP-плейлисты в браузере?", a: "Да. Небезопасные HTTP-потоки автоматически проксируются через HTTPS и воспроизводятся без ошибок смешанного содержимого." },
      { q: "Синхронизируются ли избранное и прогресс?", a: "Да. Плейлисты, избранное, продолжение просмотра и настройки привязаны к вашему аккаунту и следуют за вами на всех устройствах." },
    ],
    ctaTitle: "Готовы смотреть?",
    ctaSub: "Создайте бесплатный аккаунт и начните смотреть меньше чем за минуту.",
    ctaBtn: "Открыть приложение",
    footerTagline: "Быстрый современный IPTV-плеер для любого экрана.",
    footerDisclaimer:
      "Smart IPTV Stream — это медиаплеер. Он не предоставляет, не продаёт и не размещает каналы, потоки или контент. Пользователи должны использовать собственный легальный IPTV-плейлист.",
    footerProduct: "Продукт",
    footerLegal: "Правовое",
    footerLang: "Язык",
    linkOpenApp: "Открыть приложение",
    linkSignIn: "Войти",
    rights: "Все права защищены.",
  },
  ar: {
    metaTitle: "Smart IPTV Stream — شاهد IPTV على أي تلفاز وهاتف ومتصفح",
    metaDesc:
      "Smart IPTV Stream مشغّل IPTV سريع وأنيق لأجهزة LG webOS وSamsung TV وAndroid TV والهواتف والويب. حمّل قوائم Xtream أو M3U واستمتع بدليل البرامج والأفلام والمسلسلات وإعادة المشاهدة وتعدد الشاشات والترجمات. دفعة واحدة بدون اشتراك.",
    keywords:
      "مشغل IPTV, Smart IPTV, مشغل Xtream, مشغل M3U, LG webOS IPTV, Samsung TV IPTV, مشاهدة IPTV اونلاين, IPTV ويب, EPG, VOD, مسلسلات",
    skip: "تخطَّ إلى المحتوى",
    navFeatures: "المزايا",
    navHow: "كيف يعمل",
    navPricing: "السعر",
    navFaq: "الأسئلة",
    navOpen: "افتح التطبيق",
    heroBadge: "يعمل على كل شاشة",
    heroTitle: "IPTV الخاص بك، منظَّم بشكل رائع — على أي تلفاز أو هاتف أو متصفح.",
    heroSub:
      "حمّل قائمة Xtream Codes أو M3U واستمتع بالبث المباشر والأفلام والمسلسلات ودليل البرامج وإعادة المشاهدة وتعدد الشاشات والترجمات في مشغّل سريع وعصري. ابدأ مجانًا وترقَّ مرة واحدة — بدون اشتراك.",
    heroCta: "ابدأ المشاهدة مجانًا",
    heroCta2: "تسجيل الدخول",
    heroNote: "تجربة مجانية ليوم واحد · ترقية Pro لمرة واحدة · ألغِ متى شئت (لا شيء لإلغائه)",
    featuresTitle: "كل ما تحتاجه للمشاهدة في مكان واحد",
    features: [
      { t: "بث مباشر مع دليل البرامج", d: "تصفّح القنوات بدليل برامج إلكتروني كامل والمفضلة والتنقل الفوري." },
      { t: "أفلام ومسلسلات (VOD)", d: "مكتبات غنية بالملصقات والمواسم والحلقات، مع الاستئناف ومتابعة المشاهدة." },
      { t: "Xtream وM3U", d: "اربط أي حساب Xtream Codes أو رابط قائمة M3U/M3U8 خلال ثوانٍ. دعم ملفات تعريف متعددة." },
      { t: "الترجمات والمسارات الصوتية", d: "بحث مدمج في OpenSubtitles واختيار الترجمات والمسارات الصوتية المتعددة." },
      { t: "إعادة المشاهدة وتعدد الشاشات", d: "شاهد البرامج السابقة وحتى أربع قنوات في وقت واحد على شاشة واحدة." },
      { t: "خصوصية وأمان", d: "تتزامن قوائمك مع حسابك. تُمرَّر بثوث HTTP عبر HTTPS لتعمل بأمان في أي متصفح." },
    ],
    howTitle: "جاهز في أقل من دقيقة",
    steps: [
      { t: "أنشئ حسابك المجاني", d: "سجّل ببريد إلكتروني — لا حاجة لبطاقة للتجربة." },
      { t: "أضف قائمتك", d: "الصق حساب Xtream أو رابط M3U. تظهر قنواتك وأفلامك ومسلسلاتك فورًا." },
      { t: "اضغط تشغيل", d: "شاهد على التلفاز أو الهاتف أو المتصفح. ترقَّ إلى Pro مرة واحدة لفتح كل شيء مدى الحياة." },
    ],
    priceTitle: "تسعير بسيط وصادق",
    priceSub: "دفعة واحدة. Pro مدى الحياة. لا اشتراكات ولا تجديدات، أبدًا.",
    priceName: "Pro مدى الحياة",
    pricePer: "لمرة واحدة",
    priceFeatures: [
      "قوائم وملفات تعريف غير محدودة",
      "بث مباشر وVOD ودليل برامج وإعادة مشاهدة",
      "ترجمات وصوت متعدد وتعدد شاشات",
      "يعمل على التلفاز والهاتف والمتصفح",
      "تحديثات مجانية للأبد",
    ],
    priceCta: "احصل على Pro مدى الحياة",
    priceTrial: "…أو ابدأ بتجربة مجانية ليوم واحد",
    faqTitle: "الأسئلة الشائعة",
    faq: [
      { q: "هل يوفّر Smart IPTV Stream قنوات أو محتوى؟", a: "لا. Smart IPTV Stream مشغّل فقط. أنت تحضر حساب Xtream Codes أو قائمة M3U الخاصة بك من مزوّدك؛ نحن لا نبيع ولا نستضيف ولا نوفّر أي قنوات أو محتوى." },
      { q: "ما الأجهزة المدعومة؟", a: "تلفزيونات LG (webOS) وSamsung (Tizen) الذكية، وAndroid TV، وأي متصفح حديث على الهواتف والأجهزة اللوحية والحواسيب عبر هذا الموقع." },
      { q: "هل هي حقًا دفعة واحدة؟", a: "نعم. ادفع مرة واحدة مقابل Pro مدى الحياة — بدون اشتراكات أو رسوم متكررة. كما تحصل على تجربة مجانية ليوم واحد." },
      { q: "هل يمكنني استخدام قوائم HTTP فقط في المتصفح؟", a: "نعم. تُمرَّر بثوث HTTP غير الآمنة تلقائيًا عبر HTTPS لتعمل دون أخطاء المحتوى المختلط." },
      { q: "هل تتزامن المفضلة والتقدم؟", a: "نعم. قوائمك ومفضلتك ومتابعة المشاهدة والإعدادات مرتبطة بحسابك وتتبعك عبر الأجهزة." },
    ],
    ctaTitle: "جاهز للمشاهدة؟",
    ctaSub: "أنشئ حسابًا مجانيًا وابدأ البث في أقل من دقيقة.",
    ctaBtn: "افتح التطبيق",
    footerTagline: "مشغّل IPTV سريع وعصري لكل شاشة.",
    footerDisclaimer:
      "Smart IPTV Stream مشغّل وسائط. لا يوفّر أو يبيع أو يستضيف أي قنوات أو بثوث أو محتوى. على المستخدمين توفير قائمة IPTV قانونية خاصة بهم.",
    footerProduct: "المنتج",
    footerLegal: "قانوني",
    footerLang: "اللغة",
    linkOpenApp: "افتح التطبيق",
    linkSignIn: "تسجيل الدخول",
    rights: "جميع الحقوق محفوظة.",
  },
};

// Safety net: any published language without hand-written copy falls back to
// English (should not happen — every LANGS entry above has its own S[code]).
for (const l of LANGS) if (!S[l.code]) S[l.code] = S.en;

// ── HTML building ───────────────────────────────────────────────────────────
const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function icon(i) {
  const p = [
    '<path d="M4 5h16v11H4z"/><path d="M9 20h6"/>', // live tv
    '<path d="M4 5h16v14H4z"/><path d="M8 5v14M16 5v14"/>', // vod film
    '<path d="M4 7h16M4 12h16M4 17h10"/>', // playlist
    '<path d="M5 6h14v9H5z"/><path d="M8 19h8"/>', // subtitles
    '<path d="M4 5h7v7H4zM13 5h7v7h-7zM4 14h7v5H4zM13 14h7v5h-7z"/>', // multiscreen
    '<path d="M12 3l8 4v5c0 5-3.5 8-8 9-4.5-1-8-4-8-9V7z"/>', // shield
  ][i % 6];
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
}

function jsonLd(t, code) {
  const app = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: "Smart IPTV Stream",
    operatingSystem: "Web, Android TV, LG webOS, Samsung Tizen",
    applicationCategory: "MultimediaApplication",
    description: t.metaDesc,
    url: urlFor(code),
    image: OG_IMAGE,
    offers: { "@type": "Offer", price: "5.99", priceCurrency: "USD", category: "one-time" },
  };
  const faq = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: t.faq.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };
  return (
    `<script type="application/ld+json">${JSON.stringify(app)}</script>` +
    `<script type="application/ld+json">${JSON.stringify(faq)}</script>`
  );
}

function altLinks(current) {
  const alts = LANGS.map(
    (l) => `<link rel="alternate" hreflang="${l.hreflang}" href="${urlFor(l.code)}" />`,
  ).join("");
  return alts + `<link rel="alternate" hreflang="x-default" href="${urlFor("en")}" />`;
}

function pageHtml(L) {
  const t = S[L.code];
  const url = urlFor(L.code);
  const dir = L.dir === "rtl" ? ' dir="rtl"' : "";
  const features = t.features
    .map(
      (f, i) =>
        `<article class="card"><div class="ico">${icon(i)}</div><h3>${esc(f.t)}</h3><p>${esc(f.d)}</p></article>`,
    )
    .join("");
  const steps = t.steps
    .map((s, i) => `<li><span class="num">${i + 1}</span><div><h3>${esc(s.t)}</h3><p>${esc(s.d)}</p></div></li>`)
    .join("");
  const priceLi = t.priceFeatures.map((f) => `<li>${esc(f)}</li>`).join("");
  const faq = t.faq
    .map((f) => `<details><summary>${esc(f.q)}</summary><p>${esc(f.a)}</p></details>`)
    .join("");
  const langSwitch = LANGS.map(
    (l) => `<a href="${l.code === "en" ? "/" : "/" + l.code + "/"}"${l.code === L.code ? ' aria-current="true"' : ""}>${l.hreflang.toUpperCase()}</a>`,
  ).join("");

  return `<!doctype html>
<html lang="${L.code}"${dir}>
<head>
<meta charset="UTF-8" />
<script>if(location.hash.indexOf("#/")===0){location.replace("${APP}"+location.hash);}</script>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${esc(t.metaTitle)}</title>
<meta name="description" content="${esc(t.metaDesc)}" />
<meta name="keywords" content="${esc(t.keywords)}" />
<link rel="canonical" href="${url}" />
${altLinks(L.code)}
<meta name="theme-color" content="#0a0a1a" />
<meta property="og:type" content="website" />
<meta property="og:site_name" content="Smart IPTV Stream" />
<meta property="og:title" content="${esc(t.metaTitle)}" />
<meta property="og:description" content="${esc(t.metaDesc)}" />
<meta property="og:url" content="${url}" />
<meta property="og:image" content="${OG_IMAGE}" />
<meta property="og:locale" content="${L.locale}" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="${esc(t.metaTitle)}" />
<meta name="twitter:description" content="${esc(t.metaDesc)}" />
<meta name="twitter:image" content="${OG_IMAGE}" />
<link rel="icon" type="image/png" href="${FAVICON}" />
<link rel="apple-touch-icon" href="${FAVICON}" />
<link rel="manifest" href="/site.webmanifest" />
${jsonLd(t, L.code)}
<style>
:root{--bg:#0a0a1a;--bg2:#14002e;--fg:#eef0ff;--mut:#a6a8c6;--acc:#00E5A8;--acc2:#3660F5;--card:rgba(255,255,255,.04);--bd:rgba(255,255,255,.10)}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;color:var(--fg);background:radial-gradient(1200px 800px at 80% -10%,#1c0140 0%,transparent 60%),linear-gradient(160deg,var(--bg2) 0%,var(--bg) 55%);min-height:100vh;line-height:1.6}
a{color:inherit;text-decoration:none}
img{max-width:100%}
.wrap{max-width:1120px;margin:0 auto;padding:0 20px}
.btn{display:inline-block;padding:13px 22px;border-radius:12px;font-weight:700;border:1px solid transparent;transition:.2s}
.btn-p{background:linear-gradient(135deg,var(--acc),#33ffce);color:#06231b;box-shadow:0 8px 30px rgba(0,229,168,.25)}
.btn-p:hover{transform:translateY(-1px)}
.btn-g{background:rgba(255,255,255,.06);border-color:var(--bd);color:var(--fg)}
.btn-g:hover{background:rgba(255,255,255,.12)}
header{position:sticky;top:0;z-index:20;backdrop-filter:blur(10px);background:rgba(10,10,26,.6);border-bottom:1px solid var(--bd)}
.nav{display:flex;align-items:center;gap:22px;height:66px}
.brand{display:flex;align-items:center;gap:10px;font-weight:800;font-size:18px}
.brand img{width:30px;height:30px;border-radius:7px}
.nav .links{display:flex;gap:22px;margin-inline-start:auto}
.nav .links a{color:var(--mut);font-weight:600;font-size:15px}
.nav .links a:hover{color:var(--fg)}
.nav .cta{margin-inline-start:8px}
@media(max-width:820px){.nav .links{display:none}.nav .cta{margin-inline-start:auto}}
.hero{padding:76px 0 56px;text-align:center}
.badge{display:inline-block;padding:6px 14px;border:1px solid var(--bd);border-radius:999px;color:var(--acc);font-weight:700;font-size:13px;letter-spacing:.3px}
.hero h1{font-size:clamp(30px,5vw,54px);line-height:1.1;margin:20px auto 16px;max-width:16ch;font-weight:800;letter-spacing:-.5px}
.hero p.sub{color:var(--mut);font-size:clamp(16px,2.2vw,20px);max-width:60ch;margin:0 auto 28px}
.hero .actions{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}
.hero .note{color:var(--mut);font-size:13px;margin-top:16px}
section{padding:56px 0}
h2{font-size:clamp(24px,3.4vw,36px);text-align:center;margin:0 0 10px;font-weight:800;letter-spacing:-.3px}
.lead{color:var(--mut);text-align:center;max-width:56ch;margin:0 auto 36px}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
.card{background:var(--card);border:1px solid var(--bd);border-radius:16px;padding:24px}
.card .ico{width:44px;height:44px;border-radius:11px;display:grid;place-items:center;background:rgba(0,229,168,.12);color:var(--acc);margin-bottom:14px}
.card .ico svg{width:24px;height:24px}
.card h3{margin:0 0 6px;font-size:18px}
.card p{margin:0;color:var(--mut);font-size:15px}
.steps{list-style:none;padding:0;max-width:760px;margin:0 auto;display:grid;gap:18px}
.steps li{display:flex;gap:16px;align-items:flex-start;background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:18px 20px}
.steps .num{flex:0 0 34px;width:34px;height:34px;border-radius:50%;display:grid;place-items:center;font-weight:800;background:linear-gradient(135deg,var(--acc2),#6f8bff);color:#fff}
.steps h3{margin:0 0 4px;font-size:17px}.steps p{margin:0;color:var(--mut);font-size:15px}
.price{max-width:460px;margin:0 auto;background:linear-gradient(180deg,rgba(0,229,168,.08),var(--card));border:1px solid rgba(0,229,168,.35);border-radius:20px;padding:30px;text-align:center}
.price .amt{font-size:52px;font-weight:800;letter-spacing:-1px}
.price .amt small{font-size:16px;color:var(--mut);font-weight:600}
.price ul{list-style:none;padding:0;margin:20px 0;text-align:start;display:grid;gap:10px}
.price li{padding-inline-start:28px;position:relative;color:#dfe1ff}
.price li:before{content:"✓";position:absolute;inset-inline-start:0;color:var(--acc);font-weight:800}
.price .btn{width:100%;margin-top:6px}
.price .trial{color:var(--mut);font-size:13px;margin-top:12px}
.faq{max-width:820px;margin:0 auto;display:grid;gap:12px}
details{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:4px 18px}
summary{cursor:pointer;padding:14px 0;font-weight:700;list-style:none}
summary::-webkit-details-marker{display:none}
summary:after{content:"+";float:inline-end;color:var(--acc);font-weight:800}
details[open] summary:after{content:"–"}
details p{margin:0 0 14px;color:var(--mut)}
.ctaband{text-align:center;background:linear-gradient(135deg,rgba(54,96,245,.18),rgba(0,229,168,.12));border:1px solid var(--bd);border-radius:22px;padding:44px 24px;margin:8px 0}
footer{border-top:1px solid var(--bd);padding:40px 0;color:var(--mut);font-size:14px}
.fcols{display:flex;flex-wrap:wrap;gap:30px;justify-content:space-between}
.fcols h4{color:var(--fg);font-size:14px;margin:0 0 10px}
.fcols a{display:block;color:var(--mut);padding:3px 0}
.fcols a:hover{color:var(--fg)}
.langs{display:flex;flex-wrap:wrap;gap:8px}
.langs a{border:1px solid var(--bd);border-radius:8px;padding:4px 9px;font-size:12px;font-weight:700}
.langs a[aria-current]{border-color:var(--acc);color:var(--acc)}
.disc{margin-top:26px;font-size:12px;opacity:.75;max-width:70ch}
.copy{margin-top:14px;font-size:12px;opacity:.7}
.skip{position:absolute;left:-999px}.skip:focus{left:12px;top:12px;background:#fff;color:#000;padding:8px 12px;border-radius:8px;z-index:50}
</style>
</head>
<body>
<a class="skip" href="#main">${esc(t.skip)}</a>
<header><div class="wrap nav">
<a class="brand" href="${L.code === "en" ? "/" : "/" + L.code + "/"}"><img src="${LOGO}" alt="Smart IPTV Stream logo" width="30" height="30" />Smart IPTV Stream</a>
<nav class="links">
<a href="#features">${esc(t.navFeatures)}</a>
<a href="#how">${esc(t.navHow)}</a>
<a href="#pricing">${esc(t.navPricing)}</a>
<a href="#faq">${esc(t.navFaq)}</a>
</nav>
<a class="btn btn-p cta" href="${APP}">${esc(t.navOpen)}</a>
</div></header>

<main id="main">
<section class="hero"><div class="wrap">
<span class="badge">${esc(t.heroBadge)}</span>
<h1>${esc(t.heroTitle)}</h1>
<p class="sub">${esc(t.heroSub)}</p>
<div class="actions">
<a class="btn btn-p" href="${APP}">${esc(t.heroCta)}</a>
<a class="btn btn-g" href="${APP}/#/auth">${esc(t.heroCta2)}</a>
</div>
<p class="note">${esc(t.heroNote)}</p>
</div></section>

<section id="features"><div class="wrap">
<h2>${esc(t.featuresTitle)}</h2>
<div class="grid">${features}</div>
</div></section>

<section id="how"><div class="wrap">
<h2>${esc(t.howTitle)}</h2>
<ol class="steps">${steps}</ol>
</div></section>

<section id="pricing"><div class="wrap">
<h2>${esc(t.priceTitle)}</h2>
<p class="lead">${esc(t.priceSub)}</p>
<div class="price">
<div class="amt">${PRICE} <small>/ ${esc(t.pricePer)}</small></div>
<h3>${esc(t.priceName)}</h3>
<ul>${priceLi}</ul>
<a class="btn btn-p" href="${APP}">${esc(t.priceCta)}</a>
<p class="trial">${esc(t.priceTrial)}</p>
</div>
</div></section>

<section id="faq"><div class="wrap">
<h2>${esc(t.faqTitle)}</h2>
<div class="faq">${faq}</div>
</div></section>

<section><div class="wrap"><div class="ctaband">
<h2>${esc(t.ctaTitle)}</h2>
<p class="lead">${esc(t.ctaSub)}</p>
<a class="btn btn-p" href="${APP}">${esc(t.ctaBtn)}</a>
</div></div></section>
</main>

<footer><div class="wrap">
<div class="fcols">
<div style="max-width:280px">
<a class="brand" href="${L.code === "en" ? "/" : "/" + L.code + "/"}" style="color:var(--fg)"><img src="${LOGO}" alt="" width="26" height="26" style="border-radius:6px"/>Smart IPTV Stream</a>
<p style="margin:10px 0 0">${esc(t.footerTagline)}</p>
</div>
<div>
<h4>${esc(t.footerProduct)}</h4>
<a href="${APP}">${esc(t.linkOpenApp)}</a>
<a href="${APP}/#/auth">${esc(t.linkSignIn)}</a>
<a href="#pricing">${esc(t.navPricing)}</a>
<a href="#faq">${esc(t.navFaq)}</a>
</div>
<div>
<h4>${esc(t.footerLang)}</h4>
<div class="langs">${langSwitch}</div>
</div>
</div>
<p class="disc">${esc(t.footerDisclaimer)}</p>
<p class="copy">© ${new Date().getFullYear()} Smart IPTV Stream. ${esc(t.rights)}</p>
</div></footer>
</body>
</html>`;
}

// ── 1) Move SPA shell to app.html + mark it noindex ─────────────────────────
{
  const spa = resolve(dist, "index.html");
  let html = readFileSync(spa, "utf8");
  if (!/name="robots"/.test(html)) {
    html = html.replace(/<head>/i, '<head>\n    <meta name="robots" content="noindex,follow" />');
  }
  writeFileSync(resolve(dist, "app.html"), html);
}

// ── 2) Generate landing pages ───────────────────────────────────────────────
for (const L of LANGS) {
  const out = outFor(L.code);
  mkdirSync(dirname(out), { recursive: true });
  writeFileSync(out, pageHtml(L));
}

// ── 3) robots.txt + sitemap.xml + manifest ──────────────────────────────────
writeFileSync(
  resolve(dist, "robots.txt"),
  `User-agent: *\nAllow: /$\nAllow: /assets/\n${LANGS.filter((l) => l.code !== "en")
    .map((l) => `Allow: /${l.code}/`)
    .join("\n")}\nDisallow: /app\nDisallow: /api/\n\nSitemap: ${SITE}/sitemap.xml\n`,
);

const now = new Date().toISOString().slice(0, 10);
writeFileSync(
  resolve(dist, "sitemap.xml"),
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">\n` +
    LANGS.map(
      (l) =>
        `  <url>\n    <loc>${urlFor(l.code)}</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>${l.code === "en" ? "1.0" : "0.8"}</priority>\n` +
        LANGS.map((a) => `    <xhtml:link rel="alternate" hreflang="${a.hreflang}" href="${urlFor(a.code)}" />`).join("\n") +
        `\n    <xhtml:link rel="alternate" hreflang="x-default" href="${urlFor("en")}" />\n  </url>`,
    ).join("\n") +
    `\n</urlset>\n`,
);

writeFileSync(
  resolve(dist, "site.webmanifest"),
  JSON.stringify(
    {
      name: "Smart IPTV Stream",
      short_name: "IPTV Stream",
      description: S.en.metaDesc,
      start_url: "/app",
      scope: "/",
      display: "standalone",
      background_color: "#0a0a1a",
      theme_color: "#0a0a1a",
      icons: [
        { src: "/assets/androidlogo.png", sizes: "192x192", type: "image/png" },
        { src: "/assets/appicon.png", sizes: "512x512", type: "image/png" },
      ],
    },
    null,
    2,
  ),
);

console.log(`✓ web build ready: app.html + ${LANGS.length} landing pages + robots/sitemap/manifest`);
