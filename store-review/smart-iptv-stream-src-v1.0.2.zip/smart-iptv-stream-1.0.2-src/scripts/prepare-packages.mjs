// Prepares platform-specific app folders from the Vite `dist/` output.
//
//   node scripts/prepare-packages.mjs
//
// Produces:
//   build/webos/   -> ready for `ares-package build/webos`
//   build/tizen/   -> ready for Tizen Studio / `tizen package`
//
import { cpSync, mkdirSync, rmSync, existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");
const dist = resolve(root, "dist");

if (!existsSync(dist)) {
  console.error("dist/ not found. Run `npm run build` first.");
  process.exit(1);
}

function build(target, platformDir) {
  const out = resolve(root, "build", target);
  rmSync(out, { recursive: true, force: true });
  mkdirSync(out, { recursive: true });
  cpSync(dist, out, { recursive: true });
  cpSync(resolve(root, "platform", platformDir), out, { recursive: true });
  console.log(`✓ ${target} ready at build/${target}`);
}

build("webos", "webos");
build("tizen", "tizen");

console.log("\nNext steps:");
console.log("  webOS : ares-package build/webos && ares-install <ipk> -d <device>");
console.log("  Tizen : tizen package -t wgt -- build/tizen  (then tizen install)");
