// One-off: add the Safari paywall's "buy in the Mac app" copy to every locale.
// App Store guideline 3.1.1 forbids linking out to our own checkout from a
// Mac App Store app, so the Safari build points at the container app's
// StoreKit purchase instead of the hosted Cleeng page.
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const dir = resolve(__dirname, "../src/i18n/locales");

const TITLE = {
  en: "Upgrade in the app", af: "Gradeer op in die app", am: "በመተግበሪያው ውስጥ ያሻሽሉ",
  ar: "الترقية من التطبيق", az: "Tətbiqdə yükseltin", be: "Палепшыць у праграме",
  bg: "Надградете в приложението", bn: "অ্যাপে আপগ্রেড করুন", ca: "Millora a l'app",
  cs: "Upgradujte v aplikaci", da: "Opgrader i appen", de: "Im App upgraden",
  el: "Αναβάθμιση στην εφαρμογή", es: "Mejora en la app", et: "Uuenda rakenduses",
  eu: "Hobetu aplikazioan", fa: "ارتقا در برنامه", fi: "Päivitä sovelluksessa",
  fr: "Passez Pro dans l'app", ga_IE: "Uasghrádaigh san aip", he: "שדרוג באפליקציה",
  hi: "ऐप में अपग्रेड करें", hr: "Nadogradi u aplikaciji", hu: "Váltás az alkalmazásban",
  id: "Tingkatkan di aplikasi", it: "Passa a Pro nell'app", ja: "アプリでアップグレード",
  kk: "Қолданбада жаңарту", ko: "앱에서 업그레이드", ku: "Di sepanê de bilind bike",
  lv: "Jauniniet lietotnē", ms: "Tingkatkan dalam apl", nl: "Upgraden in de app",
  no: "Oppgrader i appen", pl: "Ulepsz w aplikacji", pt: "Atualizar na app",
  pt_BR: "Fazer upgrade no app", qu: "Aplicacionpi allinchay", ro: "Trecere la Pro în aplicație",
  ru: "Улучшить в приложении", sk: "Prejdite na Pro v aplikácii", sl: "Nadgradite v aplikaciji",
  sq: "Përmirësoje në aplikacion", sr: "Надогради у апликацији", sv: "Uppgradera i appen",
  tr: "Uygulamadan yükselt", ur: "ایپ میں اپ گریڈ کریں", zh: "在应用中升级",
};

const HINT = {
  en: "Open the Smart IPTV Stream app on your Mac and choose “Upgrade to Pro”. Pro unlocks here right after the purchase.",
  af: "Maak die Smart IPTV Stream-app op jou Mac oop en kies “Gradeer op na Pro”. Pro word hier oopgesluit direk na die aankoop.",
  am: "በ Mac ላይ የ Smart IPTV Stream መተግበሪያን ክፈቱ እና “Pro ያሻሽሉ” ይምረጡ። ግዢው ወዲያውኑ Pro እዚህ ይከፈታል።",
  ar: "افتح تطبيق Smart IPTV Stream على جهاز Mac واختر «الترقية إلى Pro». يتم تفعيل Pro هنا مباشرة بعد الشراء.",
  az: "Mac-da Smart IPTV Stream tətbiqini açın və “Pro-ya yükselt” seçin. Alışdan dərhal sonra Pro burada açılır.",
  be: "Адкрыйце праграму Smart IPTV Stream на Mac і выберыце «Палепшыць да Pro». Pro адкрыецца тут адразу пасля купкі.",
  bg: "Отворете приложението Smart IPTV Stream на вашия Mac и изберете „Надградете до Pro“. Pro се отключва тук веднага след покупката.",
  bn: "আপনার Mac-এ Smart IPTV Stream অ্যাপ খুলে “Pro-তে আপগ্রেড” বেছে নিন। কেনার সঙ্গে সঙ্গেই এখানে Pro চালু হবে।",
  ca: "Obre l'app Smart IPTV Stream al Mac i tria «Millora a Pro». Pro es desbloqueja aquí just després de la compra.",
  cs: "Otevřete aplikaci Smart IPTV Stream na Macu a zvolte „Upgradovat na Pro“. Pro se zde odemkne hned po nákupu.",
  da: "Åbn Smart IPTV Stream-appen på din Mac og vælg “Opgrader til Pro”. Pro låses op her lige efter købet.",
  de: "Öffnen Sie die Smart IPTV Stream App auf Ihrem Mac und wählen Sie „Auf Pro upgraden“. Pro wird hier direkt nach dem Kauf freigeschaltet.",
  el: "Ανοίξτε την εφαρμογή Smart IPTV Stream στο Mac και επιλέξτε «Αναβάθμιση σε Pro». Το Pro ξεκλειδώνει εδώ αμέσως μετά την αγορά.",
  es: "Abre la app Smart IPTV Stream en tu Mac y elige «Mejorar a Pro». Pro se desbloquea aquí justo después de la compra.",
  et: "Ava Macis rakendus Smart IPTV Stream ja vali „Uuenda Pro-le“. Pro avaneb siin kohe pärast ostu.",
  eu: "Ireki Smart IPTV Stream aplikazioa Mac-en eta hautatu “Hobetu Pro-ra”. Pro hemen desblokeatzen da erosi bezain laster.",
  fa: "برنامه Smart IPTV Stream را در Mac باز کنید و «ارتقا به Pro» را انتخاب کنید. Pro بلافاصله پس از خرید اینجا فعال می‌شود.",
  fi: "Avaa Smart IPTV Stream ‑sovellus Macissa ja valitse ”Päivitä Pro-versioon”. Pro avautuu tässä heti oston jälkeen.",
  fr: "Ouvrez l'app Smart IPTV Stream sur votre Mac et choisissez « Passer à Pro ». Pro est débloqué ici juste après l'achat.",
  ga_IE: "Oscail an aip Smart IPTV Stream ar do Mac agus roghnaigh “Uasghrádaigh go Pro”. Díghlasálfar Pro anseo díreach tar éis an cheannaigh.",
  he: "פתחו את אפליקציית Smart IPTV Stream ב-Mac ובחרו ב״שדרוג ל-Pro״. Pro נפתח כאן מיד לאחר הרכישה.",
  hi: "अपने Mac पर Smart IPTV Stream ऐप खोलें और “Pro में अपग्रेड करें” चुनें। खरीद के तुरंत बाद यहाँ Pro चालू हो जाएगा।",
  hr: "Otvorite aplikaciju Smart IPTV Stream na Macu i odaberite „Nadogradi na Pro“. Pro se ovdje otključava odmah nakon kupnje.",
  hu: "Nyissa meg a Smart IPTV Stream alkalmazást a Macen, és válassza a „Váltás Pro-ra” lehetőséget. A Pro a vásárlás után azonnal itt is aktív.",
  id: "Buka aplikasi Smart IPTV Stream di Mac Anda dan pilih “Tingkatkan ke Pro”. Pro terbuka di sini segera setelah pembelian.",
  it: "Apri l'app Smart IPTV Stream sul Mac e scegli «Passa a Pro». Pro si sblocca qui subito dopo l'acquisto.",
  ja: "Mac で Smart IPTV Stream アプリを開き、「Pro にアップグレード」を選択してください。購入後すぐにここで Pro が有効になります。",
  kk: "Mac құрылғысында Smart IPTV Stream қолданбасын ашып, «Pro-ға жаңарту» тармағын таңдаңыз. Сатып алғаннан кейін Pro осында бірден ашылады.",
  ko: "Mac에서 Smart IPTV Stream 앱을 열고 “Pro로 업그레이드”를 선택하세요. 구매 직후 여기에서 Pro가 활성화됩니다.",
  ku: "Sepana Smart IPTV Stream li Mac-a xwe veke û “Bilindkirina bo Pro” hilbijêre. Pro tavilê piştî kirînê li vir vedibe.",
  lv: "Atveriet Smart IPTV Stream lietotni savā Mac un izvēlieties “Jaunināt uz Pro”. Pro šeit tiek atbloķēts uzreiz pēc pirkuma.",
  ms: "Buka apl Smart IPTV Stream pada Mac anda dan pilih “Tingkatkan ke Pro”. Pro dibuka di sini sebaik sahaja pembelian selesai.",
  nl: "Open de Smart IPTV Stream-app op je Mac en kies “Upgraden naar Pro”. Pro wordt hier direct na de aankoop ontgrendeld.",
  no: "Åpne Smart IPTV Stream-appen på Macen og velg «Oppgrader til Pro». Pro låses opp her rett etter kjøpet.",
  pl: "Otwórz aplikację Smart IPTV Stream na Macu i wybierz „Ulepsz do Pro”. Pro odblokuje się tutaj zaraz po zakupie.",
  pt: "Abra a app Smart IPTV Stream no seu Mac e escolha «Atualizar para Pro». O Pro é desbloqueado aqui logo após a compra.",
  pt_BR: "Abra o app Smart IPTV Stream no seu Mac e escolha “Fazer upgrade para Pro”. O Pro é liberado aqui logo após a compra.",
  qu: "Mac nisqaykipi Smart IPTV Stream aplicacionta kichay, “Pro man allinchay” nisqata akllay. Rantisqaykimanta qhipa Pro kaypi kicharikun.",
  ro: "Deschide aplicația Smart IPTV Stream pe Mac și alege „Trecere la Pro”. Pro se deblochează aici imediat după achiziție.",
  ru: "Откройте приложение Smart IPTV Stream на Mac и выберите «Улучшить до Pro». Pro откроется здесь сразу после покупки.",
  sk: "Otvorte aplikáciu Smart IPTV Stream na Macu a vyberte „Prejsť na Pro“. Pro sa tu odomkne hneď po nákupe.",
  sl: "Odprite aplikacijo Smart IPTV Stream na Macu in izberite »Nadgradi na Pro«. Pro se tu odklene takoj po nakupu.",
  sq: "Hap aplikacionin Smart IPTV Stream në Mac dhe zgjidh “Përmirëso në Pro”. Pro shkyçet këtu menjëherë pas blerjes.",
  sr: "Отворите апликацију Smart IPTV Stream на Mac-у и изаберите „Надогради на Pro“. Pro се овде откључава одмах након куповине.",
  sv: "Öppna appen Smart IPTV Stream på din Mac och välj ”Uppgradera till Pro”. Pro låses upp här direkt efter köpet.",
  tr: "Mac'inizde Smart IPTV Stream uygulamasını açın ve “Pro'ya geç”i seçin. Satın alma biter bitmez Pro burada da açılır.",
  ur: "اپنے Mac پر Smart IPTV Stream ایپ کھولیں اور “Pro میں اپ گریڈ کریں” منتخب کریں۔ خریداری کے فوراً بعد یہاں Pro کھل جائے گا۔",
  zh: "在 Mac 上打开 Smart IPTV Stream 应用并选择“升级到 Pro”。购买完成后，这里会立即解锁 Pro。",
};

for (const code of Object.keys(TITLE)) {
  const file = resolve(dir, `${code}.json`);
  const json = JSON.parse(readFileSync(file, "utf8"));
  json.payAppleTitle = TITLE[code];
  json.payAppleHint = HINT[code];
  writeFileSync(file, JSON.stringify(json, null, 2) + "\n");
}
console.log(`Done: ${Object.keys(TITLE).length} files updated.`);
