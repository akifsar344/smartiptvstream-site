// One-off: add Live TV related keys (translated) to every locale JSON.
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const dir = resolve(__dirname, "../src/i18n/locales");

const RENAME = {
  en: "Rename", ar: "إعادة تسمية", af: "Hernoem", am: "እንደገና ሰይም", az: "Adını dəyiş",
  be: "Перайменаваць", bg: "Преименуване", bn: "নাম পরিবর্তন", ca: "Reanomena", cs: "Přejmenovat",
  da: "Omdøb", de: "Umbenennen", el: "Μετονομασία", es: "Renombrar", et: "Nimeta ümber",
  eu: "Berrizendatu", fa: "تغییر نام", fi: "Nimeä uudelleen", fr: "Renommer", ga_IE: "Athainmnigh",
  he: "שנה שם", hi: "नाम बदलें", hr: "Preimenuj", hu: "Átnevezés", id: "Ganti nama",
  it: "Rinomina", ja: "名前を変更", kk: "Атын өзгерту", ko: "이름 변경", ku: "Navê biguhêre",
  lv: "Pārdēvēt", ms: "Namakan semula", nl: "Hernoemen", no: "Gi nytt navn", pl: "Zmień nazwę",
  pt: "Renomear", pt_BR: "Renomear", qu: "Suti tikray", ro: "Redenumește", ru: "Переименовать",
  sk: "Premenovať", sl: "Preimenuj", sq: "Riemërto", sr: "Преименуј", sv: "Byt namn",
  tr: "Yeniden adlandır", ur: "نام تبدیل کریں", zh: "重命名",
};

const CLEAR_CONFIRM = {
  en: "Clear all items?", ar: "مسح كل العناصر؟", af: "Vee alle items uit?", am: "ሁሉንም ንጥሎች ይጽዱ?",
  az: "Bütün elementlər silinsin?", be: "Ачысціць усе?", bg: "Изчистване на всичко?",
  bn: "সব আইটেম মুছবেন?", ca: "Esborrar tots els elements?", cs: "Vymazat vše?", da: "Ryd alt?",
  de: "Alle Einträge löschen?", el: "Εκκαθάριση όλων;", es: "¿Borrar todo?", et: "Tühjenda kõik?",
  eu: "Garbitu dena?", fa: "همه موارد پاک شود؟", fi: "Tyhjennetäänkö kaikki?", fr: "Tout effacer ?",
  ga_IE: "Glan gach mír?", he: "לנקות את הכול?", hi: "सभी आइटम साफ़ करें?", hr: "Očistiti sve?",
  hu: "Összes törlése?", id: "Hapus semua item?", it: "Cancellare tutto?", ja: "すべて削除しますか？",
  kk: "Барлығын тазалау?", ko: "모두 지울까요?", ku: "Hemû tişt paqij bike?", lv: "Notīrīt visu?",
  ms: "Kosongkan semua item?", nl: "Alles wissen?", no: "Tøm alt?", pl: "Wyczyścić wszystko?",
  pt: "Limpar tudo?", pt_BR: "Limpar tudo?", qu: "Llapa imata pichanachu?", ro: "Ștergeți tot?",
  ru: "Очистить всё?", sk: "Vymazať všetko?", sl: "Počisti vse?", sq: "Pastro të gjitha?",
  sr: "Обрисати све?", sv: "Rensa allt?", tr: "Tümünü temizle?", ur: "تمام آئٹمز صاف کریں؟",
  zh: "清除所有项目？",
};

for (const code of Object.keys(RENAME)) {
  const file = resolve(dir, `${code}.json`);
  const json = JSON.parse(readFileSync(file, "utf8"));
  json.rename = RENAME[code];
  json.clearConfirm = CLEAR_CONFIRM[code];
  writeFileSync(file, JSON.stringify(json, null, 2) + "\n");
}
console.log(`Done: ${Object.keys(RENAME).length} files updated.`);
