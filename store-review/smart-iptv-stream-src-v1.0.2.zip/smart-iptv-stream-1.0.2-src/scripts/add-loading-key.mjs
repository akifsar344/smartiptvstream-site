// One-off: add a "loading" key (translated) to every locale JSON.
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const dir = resolve(__dirname, "../src/i18n/locales");

const T = {
  en: "Loading",
  ar: "جارٍ التحميل",
  af: "Laai tans",
  am: "በመጫን ላይ",
  az: "Yüklənir",
  be: "Загрузка",
  bg: "Зареждане",
  bn: "লোড হচ্ছে",
  ca: "S'està carregant",
  cs: "Načítání",
  da: "Indlæser",
  de: "Wird geladen",
  el: "Φόρτωση",
  es: "Cargando",
  et: "Laadimine",
  eu: "Kargatzen",
  fa: "در حال بارگذاری",
  fi: "Ladataan",
  fr: "Chargement",
  ga_IE: "Á lódáil",
  he: "טוען",
  hi: "लोड हो रहा है",
  hr: "Učitavanje",
  hu: "Betöltés",
  id: "Memuat",
  it: "Caricamento",
  ja: "読み込み中",
  kk: "Жүктелуде",
  ko: "로딩 중",
  ku: "Bar dibe",
  lv: "Notiek ielāde",
  ms: "Memuatkan",
  nl: "Laden",
  no: "Laster",
  pl: "Ładowanie",
  pt: "A carregar",
  pt_BR: "Carregando",
  qu: "Cargachkan",
  ro: "Se încarcă",
  ru: "Загрузка",
  sk: "Načítava sa",
  sl: "Nalaganje",
  sq: "Po ngarkohet",
  sr: "Учитавање",
  sv: "Laddar",
  tr: "Yükleniyor",
  ur: "لوڈ ہو رہا ہے",
  zh: "加载中",
};

for (const [code, value] of Object.entries(T)) {
  const file = resolve(dir, `${code}.json`);
  const json = JSON.parse(readFileSync(file, "utf8"));
  json.loading = value;
  writeFileSync(file, JSON.stringify(json, null, 2) + "\n");
  console.log(`+ ${code}: ${value}`);
}
console.log(`\nDone: ${Object.keys(T).length} files updated.`);
