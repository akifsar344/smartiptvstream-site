// One-off: add parental lock/unlock action labels (translated) to every locale.
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));
const dir = resolve(__dirname, "../src/i18n/locales");

const LOCK = {
  en: "Lock", ar: "قفل", af: "Sluit", am: "ቆልፍ", az: "Kilidlə",
  be: "Заблакіраваць", bg: "Заключи", bn: "লক করুন", ca: "Bloqueja", cs: "Zamknout",
  da: "Lås", de: "Sperren", el: "Κλείδωμα", es: "Bloquear", et: "Lukusta",
  eu: "Blokeatu", fa: "قفل", fi: "Lukitse", fr: "Verrouiller", ga_IE: "Glasáil",
  he: "נעל", hi: "लॉक करें", hr: "Zaključaj", hu: "Zárolás", id: "Kunci",
  it: "Blocca", ja: "ロック", kk: "Құлыптау", ko: "잠금", ku: "Kilît bike",
  lv: "Bloķēt", ms: "Kunci", nl: "Vergrendelen", no: "Lås", pl: "Zablokuj",
  pt: "Bloquear", pt_BR: "Bloquear", qu: "Wisq'ay", ro: "Blochează", ru: "Заблокировать",
  sk: "Zamknúť", sl: "Zakleni", sq: "Kyç", sr: "Закључај", sv: "Lås",
  tr: "Kilitle", ur: "لاک کریں", zh: "锁定",
};

const UNLOCK = {
  en: "Remove Lock", ar: "إزالة القفل", af: "Verwyder slot", am: "ቁልፍ አስወግድ", az: "Kilidi sil",
  be: "Зняць блакіроўку", bg: "Премахни заключването", bn: "লক সরান", ca: "Treu el bloqueig", cs: "Odebrat zámek",
  da: "Fjern lås", de: "Sperre entfernen", el: "Αφαίρεση κλειδώματος", es: "Quitar bloqueo", et: "Eemalda lukk",
  eu: "Kendu blokeoa", fa: "حذف قفل", fi: "Poista lukitus", fr: "Retirer le verrou", ga_IE: "Bain glas",
  he: "הסר נעילה", hi: "लॉक हटाएं", hr: "Ukloni zaključavanje", hu: "Zárolás eltávolítása", id: "Hapus kunci",
  it: "Rimuovi blocco", ja: "ロックを解除", kk: "Құлыпты алу", ko: "잠금 해제", ku: "Kilîtê rake",
  lv: "Noņemt bloķēšanu", ms: "Buang kunci", nl: "Vergrendeling verwijderen", no: "Fjern lås", pl: "Usuń blokadę",
  pt: "Remover bloqueio", pt_BR: "Remover bloqueio", qu: "Wisq'ayta qichuy", ro: "Elimină blocarea", ru: "Снять блокировку",
  sk: "Odstrániť zámok", sl: "Odstrani zaklep", sq: "Hiq kyçjen", sr: "Уклони закључавање", sv: "Ta bort lås",
  tr: "Kilidi Kaldır", ur: "لاک ہٹائیں", zh: "解除锁定",
};

for (const code of Object.keys(LOCK)) {
  const file = resolve(dir, `${code}.json`);
  const json = JSON.parse(readFileSync(file, "utf8"));
  json.lockItem = LOCK[code];
  json.unlockItem = UNLOCK[code];
  writeFileSync(file, JSON.stringify(json, null, 2) + "\n");
}
console.log(`Done: ${Object.keys(LOCK).length} files updated.`);
