// One-off: deploy Firestore security rules via the Firebase Rules REST API
// using a gcloud OAuth access token (avoids needing a fresh firebase CLI login).
//   node scripts/deploy-firestore-rules.mjs <rules-file> <project-id>
import { readFileSync } from "node:fs";
import { execSync } from "node:child_process";

const rulesFile = process.argv[2];
const project = process.argv[3];
if (!rulesFile || !project) {
  console.error("usage: node deploy-firestore-rules.mjs <rules-file> <project-id>");
  process.exit(1);
}

const token = execSync("gcloud auth print-access-token").toString().trim();
const source = readFileSync(rulesFile, "utf8");

async function api(path, method, body) {
  const res = await fetch(`https://firebaserules.googleapis.com/v1/${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      "x-goog-user-project": project,
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await res.json();
  if (!res.ok) {
    console.error(`HTTP ${res.status}`, JSON.stringify(json, null, 2));
    process.exit(1);
  }
  return json;
}

const ruleset = await api(`projects/${project}/rulesets`, "POST", {
  source: { files: [{ name: "firestore.rules", content: source }] },
});
console.log("created ruleset:", ruleset.name);

const releaseName = `projects/${project}/releases/cloud.firestore`;
const release = await api(`${releaseName}?updateMask=rulesetName`, "PATCH", {
  release: { name: releaseName, rulesetName: ruleset.name },
});
console.log("updated release -> ruleset:", release.rulesetName);
console.log("done");
