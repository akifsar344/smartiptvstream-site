// Assembles the browser-extension packages from the EXT_BUILD Vite output.
//
//   npm run build:ext
//     1. `EXT_BUILD=1 vite build`  → dist-ext/index.html (SPA, relative assets,
//        VITE_EXT=1, API base = smartiptvstream.com)
//     2. this script:
//        - copies dist-ext/* into build-ext/chrome/ and renames the SPA entry to
//          app.html (referenced by the manifest / opened by the service worker)
//        - drops in manifest.json (version synced from package.json),
//          background.js and the icon set
//        - zips it into build-ext/smart-iptv-stream-chrome-v<ver>.zip
//        - copies the identical MV3 package as the Edge upload zip
//
// Chrome & Edge share one Manifest V3 package. Safari is produced from the same
// build-ext/chrome/ folder via Apple's converter (see the printed command / the
// EXT_PUBLISH.md guide) and requires macOS + Xcode.
import {
  readFileSync,
  writeFileSync,
  existsSync,
  mkdirSync,
  rmSync,
  cpSync,
  readdirSync,
  statSync,
  renameSync,
} from "node:fs";
import { dirname, resolve, join, relative, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { zipSync } from "fflate";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = resolve(__dirname, "..");
const distExt = resolve(root, "dist-ext");
const extSrc = resolve(root, "extension");
const outDir = resolve(root, "build-ext");

if (!existsSync(resolve(distExt, "index.html"))) {
  console.error("dist-ext/index.html not found. Run `EXT_BUILD=1 vite build` first.");
  process.exit(1);
}

const pkg = JSON.parse(readFileSync(resolve(root, "package.json"), "utf8"));
const version = pkg.version || "1.0.0";

// ── 1) Assemble the unpacked Chrome/Edge package ────────────────────────────
const chromeDir = resolve(outDir, "chrome");
rmSync(chromeDir, { recursive: true, force: true });
mkdirSync(chromeDir, { recursive: true });

cpSync(distExt, chromeDir, { recursive: true });
// The SPA entry becomes app.html (what the manifest & service worker open).
renameSync(resolve(chromeDir, "index.html"), resolve(chromeDir, "app.html"));

// ── 2) manifest (version synced) + extension scripts + icons ────────────────
const manifest = JSON.parse(readFileSync(resolve(extSrc, "manifest.json"), "utf8"));
manifest.version = version;
writeFileSync(resolve(chromeDir, "manifest.json"), JSON.stringify(manifest, null, 2));
cpSync(resolve(extSrc, "background.js"), resolve(chromeDir, "background.js"));
cpSync(resolve(extSrc, "content-bridge.js"), resolve(chromeDir, "content-bridge.js"));
cpSync(resolve(extSrc, "icons"), resolve(chromeDir, "icons"), { recursive: true });

// ── 3) Zip (store-ready) ────────────────────────────────────────────────────
function zipDir(dir) {
  const files = {};
  const walk = (d) => {
    for (const name of readdirSync(d)) {
      const full = join(d, name);
      if (statSync(full).isDirectory()) walk(full);
      // Zip paths always use forward slashes.
      else files[relative(dir, full).split(sep).join("/")] = new Uint8Array(readFileSync(full));
    }
  };
  walk(dir);
  return zipSync(files, { level: 9 });
}

const chromeZip = resolve(outDir, `smart-iptv-stream-chrome-v${version}.zip`);
writeFileSync(chromeZip, zipDir(chromeDir));

// Edge and Opera accept the identical Chromium MV3 package.
const edgeZip = resolve(outDir, `smart-iptv-stream-edge-v${version}.zip`);
writeFileSync(edgeZip, readFileSync(chromeZip));
const operaZip = resolve(outDir, `smart-iptv-stream-opera-v${version}.zip`);
writeFileSync(operaZip, readFileSync(chromeZip));

console.log(`✓ extension package ready (v${version})`);
console.log(`  • Unpacked (load in chrome://extensions → Load unpacked): build-ext/chrome`);
console.log(`  • Chrome Web Store upload: ${relative(root, chromeZip)}`);
console.log(`  • Edge Add-ons upload:     ${relative(root, edgeZip)}`);
console.log(`  • Opera addons upload:     ${relative(root, operaZip)}`);
console.log(`  • Safari (needs macOS + Xcode):`);
console.log(`      xcrun safari-web-extension-converter "${relative(root, chromeDir)}"`);
