# smartiptvstream.com — Deployment Guide

A browser IPTV app with its own **account system** (sign up / sign in / password
reset), **per-account cloud sync** (profiles, favourites, continue-watching,
PIN, settings), a **24h trial + Cleeng Pro upgrade**, and a **stream proxy** so
HTTP-only IPTV playlists work on the HTTPS site.

Everything runs on **your own server** with a tiny SQLite database, so **Firebase
is not used at all** (no per-user read/write costs).

```
Browser ── https ──> Node server (server/)
                       ├─ /api/auth/*     accounts (JWT + bcrypt)
                       ├─ /api/data       per-account state sync
                       ├─ /api/webhook/*  Cleeng billing → Pro
                       ├─ /api/proxy      HTTP→HTTPS stream/API proxy
                       └─ static          the built React app (dist/)
                     └─ data/app.db       SQLite (accounts + data)
```

## 1. Prerequisites
- A Linux VPS with **Node.js ≥ 18.17**.
- A domain `smartiptvstream.com` pointing (A/AAAA record) to the VPS.
- A TLS reverse proxy (Nginx or Caddy) terminating HTTPS in front of the app.
- SMTP credentials (any provider: Resend, Brevo, Mailgun, Gmail app password…)
  for password-reset emails.
- A Cleeng hosted-checkout URL + webhook secret.

## 2. Build the frontend
```bash
# in the project root
cp .env.example .env          # VITE_API_BASE empty for prod; set VITE_CHECKOUT_URL
npm install
npm run build                 # outputs dist/
```

## 3. Configure & run the backend
```bash
cd server
cp .env.example .env          # fill in JWT_SECRET, SMTP_*, CLEENG_WEBHOOK_SECRET, PUBLIC_ORIGIN
npm install
npm start                     # listens on PORT (default 8080), also serves ../dist
```
Generate a strong JWT secret:
```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```
Keep it running with a process manager, e.g. **pm2**:
```bash
npm i -g pm2
pm2 start src/index.js --name smartiptvstream
pm2 save && pm2 startup
```

## 4. Reverse proxy + TLS (Nginx example)
```nginx
server {
  server_name smartiptvstream.com www.smartiptvstream.com;
  client_max_body_size 5m;

  location / {
    proxy_pass http://127.0.0.1:8080;
    proxy_http_version 1.1;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;
    # Streaming proxy: don't buffer video.
    proxy_buffering off;
    proxy_read_timeout 300s;
  }
}
```
Then run `certbot --nginx -d smartiptvstream.com -d www.smartiptvstream.com`.
(Caddy does TLS automatically: `smartiptvstream.com { reverse_proxy 127.0.0.1:8080 }`.)

## 5. Cleeng billing
1. In Cleeng, set the **webhook endpoint** to
   `https://smartiptvstream.com/api/webhook/cleeng` and copy the signing secret
   into `server/.env` → `CLEENG_WEBHOOK_SECRET`.
2. Put the hosted-checkout URL for the lifetime offer into the **frontend**
   `.env` → `VITE_CHECKOUT_URL`, then rebuild (`npm run build`).
3. Flow: paywall opens checkout with `?email=<account>` → buyer pays → Cleeng
   fires `transactionCreated` → the webhook flips that account to Pro → the app
   polls `/api/auth/me` and unlocks automatically.

## 6. Local development
```bash
# terminal 1 — backend
cd server && cp .env.example .env && npm install && npm run dev

# terminal 2 — frontend (set VITE_API_BASE=http://localhost:8080 in ./.env)
npm install && npm run dev      # http://localhost:5173
```

## Notes on cost & streaming
- **Firebase**: unused → $0.
- **Database**: SQLite file (`server/data/app.db`); back it up periodically.
- **Bandwidth**: the proxy only carries streams the browser can't fetch directly
  (HTTP playlists and HLS/TS segments that need CORS). HTTPS VOD (mp4) plays
  directly and does **not** pass through your server.
- To scale beyond one box later, move SQLite → Postgres and put the stream proxy
  on a separate cheap bandwidth host.
