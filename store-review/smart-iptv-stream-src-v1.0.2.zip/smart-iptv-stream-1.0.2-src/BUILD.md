# Build instructions — Smart IPTV Stream (Opera add-on 1.0.2)

This archive contains the complete, unminified source of the uploaded package.
The submitted `.zip` is produced by the build below; no other transformation is
applied, and Vite's minifier is the only thing that rewrites the code.

## Environment

- Node.js v22.22.2 (any Node >= 18.17 works), npm 10.9.7
- macOS, Linux or Windows — nothing platform specific is required
- Vite 5.4 and TypeScript 5.7, installed from `package-lock.json`

## Steps

```bash
npm ci
npm run build:ext
```

`build:ext` runs `tsc -b`, then `EXT_BUILD=1 vite build`, then
`node scripts/build-ext.mjs`, which copies `extension/` (manifest, background
service worker, content bridge, icons) together with the compiled app.

## Output

- `build-ext/chrome/` — the unpacked extension
- `build-ext/smart-iptv-stream-opera-v1.0.2.zip` — the uploaded package
  (identical content is uploaded to the Chrome Web Store and Edge Add-ons)

## Layout

- `extension/` — manifest, background service worker, content bridge, icons
- `src/` — the player application (React + TypeScript) bundled into the package
- `scripts/build-ext.mjs` — packaging step
- `public/` — static assets referenced by the app

No remote code is loaded or evaluated at runtime; every script ships inside the
package.
