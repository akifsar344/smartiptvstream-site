// MV3 service worker. The extension has no popup: clicking the toolbar icon
// opens (or focuses) the full app in its own browser tab. The app itself is the
// bundled SPA served from the extension package (app.html), so there is no
// remote page load — it runs entirely from the installed extension.

const APP_PAGE = "app.html";
// Safari exposes `browser`, Chrome/Edge `chrome`; both provide the MV3 surface
// used here.
const api = globalThis.browser ?? globalThis.chrome;
// Safari before 16.4 has no storage.session, so fall back to local; the SPA
// deletes the one-shot intent immediately and rejects stale entries anyway.
const bridgeStorage = api.storage.session || api.storage.local;

async function openApp() {
  const url = api.runtime.getURL(APP_PAGE);
  // Match any already-open app tab (ignore the #hash route) and focus it.
  const tabs = await api.tabs.query({});
  const existing = tabs.find((t) => t.url && t.url.startsWith(url));
  if (existing && existing.id != null) {
    await api.tabs.update(existing.id, { active: true });
    // iOS Safari has no windows API; there is only one window to focus anyway.
    if (api.windows && existing.windowId != null) {
      await api.windows.update(existing.windowId, { focused: true });
    }
    return existing;
  }
  return api.tabs.create({ url });
}

api.action.onClicked.addListener(() => {
  openApp();
});

// Open the app right after install so the user lands in it immediately.
api.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") openApp();
});

// Requests arrive only through content-bridge.js, which the manifest injects
// exclusively into smartiptvstream.com. Keep the source URL + one-time account
// handoff code in session storage (never URL/local storage), then open/focus the
// bundled app. The SPA consumes and deletes this intent immediately.
api.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== "web-play-live") return false;
  const pageUrl = sender.tab?.url || "";
  if (!/^https:\/\/(www\.)?smartiptvstream\.com\//i.test(pageUrl)) {
    sendResponse({ ok: false, error: "untrusted_origin" });
    return false;
  }

  const p = message.payload || {};
  const valid =
    p.v === 1 &&
    typeof p.handoffCode === "string" &&
    p.handoffCode.length >= 20 &&
    typeof p.url === "string" &&
    /^https?:\/\//i.test(p.url) &&
    (p.kind === "live" || p.kind === "vod");
  if (!valid) {
    sendResponse({ ok: false, error: "invalid_payload" });
    return false;
  }

  (async () => {
    await bridgeStorage.set({
      pendingWebPlayback: {
        v: 1,
        handoffCode: p.handoffCode,
        url: p.url,
        fallbackUrl:
          typeof p.fallbackUrl === "string" && /^https?:\/\//i.test(p.fallbackUrl)
            ? p.fallbackUrl
            : undefined,
        title: String(p.title || "Live TV").slice(0, 300),
        kind: p.kind,
        createdAt: Date.now(),
      },
    });
    await openApp();
    sendResponse({ ok: true });
  })().catch((error) => {
    sendResponse({ ok: false, error: error?.message || "bridge_failed" });
  });
  return true;
});
