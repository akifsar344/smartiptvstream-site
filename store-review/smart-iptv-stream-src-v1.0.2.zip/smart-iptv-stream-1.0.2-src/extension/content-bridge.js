// Secure bridge between smartiptvstream.com and this installed extension.
// The page never needs to know a Chrome/Edge/Safari extension id. Only this
// allowlisted content script can forward a one-shot playback request internally.

const PAGE_SOURCE = "smart-iptv-stream-web";
const EXT_SOURCE = "smart-iptv-stream-extension";

// Safari exposes the promise-based `browser` namespace, Chrome/Edge the
// callback-based `chrome` one. Branch on the namespace instead of sending twice.
const api = globalThis.browser ?? globalThis.chrome;
const usesPromises = Boolean(globalThis.browser);

function browserName() {
  const ua = navigator.userAgent;
  if (/OPR\//i.test(ua)) return "opera";
  if (/Edg\//i.test(ua)) return "edge";
  if (/Safari\//i.test(ua) && !/Chrome|Chromium|CriOS/i.test(ua)) return "safari";
  return "chrome";
}

function reply(type, requestId, extra = {}) {
  window.postMessage(
    { source: EXT_SOURCE, type, requestId, browser: browserName(), ...extra },
    window.location.origin
  );
}

window.addEventListener("message", (event) => {
  if (event.source !== window || event.origin !== window.location.origin) return;
  const message = event.data;
  if (!message || message.source !== PAGE_SOURCE) return;

  if (message.type === "ping") {
    reply("ready", message.requestId);
    return;
  }
  if (message.type !== "play-live" || !message.payload) return;

  const request = { type: "web-play-live", payload: message.payload };
  const done = (response) =>
    reply("play-result", message.requestId, response || { ok: false });
  const failed = (error) =>
    reply("play-result", message.requestId, {
      ok: false,
      error: error?.message || "send_failed",
    });

  if (usesPromises) {
    api.runtime.sendMessage(request).then(done, failed);
  } else {
    api.runtime.sendMessage(request, (response) => {
      if (api.runtime.lastError) failed(api.runtime.lastError);
      else done(response);
    });
  }
});

// Announce immediately; the page also has a ping mechanism in case this event
// happened before React mounted.
reply("ready", "");
