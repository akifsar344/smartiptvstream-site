//  ViewController.swift — Smart IPTV Stream, Safari extension host app.
//
//  Replaces the converter's default "enable me" page with the surface Apple
//  requires us to own natively:
//    • enabling the extension in Safari
//    • signing in to the Smart IPTV Stream account
//    • buying lifetime Pro through StoreKit (App Review forbids sending users to
//      an external checkout from inside the app, so the purchase happens here)
//
//  Entitlement is stored server-side against the account, so a verified purchase
//  immediately shows up as Pro in the Safari extension and on every other
//  platform without any local receipt handling.
//
//  One file serves both the macOS and the iOS host: the account, purchase and
//  UI code is shared, and only the bits Safari exposes differently are split.
//  Keeping it in a single file means build-safari.mjs can drop the same source
//  into each target without touching the Xcode project.
//
//  Edited in the repo at safari-app/ViewController.swift; scripts/build-safari.mjs
//  copies it into the generated Xcode project.

import Combine
import StoreKit
import SwiftUI

#if os(macOS)
import AppKit
import SafariServices
import WebKit
#else
import UIKit
#endif

let extensionBundleIdentifier = "com.discoverapp.smartiptvstream.Extension"
private let proProductIdentifier = "com.discoverapp.smartiptvstream.pro.lifetime"
private let apiBaseURL = URL(string: "https://smartiptvstream.com")!
private let websiteURL = URL(string: "https://smartiptvstream.com/app")!

// SwiftUI ships its own `Transaction`, so StoreKit's needs qualifying.
private typealias StoreTransaction = StoreKit.Transaction

private let isTurkish = Locale.current.identifier.hasPrefix("tr")
private func t(_ en: String, _ tr: String) -> String { isTurkish ? tr : en }

// MARK: - Session token (Keychain)

private enum SessionStore {
    private static let query: [String: Any] = [
        kSecClass as String: kSecClassGenericPassword,
        kSecAttrService as String: "com.discoverapp.smartiptvstream",
        kSecAttrAccount as String: "session-token",
    ]

    static func save(_ token: String) {
        SecItemDelete(query as CFDictionary)
        var attributes = query
        attributes[kSecValueData as String] = Data(token.utf8)
        SecItemAdd(attributes as CFDictionary, nil)
    }

    static func load() -> String? {
        var lookup = query
        lookup[kSecReturnData as String] = true
        var item: CFTypeRef?
        guard SecItemCopyMatching(lookup as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func clear() { SecItemDelete(query as CFDictionary) }
}

// MARK: - Backend

private struct Account {
    let email: String
    let isPro: Bool
}

private struct BackendError: LocalizedError {
    let code: String
    var errorDescription: String? {
        switch code {
        case "invalid_credentials":
            return t("Wrong e-mail or password.", "E-posta veya şifre hatalı.")
        case "transaction_belongs_to_other_account":
            return t(
                "This purchase already unlocked a different account.",
                "Bu satın alma başka bir hesabı açmış."
            )
        case "offline":
            return t("Could not reach the server.", "Sunucuya ulaşılamadı.")
        default:
            return t("The purchase could not be confirmed.", "Satın alma doğrulanamadı.")
        }
    }
}

private enum Backend {
    private static func decode(_ data: Data) -> [String: Any] {
        (try? JSONSerialization.jsonObject(with: data)) as? [String: Any] ?? [:]
    }

    private static func account(_ json: [String: Any], fallbackEmail: String) -> Account {
        let access = json["access"] as? [String: Any]
        return Account(
            email: access?["email"] as? String ?? fallbackEmail,
            isPro: access?["isPro"] as? Bool ?? false
        )
    }

    private static func send(_ request: URLRequest) async throws -> [String: Any] {
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw BackendError(code: "offline")
        }
        let json = decode(data)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw BackendError(code: json["error"] as? String ?? "unknown")
        }
        return json
    }

    private static func post(_ path: String, body: [String: String], token: String?) -> URLRequest {
        var request = URLRequest(url: apiBaseURL.appendingPathComponent(path))
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let token { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
        request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        return request
    }

    static func login(email: String, password: String) async throws -> (String, Account) {
        let json: [String: Any]
        do {
            json = try await send(post("api/auth/login", body: ["email": email, "password": password], token: nil))
        } catch let error as BackendError where error.code != "offline" {
            throw BackendError(code: "invalid_credentials")
        }
        guard let token = json["token"] as? String else { throw BackendError(code: "invalid_credentials") }
        return (token, account(json, fallbackEmail: email))
    }

    static func me(token: String) async throws -> Account {
        var request = URLRequest(url: apiBaseURL.appendingPathComponent("api/auth/me"))
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        return account(try await send(request), fallbackEmail: "")
    }

    /// The server verifies Apple's JWS against Apple's root CA before unlocking.
    static func redeem(signedTransaction: String, token: String) async throws -> Account {
        let request = post(
            "api/iap/apple/verify",
            body: ["signedTransaction": signedTransaction],
            token: token
        )
        return account(try await send(request), fallbackEmail: "")
    }
}

// MARK: - Model

@MainActor
private final class HostAppModel: ObservableObject {
    @Published var extensionEnabled: Bool?
    @Published var account: Account?
    @Published var product: Product?
    @Published var busy = false
    @Published var notice: String?
    @Published var error: String?

    init() {
        // Purchases that complete outside a purchase() call: Ask to Buy
        // approvals, and hand-offs that failed while the app was closed.
        Task { [weak self] in
            for await update in StoreTransaction.updates {
                guard case .verified(let transaction) = update else { continue }
                await self?.redeem(update.jwsRepresentation, finishing: transaction)
            }
        }
    }

    func start() async {
        await refreshExtensionState()
        product = try? await Product.products(for: [proProductIdentifier]).first
        guard let token = SessionStore.load() else { return }
        if let account = try? await Backend.me(token: token) {
            self.account = account
        } else {
            SessionStore.clear()
        }
    }

    // Only macOS can report or open the extension's state; on iOS the switch
    // lives in the Settings app and there is no API for either, so the UI falls
    // back to instructions.
    func refreshExtensionState() async {
        #if os(macOS)
        extensionEnabled = await withCheckedContinuation { continuation in
            SFSafariExtensionManager.getStateOfSafariExtension(
                withIdentifier: extensionBundleIdentifier
            ) { state, _ in
                continuation.resume(returning: state?.isEnabled ?? false)
            }
        }
        #endif
    }

    #if os(macOS)
    func openSafariSettings() {
        SFSafariApplication.showPreferencesForExtension(withIdentifier: extensionBundleIdentifier) { _ in }
    }
    #endif

    func signIn(email: String, password: String) async {
        await run {
            let (token, account) = try await Backend.login(email: email, password: password)
            SessionStore.save(token)
            self.account = account
        }
    }

    func signOut() {
        SessionStore.clear()
        account = nil
        notice = nil
        error = nil
    }

    func buy() async {
        guard let product else { return }
        await run {
            switch try await product.purchase() {
            case .success(let verification):
                guard case .verified(let transaction) = verification else {
                    throw BackendError(code: "unverified")
                }
                try await self.submit(verification.jwsRepresentation, finishing: transaction)
            case .pending:
                self.notice = t("The purchase is waiting for approval.", "Satın alma onay bekliyor.")
            case .userCancelled:
                break
            @unknown default:
                break
            }
        }
    }

    func restore() async {
        await run {
            var restored = false
            for await entitlement in StoreTransaction.currentEntitlements {
                guard case .verified(let transaction) = entitlement,
                      transaction.productID == proProductIdentifier else { continue }
                try await self.submit(entitlement.jwsRepresentation, finishing: transaction)
                restored = true
            }
            if !restored {
                self.notice = t("No previous purchase found.", "Önceki bir satın alma bulunamadı.")
            }
        }
    }

    private func submit(_ signedTransaction: String, finishing transaction: StoreTransaction) async throws {
        guard let token = SessionStore.load() else { throw BackendError(code: "signed_out") }
        account = try await Backend.redeem(signedTransaction: signedTransaction, token: token)
        // Finish only after the server recorded it, so a failed hand-off is
        // retried through Transaction.updates on the next launch.
        await transaction.finish()
        notice = t("Pro is active. Enjoy!", "Pro etkin. İyi seyirler!")
    }

    private func redeem(_ signedTransaction: String, finishing transaction: StoreTransaction) async {
        await run { try await self.submit(signedTransaction, finishing: transaction) }
    }

    private func run(_ work: () async throws -> Void) async {
        busy = true
        error = nil
        notice = nil
        do {
            try await work()
        } catch let failure as BackendError {
            error = failure.errorDescription
        } catch {
            // StoreKit's own messages ("Cannot connect to iTunes Store", no
            // sandbox account, …) are the actionable part, so pass them through
            // instead of hiding them behind a generic apology.
            NSLog("Smart IPTV Stream purchase failure: %@", String(describing: error))
            self.error = error.localizedDescription
        }
        busy = false
    }
}

// MARK: - UI

private struct RootView: View {
    @StateObject private var model = HostAppModel()
    @State private var email = ""
    @State private var password = ""

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                header
                Divider()
                extensionSection
                Divider()
                accountSection
                if let notice = model.notice {
                    Label(notice, systemImage: "checkmark.circle.fill").foregroundStyle(.green)
                }
                if let error = model.error {
                    Label(error, systemImage: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                }
            }
            .padding(22)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .task { await model.start() }
    }

    private var header: some View {
        HStack(spacing: 12) {
            appIcon
                .resizable()
                .frame(width: 52, height: 52)
            VStack(alignment: .leading, spacing: 2) {
                Text("Smart IPTV Stream").font(.title2).bold()
                Text(t("Safari extension", "Safari uzantısı")).foregroundStyle(.secondary)
            }
        }
    }

    private var extensionSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(t("Extension", "Uzantı")).font(.headline)
            #if os(macOS)
            switch model.extensionEnabled {
            case .some(true):
                Label(t("Enabled in Safari.", "Safari'de etkin."), systemImage: "checkmark.seal.fill")
                    .foregroundStyle(.green)
            case .some(false):
                Text(t(
                    "Turn the extension on in Safari to start watching.",
                    "İzlemeye başlamak için uzantıyı Safari'de açın."
                ))
                .font(.callout)
                .foregroundStyle(.secondary)
            case nil:
                ProgressView().controlSize(.small)
            }
            Button(t("Open Safari Settings", "Safari Ayarlarını Aç")) { model.openSafariSettings() }
            #else
            Text(t(
                "Turn the extension on in Safari to start watching.",
                "İzlemeye başlamak için uzantıyı Safari'de açın."
            ))
            .font(.callout)
            .foregroundStyle(.secondary)
            #endif
            setupSteps
        }
    }

    // Enabling the extension and granting it access are separate switches in
    // different corners of Safari's settings, and nothing works until both are
    // set, so spell the whole path out instead of hinting at it.
    private var setupSteps: some View {
        VStack(alignment: .leading, spacing: 7) {
            #if os(macOS)
            step(1, t(
                "Open Safari Settings above, then go to the Extensions tab.",
                "Yukarıdan Safari Ayarları'nı açın, Uzantılar sekmesine geçin."
            ))
            step(2, t(
                "Tick “Smart IPTV Stream” in the list.",
                "Listeden “Smart IPTV Stream”i işaretleyin."
            ))
            step(3, t(
                "Set its access to “Allow on Every Website”, so any IPTV server you add can load.",
                "Erişimini “Her Web Sitesinde İzin Ver” yapın; böylece eklediğiniz her IPTV sunucusu yüklenebilir."
            ))
            step(4, t(
                "Click the Smart IPTV Stream icon in Safari's toolbar to start watching.",
                "İzlemeye başlamak için Safari araç çubuğundaki Smart IPTV Stream simgesine tıklayın."
            ))
            #else
            step(1, t(
                "Open Settings › Apps › Safari › Extensions.",
                "Ayarlar › Uygulamalar › Safari › Uzantılar'ı açın."
            ))
            step(2, t(
                "Turn “Smart IPTV Stream” on.",
                "“Smart IPTV Stream”i açın."
            ))
            step(3, t(
                "Set All Websites to Allow, so any IPTV server you add can load.",
                "Tüm Web Siteleri iznini “İzin Ver” yapın; böylece eklediğiniz her IPTV sunucusu yüklenebilir."
            ))
            step(4, t(
                "In Safari, tap the extensions button in the address bar and choose Smart IPTV Stream.",
                "Safari'de adres çubuğundaki uzantılar düğmesine dokunup Smart IPTV Stream'i seçin."
            ))
            #endif
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.primary.opacity(0.06), in: RoundedRectangle(cornerRadius: 8))
    }

    private func step(_ number: Int, _ text: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Text("\(number)")
                .font(.caption2).bold()
                .frame(width: 17, height: 17)
                .background(Color.accentColor.opacity(0.3), in: Circle())
            Text(text).font(.caption).foregroundStyle(.secondary)
        }
    }

    @ViewBuilder
    private var accountSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(t("Account", "Hesap")).font(.headline)
            if let account = model.account {
                HStack {
                    Text(account.email).bold()
                    if account.isPro {
                        Text("PRO")
                            .font(.caption).bold()
                            .padding(.horizontal, 7)
                            .padding(.vertical, 2)
                            .background(.green.opacity(0.22), in: Capsule())
                    }
                    Spacer()
                    Button(t("Sign out", "Çıkış")) { model.signOut() }
                        .buttonStyle(.borderless)
                        .foregroundStyle(Color.accentColor)
                }
                if account.isPro {
                    Text(t(
                        "Pro is active on this account everywhere you sign in.",
                        "Pro, giriş yaptığınız her yerde bu hesapta etkin."
                    ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                } else {
                    purchaseControls
                }
            } else {
                Text(t(
                    "Sign in with your Smart IPTV Stream account to buy or restore Pro.",
                    "Pro satın almak veya geri yüklemek için hesabınızla giriş yapın."
                ))
                .font(.callout)
                .foregroundStyle(.secondary)
                credentialFields
                HStack {
                    Button(t("Sign in", "Giriş yap")) {
                        Task { await model.signIn(email: email, password: password) }
                    }
                    .keyboardShortcut(.defaultAction)
                    .disabled(model.busy || email.isEmpty || password.isEmpty)
                    #if os(iOS)
                    // Plain text reads as disabled on iOS; the Mac keeps the
                    // standard push button so it matches the rest of the window.
                    .buttonStyle(.borderedProminent)
                    #endif
                    if model.busy { ProgressView().controlSize(.small) }
                    Spacer()
                    Link(t("Create account", "Hesap oluştur"), destination: websiteURL)
                }
            }
        }
    }

    private var credentialFields: some View {
        Group {
            TextField(t("E-mail", "E-posta"), text: $email)
            SecureField(t("Password", "Şifre"), text: $password)
        }
        #if os(iOS)
        .textFieldStyle(.roundedBorder)
        .textInputAutocapitalization(.never)
        .autocorrectionDisabled()
        .keyboardType(.emailAddress)
        #endif
    }

    private var purchaseControls: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let product = model.product {
                Text(t("Lifetime Pro", "Ömür boyu Pro") + " · " + product.displayPrice)
                    .font(.title3).bold()
                Text(product.description).font(.caption).foregroundStyle(.secondary)
            }
            HStack {
                Button(t("Upgrade to Pro", "Pro'ya geç")) { Task { await model.buy() } }
                    .buttonStyle(.borderedProminent)
                    .disabled(model.busy || model.product == nil)
                Button(t("Restore purchases", "Satın alımları geri yükle")) {
                    Task { await model.restore() }
                }
                .disabled(model.busy)
                if model.busy { ProgressView().controlSize(.small) }
            }
        }
    }
}

/// The app icon, drawn from the running app on macOS and from the bundled copy
/// on iOS (asset-catalog app icons aren't readable there).
private var appIcon: Image {
    #if os(macOS)
    return Image(nsImage: NSApp.applicationIconImage ?? NSImage())
    #else
    let image = Bundle.main.url(forResource: "Icon", withExtension: "png")
        .flatMap { try? Data(contentsOf: $0) }
        .flatMap(UIImage.init(data:))
    return Image(uiImage: image ?? UIImage())
    #endif
}

// MARK: - Hosting

#if os(macOS)

class ViewController: NSViewController {

    // Still declared so the storyboard's outlet binds; the web view is replaced
    // by the SwiftUI interface.
    @IBOutlet var webView: WKWebView!

    override func viewDidLoad() {
        super.viewDidLoad()
        webView?.removeFromSuperview()

        let hosting = NSHostingView(rootView: RootView())
        hosting.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(hosting)
        NSLayoutConstraint.activate([
            hosting.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            hosting.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            hosting.topAnchor.constraint(equalTo: view.topAnchor),
            hosting.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
        preferredContentSize = NSSize(width: 460, height: 580)
    }
}

#else

class ViewController: UIViewController {

    // Storyboard outlet from the converter's template; unused.
    @IBOutlet var webView: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        webView?.removeFromSuperview()

        let hosting = UIHostingController(rootView: RootView())
        addChild(hosting)
        hosting.view.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(hosting.view)
        NSLayoutConstraint.activate([
            hosting.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            hosting.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            hosting.view.topAnchor.constraint(equalTo: view.topAnchor),
            hosting.view.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ])
        hosting.didMove(toParent: self)
    }
}

#endif
