import { create } from "zustand";
import { storage } from "../platform/storage";
import { XtreamClient, XtreamCreds } from "../data/xtream/client";
import { UserData } from "../data/models";
import { M3uEntry } from "../data/m3u/parser";

export type LoginType = "xtream" | "m3u" | "single";

export interface Profile {
  id: string;
  playlistName: string;
  type: LoginType;
  // xtream
  baseUrl?: string;
  username?: string;
  password?: string;
  // m3u / single
  m3uUrl?: string;
  m3uFileName?: string;
  singleStreamUrl?: string;
  createdAt: number;
}

interface SessionState {
  profiles: Profile[];
  activeId: string | null;
  client: XtreamClient | null;
  userData: UserData | null;
  m3uEntries: M3uEntry[];

  addProfile: (p: Omit<Profile, "id" | "createdAt">) => Profile;
  removeProfile: (id: string) => void;
  setActive: (id: string) => void;
  activeProfile: () => Profile | null;
  hydrate: () => void;
  setUserData: (u: UserData | null) => void;
  buildClient: (p: Profile) => XtreamClient | null;
  setM3uEntries: (e: M3uEntry[]) => void;
  logout: () => void;
}

const PROFILES_KEY = "profiles";
const ACTIVE_KEY = "active_profile";

function genId(): string {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export const useSession = create<SessionState>((set, get) => ({
  profiles: [],
  activeId: null,
  client: null,
  userData: null,
  m3uEntries: [],

  hydrate: () => {
    const profiles = storage.get<Profile[]>(PROFILES_KEY, []);
    const activeId = storage.getString(ACTIVE_KEY) || null;
    let client: XtreamClient | null = null;
    const active = profiles.find((p) => p.id === activeId) || null;
    if (active) client = get().buildClient(active);
    set({ profiles, activeId, client });
  },

  buildClient: (p) => {
    if (p.type === "xtream" && p.baseUrl && p.username && p.password) {
      const creds: XtreamCreds = {
        baseUrl: p.baseUrl,
        username: p.username,
        password: p.password,
      };
      return new XtreamClient(creds);
    }
    return null;
  },

  addProfile: (p) => {
    const profile: Profile = { ...p, id: genId(), createdAt: Date.now() };
    const profiles = [...get().profiles, profile];
    storage.set(PROFILES_KEY, profiles);
    set({ profiles });
    return profile;
  },

  removeProfile: (id) => {
    const profiles = get().profiles.filter((p) => p.id !== id);
    storage.set(PROFILES_KEY, profiles);
    const patch: Partial<SessionState> = { profiles };
    if (get().activeId === id) {
      patch.activeId = null;
      patch.client = null;
      patch.userData = null;
      storage.remove(ACTIVE_KEY);
    }
    set(patch);
  },

  setActive: (id) => {
    const p = get().profiles.find((x) => x.id === id) || null;
    storage.setString(ACTIVE_KEY, id);
    set({ activeId: id, client: p ? get().buildClient(p) : null, userData: null });
  },

  activeProfile: () => {
    const { profiles, activeId } = get();
    return profiles.find((p) => p.id === activeId) || null;
  },

  setUserData: (u) => set({ userData: u }),
  setM3uEntries: (e) => set({ m3uEntries: e }),

  logout: () => {
    storage.remove(ACTIVE_KEY);
    set({ activeId: null, client: null, userData: null, m3uEntries: [] });
  },
}));
