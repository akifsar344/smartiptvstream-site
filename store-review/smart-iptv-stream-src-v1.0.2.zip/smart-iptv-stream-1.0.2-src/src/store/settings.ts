import { create } from "zustand";
import { storage } from "../platform/storage";

export type StreamFormat = "m3u8" | "ts" | "default";

interface SettingsState {
  streamFormat: StreamFormat;
  showOnlyEpgChannels: boolean;
  epgTimeShift: number;
  autoUpdate: boolean;
  autoUpdateEpg: boolean;
  parentalPin: string | null;
  lockedCategories: string[];
  /** Display clocks in 24-hour format when true, 12-hour (AM/PM) when false. */
  hour24: boolean;

  setStreamFormat: (f: StreamFormat) => void;
  setShowOnlyEpg: (v: boolean) => void;
  setEpgTimeShift: (h: number) => void;
  setAutoUpdate: (v: boolean) => void;
  setAutoUpdateEpg: (v: boolean) => void;
  setPin: (pin: string | null) => void;
  toggleLockCategory: (id: string) => void;
  isLocked: (id: string) => boolean;
  setHour24: (v: boolean) => void;
}

const K = {
  format: "stream_format",
  epgOnly: "show_only_epg",
  shift: "epg_time_shift",
  auto: "auto_update",
  autoEpg: "auto_update_epg",
  pin: "parental_pin",
  locked: "locked_categories",
  hour24: "clock_hour24",
};

export const useSettings = create<SettingsState>((set, get) => ({
  // Default to raw .ts: on webOS TVs the native hardware decoder handles
  // continuous MPEG-TS (and HEVC/AC3) far more smoothly than hls.js/MSE,
  // which noticeably reduces live-channel stuttering out of the box.
  streamFormat: storage.get<StreamFormat>(K.format, "ts"),
  showOnlyEpgChannels: storage.get<boolean>(K.epgOnly, false),
  epgTimeShift: storage.get<number>(K.shift, 0),
  autoUpdate: storage.get<boolean>(K.auto, false),
  autoUpdateEpg: storage.get<boolean>(K.autoEpg, false),
  parentalPin: storage.get<string | null>(K.pin, null),
  lockedCategories: storage.get<string[]>(K.locked, []),
  hour24: storage.get<boolean>(K.hour24, true),

  setStreamFormat: (f) => {
    storage.set(K.format, f);
    set({ streamFormat: f });
  },
  setShowOnlyEpg: (v) => {
    storage.set(K.epgOnly, v);
    set({ showOnlyEpgChannels: v });
  },
  setEpgTimeShift: (h) => {
    storage.set(K.shift, h);
    set({ epgTimeShift: h });
  },
  setAutoUpdate: (v) => {
    storage.set(K.auto, v);
    set({ autoUpdate: v });
  },
  setAutoUpdateEpg: (v) => {
    storage.set(K.autoEpg, v);
    set({ autoUpdateEpg: v });
  },
  setPin: (pin) => {
    storage.set(K.pin, pin);
    set({ parentalPin: pin });
  },
  toggleLockCategory: (id) => {
    const cur = get().lockedCategories;
    const next = cur.includes(id)
      ? cur.filter((x) => x !== id)
      : [...cur, id];
    storage.set(K.locked, next);
    set({ lockedCategories: next });
  },
  isLocked: (id) => get().lockedCategories.includes(id),
  setHour24: (v) => {
    storage.set(K.hour24, v);
    set({ hour24: v });
  },
}));
