import { create } from "zustand";
import { storage } from "../platform/storage";
import {
  osRestLogin,
  osRestUserInfo,
  OS_CONSUMER_API_KEY,
} from "../data/subtitles/opensubtitlesRest";

interface OsAuthState {
  /**
   * Consumer Api-Key that identifies the app to OpenSubtitles. Baked into the
   * build (same for everyone) — the user never enters this.
   */
  apiKey: string;
  token: string;
  baseUrl: string;
  username: string;
  vip: boolean;
  allowedDownloads: number;
  loggedIn: boolean;
  loading: boolean;
  error: string;
  login: (username: string, password: string) => Promise<boolean>;
  refreshUser: () => Promise<void>;
  logout: () => void;
}

const K = {
  token: "opensubtitles_token",
  base: "opensubtitles_base",
  user: "opensubtitles_username",
};

// The consumer Api-Key ships with the app. Users only sign in with their own
// OpenSubtitles account, and we restore that session from whatever was saved.
const savedToken = storage.getString(K.token) || "";
const savedBase = storage.getString(K.base) || "api.opensubtitles.com";
const savedUser = storage.getString(K.user) || "";

export const useOpenSubtitles = create<OsAuthState>((set, get) => ({
  apiKey: OS_CONSUMER_API_KEY,
  token: savedToken,
  baseUrl: savedBase,
  username: savedUser,
  vip: false,
  allowedDownloads: 0,
  loggedIn: !!savedToken && !!savedUser,
  loading: false,
  error: "",

  login: async (username, password) => {
    const apiKey = get().apiKey;
    set({ loading: true, error: "" });
    try {
      const sess = await osRestLogin(apiKey, username, password);
      storage.setString(K.token, sess.token);
      storage.setString(K.base, sess.baseUrl);
      storage.setString(K.user, username.trim());
      set({
        token: sess.token,
        baseUrl: sess.baseUrl,
        username: username.trim(),
        vip: sess.user.vip,
        allowedDownloads: sess.user.allowedDownloads,
        loggedIn: true,
        loading: false,
        error: "",
      });
      return true;
    } catch (e) {
      set({ loading: false, error: e instanceof Error ? e.message : String(e) });
      return false;
    }
  },

  refreshUser: async () => {
    const { apiKey, token, baseUrl } = get();
    if (!apiKey || !token) return;
    try {
      const u = await osRestUserInfo(apiKey, token, baseUrl);
      if (u) {
        set({ vip: u.vip, allowedDownloads: u.allowedDownloads, loggedIn: true });
      } else {
        // Token invalid/expired → drop it so the UI prompts a fresh login.
        storage.remove(K.token);
        set({ token: "", loggedIn: false });
      }
    } catch {
      /* keep current state on transient network errors */
    }
  },

  logout: () => {
    storage.remove(K.token);
    storage.remove(K.base);
    storage.remove(K.user);
    set({ token: "", username: "", vip: false, allowedDownloads: 0, loggedIn: false, error: "" });
  },
}));

// On load: if the user previously signed in, validate the saved token and pull
// live VIP/quota. Expired/invalid tokens are dropped so the UI prompts a fresh
// login. No baked-in credentials → no auto-login.
if (useOpenSubtitles.getState().loggedIn) {
  void useOpenSubtitles.getState().refreshUser();
}
