import { create } from "zustand";
import { storage } from "../platform/storage";
import { useSession } from "./session";
import { useFavorites } from "./favorites";
import { useResume } from "./resume";

// Per-user isolated data for the Live TV experience (and shared parental PIN).
// Everything is keyed by a stable "scope" derived from the active profile so
// that multiple accounts never mix data, and a future backup system can export
// the whole `ud:{scope}` blob per user.

export function userScope(): string {
  const p = useSession.getState().activeProfile();
  if (!p) return "default";
  if (p.type === "m3u") return `m3u:${p.m3uUrl || p.m3uFileName || p.id}`;
  if (p.type === "single") return `single:${p.id}`;
  if (p.username) return `xt:${p.username}@${p.baseUrl || ""}`;
  return `p:${p.id}`;
}

interface PersistedUserData {
  liveFav: number[];
  liveRecent: number[];
  lockedCats: string[];
  lockedChannels: string[];
  catRenames: Record<string, string>;
  channelRenames: Record<string, string>;
  pin: string | null;
}

function emptyData(): PersistedUserData {
  return {
    liveFav: [],
    liveRecent: [],
    lockedCats: [],
    lockedChannels: [],
    catRenames: {},
    channelRenames: {},
    pin: null,
  };
}

const MAX_RECENT = 50;
const keyFor = (scope: string) => `ud:${scope}`;

interface UserDataState extends PersistedUserData {
  scope: string;
  reload: () => void;

  // Favourites (live)
  isLiveFav: (streamId: number) => boolean;
  toggleLiveFav: (streamId: number) => void;
  clearLiveFav: () => void;

  // Recently watched (live)
  pushRecent: (streamId: number) => void;
  clearRecent: () => void;

  // Category parental lock
  isCatLocked: (categoryId: string) => boolean;
  toggleCatLock: (categoryId: string) => void;

  // Channel parental lock
  isChannelLocked: (streamId: number) => boolean;
  toggleChannelLock: (streamId: number) => void;

  // Renames
  catName: (categoryId: string, fallback: string) => string;
  renameCat: (categoryId: string, name: string) => void;
  channelName: (streamId: number, fallback: string) => string;
  renameChannel: (streamId: number, name: string) => void;

  // Generic item lock / rename (movies & series posters), keyed by a caller
  // supplied namespaced string e.g. "movie:123" / "series:45" so they never
  // collide with Live TV channel ids. Reuses the same persisted storage.
  isItemLocked: (key: string) => boolean;
  toggleItemLock: (key: string) => void;
  itemName: (key: string, fallback: string) => string;
  renameItem: (key: string, name: string) => void;

  // Parental PIN (per user)
  setPin: (pin: string | null) => void;
  // Clears the PIN AND every category/channel/item lock in one step.
  removeParental: () => void;
}

export const useUserData = create<UserDataState>((set, get) => {
  const persist = () => {
    const s = get();
    const data: PersistedUserData = {
      liveFav: s.liveFav,
      liveRecent: s.liveRecent,
      lockedCats: s.lockedCats,
      lockedChannels: s.lockedChannels,
      catRenames: s.catRenames,
      channelRenames: s.channelRenames,
      pin: s.pin,
    };
    storage.set(keyFor(s.scope), data);
  };

  return {
    scope: "default",
    ...emptyData(),

    reload: () => {
      const scope = userScope();
      const data = storage.get<PersistedUserData>(keyFor(scope), emptyData());
      set({ scope, ...emptyData(), ...data });
    },

    isLiveFav: (id) => get().liveFav.includes(id),
    toggleLiveFav: (id) => {
      const cur = get().liveFav;
      const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
      set({ liveFav: next });
      persist();
    },
    clearLiveFav: () => {
      set({ liveFav: [] });
      persist();
    },

    pushRecent: (id) => {
      const cur = get().liveRecent.filter((x) => x !== id);
      const next = [id, ...cur].slice(0, MAX_RECENT);
      set({ liveRecent: next });
      persist();
    },
    clearRecent: () => {
      set({ liveRecent: [] });
      persist();
    },

    isCatLocked: (cid) => get().lockedCats.includes(cid),
    toggleCatLock: (cid) => {
      const cur = get().lockedCats;
      const next = cur.includes(cid) ? cur.filter((x) => x !== cid) : [...cur, cid];
      set({ lockedCats: next });
      persist();
    },

    isChannelLocked: (id) => get().lockedChannels.includes(String(id)),
    toggleChannelLock: (id) => {
      const key = String(id);
      const cur = get().lockedChannels;
      const next = cur.includes(key) ? cur.filter((x) => x !== key) : [...cur, key];
      set({ lockedChannels: next });
      persist();
    },

    catName: (cid, fallback) => get().catRenames[cid] ?? fallback,
    renameCat: (cid, name) => {
      const next = { ...get().catRenames };
      if (name.trim()) next[cid] = name.trim();
      else delete next[cid];
      set({ catRenames: next });
      persist();
    },
    channelName: (id, fallback) => get().channelRenames[String(id)] ?? fallback,
    renameChannel: (id, name) => {
      const next = { ...get().channelRenames };
      if (name.trim()) next[String(id)] = name.trim();
      else delete next[String(id)];
      set({ channelRenames: next });
      persist();
    },

    isItemLocked: (key) => get().lockedChannels.includes(key),
    toggleItemLock: (key) => {
      const cur = get().lockedChannels;
      const next = cur.includes(key) ? cur.filter((x) => x !== key) : [...cur, key];
      set({ lockedChannels: next });
      persist();
    },
    itemName: (key, fallback) => get().channelRenames[key] ?? fallback,
    renameItem: (key, name) => {
      const next = { ...get().channelRenames };
      if (name.trim()) next[key] = name.trim();
      else delete next[key];
      set({ channelRenames: next });
      persist();
    },

    setPin: (pin) => {
      set({ pin });
      persist();
    },

    removeParental: () => {
      set({ pin: null, lockedCats: [], lockedChannels: [] });
      persist();
    },
  };
});

// Reload every per-user scoped store whenever the active profile changes.
let lastScope = "";
export function syncUserScope(force = false) {
  const s = userScope();
  if (force || s !== lastScope) {
    lastScope = s;
    useUserData.getState().reload();
    useFavorites.getState().reload(s);
    useResume.getState().reload(s);
  }
}
useSession.subscribe(() => syncUserScope());
