import { create } from "zustand";
import {
  Category,
  LiveStream,
  MovieStream,
  SeriesStream,
} from "../data/models";
import { useSession } from "./session";
import { userScope } from "./userdata";
import { diskCache } from "../platform/diskCache";
import { storage } from "../platform/storage";
import { parseM3u } from "../data/m3u/parser";
import { buildM3uCatalog } from "../data/m3u/catalog";

// Refresh from the API every Nth time the catalog is opened; in between we
// serve the per-user disk cache instantly so the app feels "rocket fast".
const REFRESH_EVERY = 5;
const CACHE_VERSION = 2;

interface CachedCatalog {
  v: number;
  savedAt: number;
  liveCategories: Category[];
  liveStreams: LiveStream[];
  movieCategories: Category[];
  movieStreams: MovieStream[];
  seriesCategories: Category[];
  seriesStreams: SeriesStream[];
  // M3U-only: raw series_info payloads keyed by synthetic seriesId.
  seriesInfo?: Record<number, any>;
}

interface CatalogState {
  liveCategories: Category[];
  movieCategories: Category[];
  seriesCategories: Category[];
  liveStreams: LiveStream[];
  movieStreams: MovieStream[];
  seriesStreams: SeriesStream[];
  // M3U-only: raw series_info payloads keyed by synthetic seriesId, consumed by
  // SeriesDetailScreen when there is no Xtream client.
  m3uSeriesInfo: Record<number, any>;

  loadingLive: boolean;
  loadingMovies: boolean;
  loadingSeries: boolean;
  loaded: boolean;
  refreshing: boolean;

  /** Cache-aware loader: instant from disk, refreshes from API as needed. */
  loadForScope: (force?: boolean) => Promise<void>;
  fetchAll: () => Promise<void>;
  fetchLive: () => Promise<void>;
  fetchMovies: () => Promise<void>;
  fetchSeries: () => Promise<void>;
  fetchM3u: () => Promise<void>;
  clear: () => void;
}

let lastScope: string | null = null;

export const useCatalog = create<CatalogState>((set, get) => ({
  liveCategories: [],
  movieCategories: [],
  seriesCategories: [],
  liveStreams: [],
  movieStreams: [],
  seriesStreams: [],
  m3uSeriesInfo: {},
  loadingLive: false,
  loadingMovies: false,
  loadingSeries: false,
  loaded: false,
  refreshing: false,

  loadForScope: async (force = false) => {
    const scope = userScope();
    const cacheKey = `catalog:${scope}`;
    const openKey = `catalog_open:${scope}`;

    // Switching users: drop the previous user's in-memory catalog.
    if (lastScope !== scope) {
      get().clear();
      lastScope = scope;
    }

    const opens = storage.get<number>(openKey, 0);
    let cached: CachedCatalog | null = null;
    if (!force) {
      const c = await diskCache.get<CachedCatalog>(cacheKey);
      if (c && c.v === CACHE_VERSION) cached = c;
    }

    if (cached) {
      set({
        liveCategories: cached.liveCategories || [],
        liveStreams: cached.liveStreams || [],
        movieCategories: cached.movieCategories || [],
        movieStreams: cached.movieStreams || [],
        seriesCategories: cached.seriesCategories || [],
        seriesStreams: cached.seriesStreams || [],
        m3uSeriesInfo: cached.seriesInfo || {},
        loaded: true,
      });
    }

    storage.set(openKey, opens + 1);
    const mustRefresh = force || !cached || opens % REFRESH_EVERY === 0;

    if (!cached) {
      // No cache yet (first login for this user): fetch and persist, blocking.
      await get().fetchAll();
      await saveCatalogCache(scope, get());
    } else if (mustRefresh) {
      // We already showed the cache instantly; refresh in the background.
      set({ refreshing: true });
      get()
        .fetchAll()
        .then(() => saveCatalogCache(scope, get()))
        .catch(() => {})
        .finally(() => set({ refreshing: false }));
    }
  },

  // Each section fetches independently and soft-fails (empty list) so a single
  // flaky endpoint never blocks login or crashes the catalog. Categories and
  // streams are also fetched independently for the same reason.
  fetchLive: async () => {
    const client = useSession.getState().client;
    if (!client) return;
    set({ loadingLive: true });
    try {
      const [cats, streams] = await Promise.all([
        client.getLiveCategories().catch(() => [] as Category[]),
        client.getLiveStreams().catch(() => [] as LiveStream[]),
      ]);
      set({ liveCategories: cats, liveStreams: streams });
    } catch {
      /* keep whatever we have */
    } finally {
      set({ loadingLive: false });
    }
  },

  fetchMovies: async () => {
    const client = useSession.getState().client;
    if (!client) return;
    set({ loadingMovies: true });
    try {
      const [cats, streams] = await Promise.all([
        client.getVodCategories().catch(() => [] as Category[]),
        client.getVodStreams().catch(() => [] as MovieStream[]),
      ]);
      set({ movieCategories: cats, movieStreams: streams });
    } catch {
      /* keep whatever we have */
    } finally {
      set({ loadingMovies: false });
    }
  },

  fetchSeries: async () => {
    const client = useSession.getState().client;
    if (!client) return;
    set({ loadingSeries: true });
    try {
      const [cats, streams] = await Promise.all([
        client.getSeriesCategories().catch(() => [] as Category[]),
        client.getSeries().catch(() => [] as SeriesStream[]),
      ]);
      set({ seriesCategories: cats, seriesStreams: streams });
    } catch {
      /* keep whatever we have */
    } finally {
      set({ loadingSeries: false });
    }
  },

  // Fetch + parse the M3U playlist and project it into the catalog shape. Soft-
  // fails so a bad/temporary URL never wipes a previously cached catalog.
  fetchM3u: async () => {
    const profile = useSession.getState().activeProfile();
    const url = profile?.m3uUrl;
    if (!url) return;
    set({ loadingLive: true, loadingMovies: true, loadingSeries: true });
    try {
      const res = await fetch(url);
      const text = await res.text();
      const cat = buildM3uCatalog(parseM3u(text));
      const empty =
        !cat.liveStreams.length && !cat.movieStreams.length && !cat.seriesStreams.length;
      if (empty) return; // keep whatever cache we already have
      set({
        liveCategories: cat.liveCategories,
        liveStreams: cat.liveStreams,
        movieCategories: cat.movieCategories,
        movieStreams: cat.movieStreams,
        seriesCategories: cat.seriesCategories,
        seriesStreams: cat.seriesStreams,
        m3uSeriesInfo: cat.seriesInfo,
      });
    } catch {
      /* keep whatever we have */
    } finally {
      set({ loadingLive: false, loadingMovies: false, loadingSeries: false });
    }
  },

  fetchAll: async () => {
    // Never reject, so login can always proceed to the dashboard even if a
    // single section (e.g. movies/series) endpoint is flaky.
    const noop = () => {};
    // M3U profiles have no Xtream client; build the catalog from the playlist.
    if (useSession.getState().activeProfile()?.type === "m3u") {
      await get().fetchM3u().catch(noop);
      set({ loaded: true });
      return;
    }
    await Promise.all([
      get().fetchLive().catch(noop),
      get().fetchMovies().catch(noop),
      get().fetchSeries().catch(noop),
    ]);
    set({ loaded: true });
  },

  clear: () =>
    set({
      liveCategories: [],
      movieCategories: [],
      seriesCategories: [],
      liveStreams: [],
      movieStreams: [],
      seriesStreams: [],
      m3uSeriesInfo: {},
      loaded: false,
    }),
}));

// Persist the current catalog to the per-user disk cache. Skips writing when
// everything is empty so a failed refresh never wipes a good cache.
async function saveCatalogCache(
  scope: string,
  s: Pick<
    CatalogState,
    | "liveCategories"
    | "liveStreams"
    | "movieCategories"
    | "movieStreams"
    | "seriesCategories"
    | "seriesStreams"
    | "m3uSeriesInfo"
  >
): Promise<void> {
  const empty =
    !s.liveCategories.length &&
    !s.liveStreams.length &&
    !s.movieCategories.length &&
    !s.movieStreams.length &&
    !s.seriesCategories.length &&
    !s.seriesStreams.length;
  if (empty) return;
  const payload: CachedCatalog = {
    v: CACHE_VERSION,
    savedAt: Date.now(),
    liveCategories: s.liveCategories,
    liveStreams: s.liveStreams,
    movieCategories: s.movieCategories,
    movieStreams: s.movieStreams,
    seriesCategories: s.seriesCategories,
    seriesStreams: s.seriesStreams,
    seriesInfo: s.m3uSeriesInfo,
  };
  await diskCache.set(`catalog:${scope}`, payload);
}
