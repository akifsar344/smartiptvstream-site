import { create } from "zustand";
import { storage } from "../platform/storage";
import { useAuth } from "./auth";
import { AccessView } from "../data/api/backend";

// Web entitlement gate. Unlike the TV build (device-based license), Pro and the
// 24h trial are now tied to the logged-in ACCOUNT and are server-authoritative:
// the backend records trial_started_at per user and the Cleeng webhook flips
// `pro`. This store simply mirrors the auth store's access view and derives the
// paywall `blocked` flag, re-evaluating it on a timer so the trial expires live.

const K = { rated: "access.rated" };

interface AccessState {
  initialized: boolean;
  isPro: boolean;
  plan: string | null;
  status: string;
  trialEndsAt: number;
  blocked: boolean;
  ratePending: boolean;
  // Set once right after the account flips to Pro so Home can prompt a one-time
  // catalog refresh (the in-memory catalog can be stale/empty at that moment).
  refreshPending: boolean;

  init: () => Promise<void>;
  refresh: () => Promise<boolean>;
  recompute: () => void;
  trialRemainingMs: () => number;
  consumeRate: () => void;
  markRated: () => void;
  consumeRefresh: () => void;
}

let ticker: ReturnType<typeof setInterval> | null = null;
let subscribed = false;

export const useAccess = create<AccessState>((set, get) => {
  const applyFromAuth = (access: AccessView | null) => {
    if (!access) {
      set({ initialized: true, isPro: false, plan: null, status: "unknown", trialEndsAt: 0 });
      get().recompute();
      return;
    }
    const wasPro = get().isPro;
    const becamePro = access.isPro && !wasPro;
    const alreadyRated = storage.get<boolean>(K.rated, false);
    set({
      initialized: true,
      isPro: access.isPro,
      plan: access.plan,
      status: access.status,
      trialEndsAt: access.trialEndsAt,
      ratePending: becamePro && !alreadyRated ? true : get().ratePending,
      refreshPending: becamePro ? true : get().refreshPending,
    });
    get().recompute();
  };

  return {
    initialized: false,
    isPro: false,
    plan: null,
    status: "unknown",
    trialEndsAt: 0,
    blocked: false,
    ratePending: false,
    refreshPending: false,

    init: async () => {
      applyFromAuth(useAuth.getState().access);
      if (!subscribed) {
        subscribed = true;
        useAuth.subscribe((s) => applyFromAuth(s.access));
      }
      if (!ticker) ticker = setInterval(() => get().recompute(), 20_000);
    },

    refresh: async () => {
      const access = await useAuth.getState().refreshAccess();
      applyFromAuth(access);
      return get().isPro;
    },

    recompute: () => {
      const { initialized, isPro, trialEndsAt } = get();
      const blocked = initialized && !isPro && Date.now() >= trialEndsAt;
      if (blocked !== get().blocked) set({ blocked });
    },

    trialRemainingMs: () => Math.max(0, get().trialEndsAt - Date.now()),

    consumeRate: () => set({ ratePending: false }),

    markRated: () => {
      storage.set(K.rated, true);
      set({ ratePending: false });
    },

    consumeRefresh: () => set({ refreshPending: false }),
  };
});
