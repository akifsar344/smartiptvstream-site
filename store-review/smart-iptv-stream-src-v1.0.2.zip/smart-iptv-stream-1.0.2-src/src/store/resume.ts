import { create } from "zustand";
import { storage } from "../platform/storage";

export type ResumeKind = "movie" | "series" | "live";

export interface ResumeItem {
  kind: ResumeKind;
  id: number; // stream id (movie/live) or episode id (series)
  seriesId?: number;
  name: string;
  icon: string;
  positionSec: number;
  durationSec: number;
  updatedAt: number;
  containerExtension?: string;
  // Direct playback URL (M3U only) so the item can be re-opened without an
  // Xtream client; Xtream items leave this empty and rebuild from the id.
  url?: string;
}

interface ResumeState {
  scope: string;
  items: ResumeItem[];
  reload: (scope: string) => void;
  save: (item: ResumeItem) => void;
  remove: (kind: ResumeKind, id: number) => void;
  get: (kind: ResumeKind, id: number) => ResumeItem | undefined;
  list: (limit?: number) => ResumeItem[];
  byKind: (kind: ResumeKind) => ResumeItem[];
  clearKind: (kind: ResumeKind) => void;
}

// Per-user scoped continue-watching history.
const keyFor = (scope: string) => `continue_watching:${scope}`;
const MAX = 30;

export const useResume = create<ResumeState>((set, get) => ({
  scope: "default",
  items: storage.get<ResumeItem[]>(keyFor("default"), []),

  reload: (scope) => {
    set({ scope, items: storage.get<ResumeItem[]>(keyFor(scope), []) });
  },

  save: (item) => {
    const filtered = get().items.filter(
      (x) => !(x.kind === item.kind && x.id === item.id)
    );
    let items = filtered;
    if (item.kind === "live") {
      // Live channels have no progress; we just track "recently opened" so the
      // Continue Watching Live TV tab can re-open them.
      items = [{ ...item, updatedAt: Date.now() }, ...filtered];
    } else {
      // Drop near-complete items so they don't clutter Continue Watching.
      // Duration may be unknown (0) for some streams; in that case we still keep
      // the item (ratio 0) so it shows up — just without a progress bar.
      const ratio = item.durationSec > 0 ? item.positionSec / item.durationSec : 0;
      if (ratio < 0.95 && item.positionSec > 5) {
        items = [{ ...item, updatedAt: Date.now() }, ...filtered];
      }
    }
    items = items
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .slice(0, MAX);
    storage.set(keyFor(get().scope), items);
    set({ items });
  },

  remove: (kind, id) => {
    const items = get().items.filter(
      (x) => !(x.kind === kind && x.id === id)
    );
    storage.set(keyFor(get().scope), items);
    set({ items });
  },

  get: (kind, id) =>
    get().items.find((x) => x.kind === kind && x.id === id),

  list: (limit) => {
    const sorted = [...get().items].sort((a, b) => b.updatedAt - a.updatedAt);
    return limit ? sorted.slice(0, limit) : sorted;
  },

  byKind: (kind) =>
    [...get().items]
      .filter((x) => x.kind === kind)
      .sort((a, b) => b.updatedAt - a.updatedAt),

  clearKind: (kind) => {
    const items = get().items.filter((x) => x.kind !== kind);
    storage.set(keyFor(get().scope), items);
    set({ items });
  },
}));
