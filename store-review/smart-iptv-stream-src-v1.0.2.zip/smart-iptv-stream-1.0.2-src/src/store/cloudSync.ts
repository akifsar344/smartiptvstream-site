import { storage } from "../platform/storage";
import { backend } from "../data/api/backend";
import { useSession } from "./session";
import { syncUserScope } from "./userdata";

// Mirrors the whole `sis:` localStorage namespace to the logged-in account so a
// user's profiles, favourites, resume list, PIN and settings follow them across
// devices. localStorage stays the fast local cache; the server is the backup.

let token: string | null = null;
let unsub: (() => void) | null = null;
let timer: ReturnType<typeof setTimeout> | null = null;
const DEBOUNCE_MS = 1500;

function schedulePush() {
  if (!token) return;
  if (timer) clearTimeout(timer);
  timer = setTimeout(pushNow, DEBOUNCE_MS);
}

async function pushNow() {
  if (!token) return;
  timer = null;
  try {
    await backend.putData(token, storage.exportAll());
  } catch {
    // Offline / transient — the next change reschedules a push. Local cache is
    // still intact, so no data is lost.
  }
}

/** Pulls the account's saved blob into localStorage and re-hydrates the stores. */
export async function hydrateFromCloud(t: string): Promise<void> {
  try {
    const { data } = await backend.getData(t);
    if (data && typeof data === "object") {
      storage.importAll(data as Record<string, unknown>);
      // Re-read the local session + per-user scoped stores from the fresh cache.
      useSession.getState().hydrate();
      syncUserScope(true);
    }
  } catch {
    // No cloud data yet or offline: keep whatever is in the local cache.
  }
}

/** Begins mirroring local changes to the account (debounced). */
export function startCloudSync(t: string): void {
  token = t;
  if (!unsub) unsub = storage.onChange(schedulePush);
}

/** Stops syncing and flushes any pending change immediately. */
export function stopCloudSync(): void {
  if (timer) {
    clearTimeout(timer);
    timer = null;
  }
  if (unsub) {
    unsub();
    unsub = null;
  }
  token = null;
}
