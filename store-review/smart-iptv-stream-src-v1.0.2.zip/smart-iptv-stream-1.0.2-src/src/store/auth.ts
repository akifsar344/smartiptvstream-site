import { create } from "zustand";
import { backend, AccessView, ApiError } from "../data/api/backend";
import { storage } from "../platform/storage";
import { useSession } from "./session";
import { syncUserScope } from "./userdata";
import { hydrateFromCloud, startCloudSync, stopCloudSync } from "./cloudSync";

// Account layer for the web build. The auth token is kept OUTSIDE the `sis:`
// namespace so clearing user data on logout never touches the session token.
const TOKEN_KEY = "auth.token";

function readToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}
function writeToken(t: string | null) {
  try {
    if (t) localStorage.setItem(TOKEN_KEY, t);
    else localStorage.removeItem(TOKEN_KEY);
  } catch {
    /* noop */
  }
}

export type AuthStatus = "loading" | "anon" | "authed";

interface AuthState {
  status: AuthStatus;
  token: string | null;
  email: string | null;
  access: AccessView | null;

  init: () => Promise<void>;
  signup: (email: string, password: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  loginWithExtensionHandoff: (code: string) => Promise<void>;
  logout: () => void;
  refreshAccess: () => Promise<AccessView | null>;
  setAccess: (a: AccessView) => void;
}

async function enterSession(t: string, access: AccessView, set: (p: Partial<AuthState>) => void) {
  writeToken(t);
  await hydrateFromCloud(t);
  startCloudSync(t);
  set({ status: "authed", token: t, email: access.email, access });
}

export const useAuth = create<AuthState>((set, get) => ({
  status: "loading",
  token: null,
  email: null,
  access: null,

  init: async () => {
    const t = readToken();
    if (!t) {
      set({ status: "anon" });
      return;
    }
    try {
      const { access } = await backend.me(t);
      await enterSession(t, access, set);
    } catch (e) {
      if (e instanceof ApiError && e.httpStatus === 401) {
        writeToken(null);
        set({ status: "anon", token: null, email: null, access: null });
      } else {
        // Network error but we have a token — enter offline with cached local data.
        startCloudSync(t);
        set({ status: "authed", token: t });
      }
    }
  },

  signup: async (email, password) => {
    const { token, access } = await backend.signup(email, password);
    await enterSession(token, access, set);
  },

  login: async (email, password) => {
    const { token, access } = await backend.login(email, password);
    await enterSession(token, access, set);
  },

  loginWithExtensionHandoff: async (code) => {
    // A website handoff intentionally replaces any different account currently
    // open in the extension, so playback and Pro entitlement match the web user.
    stopCloudSync();
    const { token, access } = await backend.redeemExtensionHandoff(code);
    await enterSession(token, access, set);
  },

  logout: () => {
    stopCloudSync();
    writeToken(null);
    storage.clearAll();
    useSession.getState().logout();
    syncUserScope(true);
    set({ status: "anon", token: null, email: null, access: null });
  },

  refreshAccess: async () => {
    const t = get().token;
    if (!t) return null;
    try {
      const { access } = await backend.me(t);
      set({ access, email: access.email });
      return access;
    } catch {
      return get().access;
    }
  },

  setAccess: (a) => set({ access: a }),
}));
