import { create } from "zustand";
import { storage } from "../platform/storage";

export type FavKind = "live" | "movie" | "series";

export interface FavItem {
  kind: FavKind;
  id: number;
  name: string;
  icon: string;
}

interface FavState {
  scope: string;
  items: FavItem[];
  reload: (scope: string) => void;
  toggle: (item: FavItem) => void;
  has: (kind: FavKind, id: number) => boolean;
  byKind: (kind: FavKind) => FavItem[];
  clearKind: (kind: FavKind) => void;
}

// Per-user scoped so multiple accounts don't share favourites.
const keyFor = (scope: string) => `favorites:${scope}`;

export const useFavorites = create<FavState>((set, get) => ({
  scope: "default",
  items: storage.get<FavItem[]>(keyFor("default"), []),
  reload: (scope) => {
    set({ scope, items: storage.get<FavItem[]>(keyFor(scope), []) });
  },
  toggle: (item) => {
    const exists = get().items.some(
      (x) => x.kind === item.kind && x.id === item.id
    );
    const items = exists
      ? get().items.filter((x) => !(x.kind === item.kind && x.id === item.id))
      : [...get().items, item];
    storage.set(keyFor(get().scope), items);
    set({ items });
  },
  has: (kind, id) => get().items.some((x) => x.kind === kind && x.id === id),
  byKind: (kind) => get().items.filter((x) => x.kind === kind),
  clearKind: (kind) => {
    const items = get().items.filter((x) => x.kind !== kind);
    storage.set(keyFor(get().scope), items);
    set({ items });
  },
}));
