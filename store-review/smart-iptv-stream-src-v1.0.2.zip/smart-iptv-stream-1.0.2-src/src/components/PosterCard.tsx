import { useFocusable } from "../navigation/useFocusable";
import { Icon } from "./Icon";
import { colors } from "../styles/theme";

export function PosterCard({
  title,
  image,
  rating,
  onTap,
  focusKey,
  autoFocus,
  width = 168,
  height = 252,
}: {
  title: string;
  image?: string;
  rating?: string;
  onTap: () => void;
  focusKey?: string;
  autoFocus?: boolean;
  width?: number;
  height?: number;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey,
    onEnter: onTap,
    autoFocus,
  });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        width,
        display: "flex",
        flexDirection: "column",
        cursor: "pointer",
        transform: focused ? "scale(1.07)" : "scale(1)",
        zIndex: focused ? 5 : 1,
      }}
    >
      <div
        style={{
          width,
          height,
          borderRadius: 12,
          overflow: "hidden",
          background: "rgba(255,255,255,0.06)",
          border: focused ? "3px solid #fff" : "1px solid rgba(255,255,255,0.1)",
          boxShadow: focused ? `0 0 26px ${colors.btn}` : "0 6px 14px rgba(0,0,0,0.4)",
          position: "relative",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {image ? (
          <img
            src={image}
            alt={title}
            loading="lazy"
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
            onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
          />
        ) : (
          <Icon name="movie" size={48} color="rgba(255,255,255,0.3)" />
        )}
        {rating && Number(rating) > 0 && (
          <div
            style={{
              position: "absolute",
              top: 8,
              left: 8,
              padding: "2px 8px",
              borderRadius: 6,
              background: "rgba(0,0,0,0.7)",
              fontSize: 12,
              fontWeight: 700,
              display: "flex",
              alignItems: "center",
              gap: 3,
            }}
          >
            <Icon name="star" size={12} color="#FFB300" />
            {Number(rating).toFixed(1)}
          </div>
        )}
      </div>
      <span
        style={{
          marginTop: 8,
          fontSize: 13,
          fontWeight: 600,
          color: focused ? "#fff" : "rgba(255,255,255,0.8)",
          textAlign: "center",
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
        }}
      >
        {title}
      </span>
    </div>
  );
}
