import { useEffect } from "react";
import { useT } from "../i18n/I18nProvider";
import { attemptLandscapeLock } from "../platform/useViewport";

// Full-screen prompt shown on touch phones held in portrait once the user is
// inside the (landscape-only) TV UI. It also makes a best-effort attempt to
// lock the orientation to landscape where the browser allows it.
export function RotateNotice() {
  const t = useT();

  useEffect(() => {
    attemptLandscapeLock();
  }, []);

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 100000,
        background: "linear-gradient(135deg, #16213e 0%, #1a1a40 50%, #2a0845 100%)",
        color: "#fff",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        gap: 22,
        padding: 28,
      }}
    >
      <svg
        width="88"
        height="88"
        viewBox="0 0 24 24"
        fill="none"
        stroke="#80DEEA"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
        style={{ animation: "rotateHint 2.4s ease-in-out infinite", transformOrigin: "50% 50%" }}
      >
        <rect x="7" y="2" width="10" height="20" rx="2" />
        <path d="M11 19h2" />
      </svg>
      <div style={{ fontSize: 22, fontWeight: 800 }}>{t("rotateTitle")}</div>
      <div style={{ fontSize: 15, opacity: 0.75, maxWidth: 340, lineHeight: 1.5 }}>
        {t("rotateHint")}
      </div>
    </div>
  );
}
