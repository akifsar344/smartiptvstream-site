import { useFocusable } from "../navigation/useFocusable";
import { colors, gradient } from "../styles/theme";
import { Icon } from "./Icon";

export interface RailCategory {
  id: string;
  name: string;
  count?: number;
  locked?: boolean;
}

export function CategoryRail({
  categories,
  selectedId,
  onSelect,
  accent = colors.tiles.live,
  title,
}: {
  categories: RailCategory[];
  selectedId: string;
  onSelect: (id: string) => void;
  accent?: string[];
  title?: string;
}) {
  return (
    <div
      style={{
        width: 300,
        height: "100%",
        display: "flex",
        flexDirection: "column",
        background: "rgba(0,0,0,0.25)",
        borderRight: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      {title && (
        <div style={{ padding: "16px 18px 8px", fontSize: 14, fontWeight: 800, letterSpacing: 1, color: "rgba(255,255,255,0.6)" }}>
          {title}
        </div>
      )}
      <div className="scrollable" style={{ flex: 1, padding: "4px 10px" }}>
        {categories.map((c, i) => (
          <CategoryItem
            key={c.id}
            cat={c}
            selected={c.id === selectedId}
            accent={accent}
            onTap={() => onSelect(c.id)}
            autoFocus={i === 0}
          />
        ))}
      </div>
    </div>
  );
}

function CategoryItem({
  cat,
  selected,
  accent,
  onTap,
  autoFocus,
}: {
  cat: RailCategory;
  selected: boolean;
  accent: string[];
  onTap: () => void;
  autoFocus?: boolean;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    onEnter: onTap,
    onFocus: onTap,
    autoFocus,
  });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "12px 14px",
        marginBottom: 4,
        borderRadius: 10,
        cursor: "pointer",
        background: focused
          ? gradient(accent)
          : selected
          ? "rgba(255,255,255,0.10)"
          : "transparent",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      {cat.locked && <Icon name="lock" size={16} color="rgba(255,255,255,0.7)" />}
      <span
        style={{
          flex: 1,
          fontSize: 14,
          fontWeight: selected || focused ? 700 : 500,
          color: "#fff",
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
        }}
      >
        {cat.name}
      </span>
      {cat.count != null && (
        <span style={{ fontSize: 12, color: "rgba(255,255,255,0.5)" }}>{cat.count}</span>
      )}
    </div>
  );
}
