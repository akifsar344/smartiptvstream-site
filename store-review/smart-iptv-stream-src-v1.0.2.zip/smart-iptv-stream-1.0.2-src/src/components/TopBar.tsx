import { useNavigate } from "react-router-dom";
import { colors, gradient } from "../styles/theme";
import { Routes } from "../routes";
import { IconCircle } from "../screens/home/HomeWidgets";
import { useClock, formatHeaderDate } from "../utils/datetime";
import { useSession } from "../store/session";
import { useSettings } from "../store/settings";
import { useCatalog } from "../store/catalog";
import { exitApp } from "../platform/device";
import { asset } from "../platform/asset";

export interface TopBarAction {
  icon: string;
  fg: string;
  onTap: () => void;
  focusKey?: string;
}

// Shared header bar used on every screen. Mirrors the home dashboard header so
// the top-right control cluster is consistent app-wide.
export function TopBar({
  title,
  onBack,
  leadingActions = [],
  showHome = true,
}: {
  title?: string;
  onBack?: () => void;
  /** Screen-specific actions inserted before the standard cluster. */
  leadingActions?: TopBarAction[];
  showHome?: boolean;
}) {
  const navigate = useNavigate();
  const now = useClock();
  const hour24 = useSettings((s) => s.hour24);
  const logout = useSession((s) => s.logout);

  const handleLogout = () => {
    logout();
    navigate(Routes.userList, { replace: true });
  };
  const handleRefresh = () => {
    void useCatalog.getState().loadForScope(true);
  };

  return (
    <div style={{ padding: "0 10px" }}>
      <div
        style={{
          height: 64,
          padding: "0 14px",
          borderRadius: 12,
          background: colors.headerBg,
          border: `1px solid ${colors.headerBorder}`,
          boxShadow: "0 6px 20px rgba(0,0,0,0.25)",
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: 10 }}>
          {onBack && (
            <IconCircle icon="arrow_back" fg="#90CAF9" onTap={onBack} focusKey="topbar-back" />
          )}
          <img
            src={asset("assets/Logo_inn.png")}
            alt="logo"
            style={{ width: 40, height: 40, objectFit: "contain" }}
          />
          {title ? (
            <span style={{ marginLeft: 4, fontSize: 18, fontWeight: 800, letterSpacing: 0.5 }}>
              {title}
            </span>
          ) : (
            <span style={{ marginLeft: 4, color: "rgba(255,255,255,0.70)", fontSize: 13 }}>
              {formatHeaderDate(now, hour24)}
            </span>
          )}
          <div style={{ flex: 1 }} />
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {leadingActions.map((a, i) => (
              <IconCircle
                key={a.focusKey || i}
                icon={a.icon}
                fg={a.fg}
                onTap={a.onTap}
                focusKey={a.focusKey}
              />
            ))}
            {showHome && (
              <IconCircle icon="home" fg="#80DEEA" onTap={() => navigate(Routes.home)} focusKey="topbar-home" />
            )}
            <IconCircle icon="manage_accounts" fg={colors.iconFg.account} onTap={() => navigate(Routes.userList, { state: { from: "home" } })} />
            <IconCircle icon="restart_alt" fg={colors.iconFg.refresh} onTap={handleRefresh} />
            <IconCircle icon="settings" fg={colors.iconFg.settings} onTap={() => navigate(Routes.settings)} />
            <IconCircle icon="info_outline" fg={colors.iconFg.info} onTap={() => navigate(Routes.aboutApp)} />
            <IconCircle icon="exit_to_app" fg={colors.iconFg.logout} onTap={handleLogout} />
            <IconCircle icon="power_settings_new" fg={colors.iconFg.power} onTap={exitApp} />
          </div>
        </div>
        <div
          style={{
            height: 2,
            background: gradient(colors.dividerGradient, "90deg"),
            boxShadow: "0 0 10px rgba(138,43,226,0.35)",
          }}
        />
      </div>
    </div>
  );
}
