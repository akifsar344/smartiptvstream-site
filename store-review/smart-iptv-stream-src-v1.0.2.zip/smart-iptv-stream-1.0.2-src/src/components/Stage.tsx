import React, { useEffect, useState } from "react";
import { BASE_HEIGHT, BASE_WIDTH } from "../styles/theme";

// Renders children inside a fixed 1280x720 coordinate space and scales the
// whole stage to fill the actual TV screen (1280x720 or 1920x1080, both 16:9).
export function Stage({ children }: { children: React.ReactNode }) {
  const [transform, setTransform] = useState("");

  useEffect(() => {
    const apply = () => {
      const sw = window.innerWidth;
      const sh = window.innerHeight;
      const scale = Math.min(sw / BASE_WIDTH, sh / BASE_HEIGHT);
      const offsetX = (sw - BASE_WIDTH * scale) / 2;
      const offsetY = (sh - BASE_HEIGHT * scale) / 2;
      setTransform(
        `translate(${offsetX}px, ${offsetY}px) scale(${scale})`
      );
    };
    apply();
    window.addEventListener("resize", apply);
    return () => window.removeEventListener("resize", apply);
  }, []);

  return (
    <div className="stage" style={{ transform }}>
      {children}
    </div>
  );
}
