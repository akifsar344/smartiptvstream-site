import { useFocusable } from "../navigation/useFocusable";

// Focusable text field. On TV, focusing the underlying <input> triggers the
// platform on-screen keyboard (webOS / Tizen IME).
export function FocusInput({
  value,
  onChange,
  placeholder,
  type = "text",
  focusKey,
  width = "100%",
  layer,
  autoFocus,
  fieldNav,
  scrollOnFocus,
  onSubmit,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
  focusKey?: string;
  width?: number | string;
  layer?: string;
  autoFocus?: boolean;
  fieldNav?: boolean;
  // Scroll the field to the top of its scroll container on focus, so the
  // on-screen keyboard (which covers the bottom of the screen) never hides it.
  scrollOnFocus?: boolean;
  // Fired when the IME / remote "enter/go" key is pressed in this field.
  onSubmit?: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLInputElement>({
    focusKey,
    layer,
    autoFocus,
    editArrowsAsFields: fieldNav,
    onEnter: () => ref.current?.focus(),
    onFocus: () => {
      // Defer so the focus ring renders before IME opens.
      setTimeout(() => {
        ref.current?.focus({ preventScroll: true } as any);
        if (scrollOnFocus) ref.current?.scrollIntoView({ block: "start", behavior: "auto" });
      }, 0);
    },
    onBlur: () => ref.current?.blur(),
  });
  return (
    <input
      ref={ref}
      value={value}
      type={type}
      placeholder={placeholder}
      onChange={(e) => onChange(e.target.value)}
      onKeyDown={(e) => {
        if (onSubmit && (e.key === "Enter" || e.keyCode === 13)) {
          e.preventDefault();
          ref.current?.blur();
          onSubmit();
        }
      }}
      className="focusable"
      style={{
        width,
        height: 48,
        padding: "0 16px",
        fontSize: 16,
        color: "#fff",
        background: "rgba(255,255,255,0.06)",
        border: focused
          ? "2.5px solid #fff"
          : "1.5px solid rgba(255,255,255,0.18)",
        borderRadius: 10,
        boxShadow: focused ? "0 0 20px rgba(54,96,245,0.5)" : "none",
        outline: "none",
        // Leave headroom above the field when it scrolls to the top.
        scrollMarginTop: scrollOnFocus ? 80 : undefined,
      }}
    />
  );
}
