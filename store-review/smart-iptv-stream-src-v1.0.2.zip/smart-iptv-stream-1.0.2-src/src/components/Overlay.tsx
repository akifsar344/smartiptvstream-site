import { useEffect, useId, useState } from "react";
import { focusManager } from "../navigation/focusManager";
import { useFocusable } from "../navigation/useFocusable";
import { useBack } from "../navigation/useBack";
import { FocusInput } from "./FocusInput";
import { Icon } from "./Icon";
import { colors } from "../styles/theme";

// Activates an isolated focus layer for the lifetime of the component so the
// background screen can't be reached while an overlay is open.
function useFocusLayer(name: string) {
  useEffect(() => {
    focusManager.pushLayer(name);
    return () => focusManager.popLayer(name);
  }, [name]);
}

// Mouse-only close affordance shown in a modal's top-right corner. The parent
// card must be position:relative for this to anchor correctly.
export function CloseButton({ onClose }: { onClose: () => void }) {
  return (
    <div
      onClick={(e) => {
        e.stopPropagation();
        onClose();
      }}
      title="Close"
      aria-label="Close"
      style={{
        position: "absolute",
        top: 10,
        right: 10,
        width: 34,
        height: 34,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        zIndex: 6,
        background: "rgba(255,255,255,0.12)",
        border: "1px solid rgba(255,255,255,0.25)",
      }}
    >
      <Icon name="close" size={20} color="#fff" />
    </div>
  );
}

// Click on the dim area outside the card closes the modal. Only fires when the
// click lands on the backdrop itself (not on a child element).
export function backdropClose(onClose: () => void) {
  return (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) onClose();
  };
}

function Backdrop({ children, onClose }: { children: React.ReactNode; onClose?: () => void }) {
  return (
    <div
      onClick={onClose ? backdropClose(onClose) : undefined}
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 1000,
        background: "rgba(0,0,0,0.65)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      {onClose ? (
        <div style={{ position: "relative" }}>
          {children}
          <CloseButton onClose={onClose} />
        </div>
      ) : (
        children
      )}
    </div>
  );
}

function Card({ children, width = 460 }: { children: React.ReactNode; width?: number }) {
  return (
    <div
      style={{
        width,
        maxHeight: 600,
        padding: 22,
        borderRadius: 16,
        background: "linear-gradient(135deg, #18203f, #141632)",
        border: "1px solid rgba(255,255,255,0.16)",
        boxShadow: "0 20px 60px rgba(0,0,0,0.6)",
        display: "flex",
        flexDirection: "column",
        gap: 14,
      }}
    >
      {children}
    </div>
  );
}

function Title({ text }: { text: string }) {
  return (
    <div style={{ fontSize: 18, fontWeight: 800, letterSpacing: 0.3 }}>{text}</div>
  );
}

interface MenuOption {
  label: string;
  icon?: string;
  danger?: boolean;
  onSelect: () => void;
}

export function OptionMenu({
  title,
  options,
  onClose,
}: {
  title: string;
  options: MenuOption[];
  onClose: () => void;
}) {
  const layer = useId();
  useFocusLayer(layer);
  useBack(() => {
    onClose();
    return true;
  });
  return (
    <Backdrop onClose={onClose}>
      <Card width={380}>
        <Title text={title} />
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {options.map((o, i) => (
            <MenuRow key={i} option={o} layer={layer} autoFocus={i === 0} onClose={onClose} />
          ))}
        </div>
      </Card>
    </Backdrop>
  );
}

function MenuRow({
  option,
  layer,
  autoFocus,
  onClose,
}: {
  option: MenuOption;
  layer: string;
  autoFocus?: boolean;
  onClose: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    layer,
    autoFocus,
    onEnter: () => {
      onClose();
      option.onSelect();
    },
  });
  const color = option.danger ? "#FF7043" : "#fff";
  return (
    <div
      ref={ref}
      onClick={() => {
        onClose();
        option.onSelect();
      }}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "12px 14px",
        borderRadius: 10,
        cursor: "pointer",
        background: focused ? "rgba(54,96,245,0.35)" : "rgba(255,255,255,0.05)",
        border: focused ? "2px solid #fff" : "2px solid transparent",
        color,
      }}
    >
      {option.icon && <Icon name={option.icon} size={20} color={color} />}
      <span style={{ fontSize: 15, fontWeight: 600 }}>{option.label}</span>
    </div>
  );
}

export interface SortOption {
  key: string;
  title: string;
  subtitle: string;
  icon: string;
}

// Professional sort picker (Movies / Series). Each option shows a title +
// subtitle and the current selection is checked.
export function SortDialog({
  title,
  subtitle,
  options,
  selected,
  onSelect,
  onClose,
}: {
  title: string;
  subtitle?: string;
  options: SortOption[];
  selected: string;
  onSelect: (key: string) => void;
  onClose: () => void;
}) {
  const layer = useId();
  useFocusLayer(layer);
  useBack(() => {
    onClose();
    return true;
  });
  return (
    <Backdrop onClose={onClose}>
      <Card width={440}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <Icon name="tune" size={26} color={colors.btn} />
          <div style={{ display: "flex", flexDirection: "column" }}>
            <Title text={title} />
            {subtitle && (
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.6)" }}>{subtitle}</span>
            )}
          </div>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {options.map((o, i) => (
            <SortRow
              key={o.key}
              option={o}
              layer={layer}
              active={o.key === selected}
              autoFocus={o.key === selected || (i === 0 && !options.some((x) => x.key === selected))}
              onTap={() => {
                onSelect(o.key);
                onClose();
              }}
            />
          ))}
        </div>
      </Card>
    </Backdrop>
  );
}

function SortRow({
  option,
  layer,
  active,
  autoFocus,
  onTap,
}: {
  option: SortOption;
  layer: string;
  active: boolean;
  autoFocus?: boolean;
  onTap: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap });
  const accent = focused || active ? colors.btn : "rgba(255,255,255,0.7)";
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "12px 14px",
        borderRadius: 12,
        cursor: "pointer",
        background: focused ? "rgba(54,96,245,0.35)" : active ? "rgba(54,96,245,0.18)" : "rgba(255,255,255,0.05)",
        border: focused ? "2px solid #fff" : active ? "2px solid rgba(54,96,245,0.6)" : "2px solid transparent",
      }}
    >
      <Icon name={option.icon} size={24} color={accent} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 700, color: "#fff" }}>{option.title}</div>
        <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }}>{option.subtitle}</div>
      </div>
      {active && <Icon name="check_circle" size={20} color={colors.btn} />}
    </div>
  );
}

export function RenamePrompt({
  title,
  initial,
  okLabel,
  cancelLabel,
  onSubmit,
  onClose,
}: {
  title: string;
  initial: string;
  okLabel: string;
  cancelLabel: string;
  onSubmit: (value: string) => void;
  onClose: () => void;
}) {
  const layer = useId();
  const [val, setVal] = useState(initial);
  useFocusLayer(layer);
  useBack(() => {
    onClose();
    return true;
  });
  return (
    <Backdrop onClose={onClose}>
      <Card>
        <Title text={title} />
        <FocusInput value={val} onChange={setVal} layer={layer} autoFocus fieldNav />
        <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
          <PlainButton label={cancelLabel} layer={layer} onTap={onClose} />
          <PlainButton
            label={okLabel}
            layer={layer}
            primary
            onTap={() => {
              onSubmit(val);
              onClose();
            }}
          />
        </div>
      </Card>
    </Backdrop>
  );
}

export function ConfirmDialog({
  title,
  message,
  okLabel,
  cancelLabel,
  danger,
  onConfirm,
  onClose,
}: {
  title: string;
  message?: string;
  okLabel: string;
  cancelLabel: string;
  danger?: boolean;
  onConfirm: () => void;
  onClose: () => void;
}) {
  const layer = useId();
  useFocusLayer(layer);
  useBack(() => {
    onClose();
    return true;
  });
  return (
    <Backdrop onClose={onClose}>
      <Card>
        <Title text={title} />
        {message && (
          <div style={{ fontSize: 14, color: "rgba(255,255,255,0.7)" }}>{message}</div>
        )}
        <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
          <PlainButton label={cancelLabel} layer={layer} autoFocus onTap={onClose} />
          <PlainButton
            label={okLabel}
            layer={layer}
            primary
            danger={danger}
            onTap={() => {
              onConfirm();
              onClose();
            }}
          />
        </div>
      </Card>
    </Backdrop>
  );
}

// PIN entry / set dialog with an on-screen numeric keypad (TV friendly).
export function PinDialog({
  title,
  mode,
  expectedPin,
  onSuccess,
  onClose,
}: {
  title: string;
  mode: "set" | "verify";
  expectedPin?: string | null;
  onSuccess: (pin: string) => void;
  onClose: () => void;
}) {
  const layer = useId();
  const [pin, setPin] = useState("");
  const [error, setError] = useState(false);
  useFocusLayer(layer);
  useBack(() => {
    onClose();
    return true;
  });

  const press = (d: string) => {
    setError(false);
    setPin((p) => (p.length >= 6 ? p : p + d));
  };
  const back = () => setPin((p) => p.slice(0, -1));
  const submit = () => {
    if (mode === "verify") {
      if (pin === (expectedPin || "")) {
        onSuccess(pin);
        onClose();
      } else {
        setError(true);
        setPin("");
      }
    } else {
      if (pin.length >= 4) {
        onSuccess(pin);
        onClose();
      } else {
        setError(true);
      }
    }
  };

  const keys = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "back", "0", "ok"];

  return (
    <Backdrop onClose={onClose}>
      <Card width={320}>
        <Title text={title} />
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 10,
            padding: "6px 0 2px",
          }}
        >
          {Array.from({ length: 6 }).map((_, i) => (
            <span
              key={i}
              style={{
                width: 14,
                height: 14,
                borderRadius: "50%",
                background: i < pin.length ? "#fff" : "rgba(255,255,255,0.2)",
                border: error ? "1px solid #FF7043" : "none",
              }}
            />
          ))}
        </div>
        {error && (
          <div style={{ color: "#FF7043", fontSize: 13, textAlign: "center" }}>
            {mode === "verify" ? "Wrong PIN" : "PIN too short"}
          </div>
        )}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(3, 1fr)",
            gap: 8,
          }}
        >
          {keys.map((k, i) => (
            <KeypadKey
              key={k}
              label={k}
              layer={layer}
              autoFocus={i === 0}
              onTap={() => {
                if (k === "back") back();
                else if (k === "ok") submit();
                else press(k);
              }}
            />
          ))}
        </div>
      </Card>
    </Backdrop>
  );
}

function KeypadKey({
  label,
  layer,
  autoFocus,
  onTap,
}: {
  label: string;
  layer: string;
  autoFocus?: boolean;
  onTap: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap });
  const content =
    label === "back" ? (
      <Icon name="arrow_back" size={22} color={focused ? colors.primary : "#fff"} />
    ) : label === "ok" ? (
      <Icon name="check" size={22} color={focused ? colors.primary : "#fff"} />
    ) : (
      label
    );
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        height: 52,
        borderRadius: 10,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 22,
        fontWeight: 700,
        cursor: "pointer",
        background: focused ? "#fff" : "rgba(255,255,255,0.08)",
        color: focused ? colors.primary : "#fff",
        border: focused ? "2px solid #fff" : "1.5px solid rgba(255,255,255,0.15)",
      }}
    >
      {content}
    </div>
  );
}

function PlainButton({
  label,
  layer,
  onTap,
  primary,
  danger,
  autoFocus,
}: {
  label: string;
  layer: string;
  onTap: () => void;
  primary?: boolean;
  danger?: boolean;
  autoFocus?: boolean;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap });
  const base = danger ? "#E53935" : primary ? colors.btn : "rgba(255,255,255,0.08)";
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        minWidth: 100,
        height: 44,
        padding: "0 18px",
        borderRadius: 10,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 14,
        fontWeight: 700,
        cursor: "pointer",
        background: focused ? "#fff" : base,
        color: focused ? colors.primary : "#fff",
        border: focused ? "2.5px solid #fff" : "1.5px solid rgba(255,255,255,0.18)",
      }}
    >
      {label}
    </div>
  );
}
