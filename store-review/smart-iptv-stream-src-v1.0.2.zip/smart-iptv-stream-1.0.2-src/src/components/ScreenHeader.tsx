import { useFocusable } from "../navigation/useFocusable";
import { Icon } from "./Icon";
import { colors } from "../styles/theme";

export function ScreenHeader({
  title,
  onBack,
  right,
}: {
  title: string;
  onBack: () => void;
  right?: React.ReactNode;
}) {
  return (
    <div
      style={{
        height: 60,
        display: "flex",
        alignItems: "center",
        gap: 16,
        padding: "0 24px",
        borderBottom: "1px solid rgba(255,255,255,0.08)",
        background: "rgba(0,0,0,0.2)",
      }}
    >
      <BackButton onTap={onBack} />
      <span style={{ fontSize: 20, fontWeight: 800, letterSpacing: 0.5 }}>{title}</span>
      <div style={{ flex: 1 }} />
      {right}
    </div>
  );
}

export function BackButton({ onTap }: { onTap: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        width: 40,
        height: 40,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: focused ? "#fff" : "rgba(255,255,255,0.1)",
        border: focused ? "2.5px solid #fff" : "1px solid rgba(255,255,255,0.15)",
        boxShadow: focused ? `0 0 20px ${colors.btn}` : "none",
        cursor: "pointer",
      }}
    >
      <Icon name="arrow_back" size={22} color={focused ? colors.primary : "#fff"} />
    </div>
  );
}
