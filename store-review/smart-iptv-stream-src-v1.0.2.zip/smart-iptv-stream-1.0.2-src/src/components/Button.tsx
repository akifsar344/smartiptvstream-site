import React from "react";
import { useFocusable } from "../navigation/useFocusable";
import { colors } from "../styles/theme";

export function Button({
  label,
  onTap,
  focusKey,
  autoFocus,
  width,
  variant = "primary",
  icon,
  layer,
}: {
  label: string;
  onTap: () => void;
  focusKey?: string;
  autoFocus?: boolean;
  width?: number | string;
  variant?: "primary" | "ghost" | "danger";
  icon?: React.ReactNode;
  layer?: string;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey,
    onEnter: onTap,
    autoFocus,
    layer,
  });
  const bg =
    variant === "primary"
      ? colors.btn
      : variant === "danger"
      ? "#E53935"
      : "rgba(255,255,255,0.08)";
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        width,
        height: 48,
        padding: "0 22px",
        borderRadius: 10,
        background: focused ? "#fff" : bg,
        color: focused ? colors.primary : "#fff",
        border: focused
          ? "2.5px solid #fff"
          : "1.5px solid rgba(255,255,255,0.18)",
        boxShadow: focused ? `0 0 22px ${bg}` : "none",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        fontSize: 15,
        fontWeight: 700,
        letterSpacing: 0.5,
        cursor: "pointer",
        transform: focused ? "scale(1.03)" : "scale(1)",
      }}
    >
      {icon}
      {label}
    </div>
  );
}
