import { useEffect } from "react";
import { Route, Routes as RRoutes, useLocation, useNavigate } from "react-router-dom";
import { Stage } from "./components/Stage";
import { RotateNotice } from "./components/RotateNotice";
import { useViewport } from "./platform/useViewport";
import { PayLinkScreen } from "./screens/paywall/PayLinkScreen";
import { keepScreenAwake } from "./platform/device";
import { useAccess } from "./store/access";
import { useAuth } from "./store/auth";
import { Routes } from "./routes";
import { SplashScreen } from "./screens/splash/SplashScreen";
import { AuthScreen } from "./screens/auth/AuthScreen";
import { ResetScreen } from "./screens/auth/ResetScreen";
import { LoginScreen } from "./screens/login/LoginScreen";
import { UserListScreen } from "./screens/userlist/UserListScreen";
import { HomeScreen } from "./screens/home/HomeScreen";
import { LiveTvScreen } from "./screens/livetv/LiveTvScreen";
import { MoviesScreen } from "./screens/movies/MoviesScreen";
import { SeriesScreen } from "./screens/series/SeriesScreen";
import { MovieDetailScreen } from "./screens/moviedetail/MovieDetailScreen";
import { SeriesDetailScreen } from "./screens/seriesdetail/SeriesDetailScreen";
import { PlayerScreen } from "./screens/player/PlayerScreen";
import { SettingsScreen } from "./screens/settings/SettingsScreen";
import { CatchUpScreen } from "./screens/catchup/CatchUpScreen";
import { MultiScreen } from "./screens/multiscreen/MultiScreen";
import { InstallEpgScreen } from "./screens/installepg/InstallEpgScreen";
import { SpeedTestScreen } from "./screens/speedtest/SpeedTestScreen";
import { AboutScreen } from "./screens/about/AboutScreen";
import { AccountScreen } from "./screens/account/AccountScreen";
import { PaywallScreen } from "./screens/paywall/PaywallScreen";
import { useWebPlaybackBridge } from "./platform/webPlaybackBridge";

// Routes that stay reachable even when the app is locked (no profile / login /
// the paywall itself). Everything else bounces to the paywall while blocked.
const UNLOCKED_ROUTES: string[] = [
  Routes.splash,
  Routes.login,
  Routes.userList,
  Routes.paywall,
];

// Account-auth routes reachable while signed out (sign in/up + password reset).
const AUTH_ROUTES: string[] = [Routes.authLogin, Routes.authReset];

// Portrait-friendly onboarding screens rendered OUTSIDE the fixed 1280x720 TV
// stage so they adapt to a phone held vertically: account auth, the loading
// splash, and the playlist login. The landscape "please rotate" prompt only
// kicks in once the user reaches the actual TV content (home and beyond).
const PORTRAIT_ROUTES: string[] = [
  Routes.authLogin,
  Routes.authReset,
  Routes.splash,
  Routes.login,
];

function AccessGate() {
  const blocked = useAccess((s) => s.blocked);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (blocked && !UNLOCKED_ROUTES.includes(location.pathname) && !AUTH_ROUTES.includes(location.pathname)) {
      navigate(Routes.paywall, { replace: true });
    }
  }, [blocked, location.pathname, navigate]);

  return null;
}

// Requires a signed-in account before any IPTV screen. Signed-out users are
// sent to /auth (except the reset-password deep link); signed-in users never
// sit on the auth screens.
function AuthGate() {
  const status = useAuth((s) => s.status);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (status === "loading") return;
    const onAuthRoute = AUTH_ROUTES.includes(location.pathname);
    if (status === "anon" && !onAuthRoute) {
      navigate(Routes.authLogin, { replace: true });
    } else if (status === "authed" && location.pathname === Routes.authLogin) {
      navigate(Routes.splash, { replace: true });
    }
  }, [status, location.pathname, navigate]);

  return null;
}

export default function App() {
  const status = useAuth((s) => s.status);
  const location = useLocation();
  const { isMobile, portrait } = useViewport();
  useWebPlaybackBridge();

  useEffect(() => {
    (async () => {
      // Validate the session + pull the account's cloud data, then wire the
      // account-based entitlement store.
      await useAuth.getState().init();
      await useAccess.getState().init();
      keepScreenAwake();
    })();
  }, []);

  // The phone checkout page is public and phone-shaped: render it bare, outside
  // the TV Stage and auth/access gates, so it stays responsive and login-free.
  if (location.pathname === Routes.payLink) {
    return <PayLinkScreen />;
  }

  if (status === "loading") {
    return (
      <div className="authbg" style={{ color: "rgba(255,255,255,0.8)", fontWeight: 600 }}>
        Smart IPTV Stream
      </div>
    );
  }

  // Onboarding screens (account auth, splash, playlist login) render OUTSIDE the
  // fixed 1280x720 stage so they adapt to a phone held vertically. The landscape
  // TV UI (home and beyond) stays in the stage and shows the rotate prompt.
  const isPortraitScreen = PORTRAIT_ROUTES.includes(location.pathname);
  if (isPortraitScreen) {
    return (
      <>
        <AuthGate />
        <AccessGate />
        <RRoutes>
          <Route path={Routes.authLogin} element={<AuthScreen />} />
          <Route path={Routes.authReset} element={<ResetScreen />} />
          <Route path={Routes.splash} element={<SplashScreen />} />
          <Route path={Routes.login} element={<LoginScreen />} />
        </RRoutes>
      </>
    );
  }

  return (
    <>
      <AuthGate />
      <AccessGate />
      <Stage>
        <RRoutes>
          <Route path={Routes.userList} element={<UserListScreen />} />
          <Route path={Routes.home} element={<HomeScreen />} />
          <Route path={Routes.liveTv} element={<LiveTvScreen />} />
          <Route path={Routes.movies} element={<MoviesScreen />} />
          <Route path={Routes.series} element={<SeriesScreen />} />
          <Route path={Routes.movieDetail} element={<MovieDetailScreen />} />
          <Route path={Routes.seriesDetail} element={<SeriesDetailScreen />} />
          <Route path={Routes.player} element={<PlayerScreen />} />
          <Route path={Routes.settings} element={<SettingsScreen />} />
          <Route path={Routes.catchUp} element={<CatchUpScreen />} />
          <Route path={Routes.multiScreen} element={<MultiScreen />} />
          <Route path={Routes.installEpg} element={<InstallEpgScreen />} />
          <Route path={Routes.speedTest} element={<SpeedTestScreen />} />
          <Route path={Routes.aboutApp} element={<AboutScreen />} />
          <Route path={Routes.accountInfo} element={<AccountScreen />} />
          <Route path={Routes.paywall} element={<PaywallScreen />} />
        </RRoutes>
      </Stage>
      {/* Phones must be landscape for the TV UI: prompt to rotate when portrait. */}
      {isMobile && portrait && <RotateNotice />}
    </>
  );
}
