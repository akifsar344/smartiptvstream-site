// Ported from lib/utils/xtream_urls.dart — robust parsing of pasted Xtream
// inputs (handles smart quotes, htp:// typos, embedded credentials, etc.).

const ENDPOINT_FILES = new Set([
  "player_api.php",
  "get.php",
  "xmltv.php",
  "xmltv_api.php",
  "epg.php",
  "panel_api.php",
  "portal.php",
  "stalker_portal.php",
  "api.php",
  "live.php",
  "movie.php",
  "series.php",
  "index.php",
  "login.php",
  "enigma2.php",
  "timeshift.php",
  "c",
]);

function cleanupInput(input: string): string {
  let s = input;
  s = s.replace(/[\u200B-\u200F\u200D\u2060\uFEFF\u00A0\u2028\u2029\u202A-\u202E]/g, "");
  s = s.replace(/\u201C/g, '"').replace(/\u201D/g, '"');
  s = s.replace(/\u2018/g, "'").replace(/\u2019/g, "'");
  s = s.replace(/\uFF1A/g, ":").replace(/\uFF0F/g, "/");
  s = s.trim();
  if (s.length >= 2) {
    if (
      (s.startsWith('"') && s.endsWith('"')) ||
      (s.startsWith("'") && s.endsWith("'"))
    ) {
      s = s.substring(1, s.length - 1).trim();
    }
  }
  return s;
}

function normalizeSchemes(input: string): string {
  let s = input;
  s = s.replace(/(https?)\s*:\s*\/\//gi, (_m, p1) => `${p1.toLowerCase()}://`);
  s = s.replace(/^(https?)(?::\s*)?\/\//i, (_m, p1) => `${p1.toLowerCase()}://`);
  s = s.replace(/^htp\s*:\/\//i, "http://");
  s = s.replace(/^htps\s*:\/\//i, "https://");
  s = s.replace(/^ht+t?p+\s*:\/\//i, "http://");
  s = s.replace(/^(https?):\/\/+/i, (_m, p1) => `${p1.toLowerCase()}://`);
  return s;
}

function extractFirstUrlLike(input: string): string {
  const s = input.trim();
  const m = /(https?:\/\/[^\s<>"]+)/i.exec(s);
  return m ? m[1] : s;
}

export interface XtreamParsedInput {
  baseUrl: string;
  username: string;
  password: string;
}

export function xtreamBaseUrlFrom(input: string): string {
  const cleaned = cleanupInput(input);
  if (!cleaned) return "";
  let s = normalizeSchemes(cleaned);
  s = extractFirstUrlLike(s);
  s = normalizeSchemes(s);
  if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://" + s;

  let uri: URL;
  try {
    uri = new URL(s);
  } catch {
    return "";
  }
  if (!uri.host) return "";

  const segments = uri.pathname.split("/").filter(Boolean);
  if (segments.length) {
    const last = segments[segments.length - 1].toLowerCase();
    if (ENDPOINT_FILES.has(last)) segments.pop();
  }
  let path = "/" + segments.join("/");
  if (!path.endsWith("/")) path += "/";
  return `${uri.protocol}//${uri.host}${path}`;
}

export function parseXtreamInput(input: string): XtreamParsedInput {
  const cleaned = cleanupInput(input);
  if (!cleaned) return { baseUrl: "", username: "", password: "" };
  const normalized = normalizeSchemes(cleaned);
  let s = normalizeSchemes(extractFirstUrlLike(normalized));
  if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://" + s;

  let uri: URL;
  try {
    uri = new URL(s);
  } catch {
    return { baseUrl: "", username: "", password: "" };
  }
  if (!uri.host) return { baseUrl: "", username: "", password: "" };

  const username = (uri.searchParams.get("username") || "").trim();
  const password = (uri.searchParams.get("password") || "").trim();
  return { baseUrl: xtreamBaseUrlFrom(uri.toString()), username, password };
}
