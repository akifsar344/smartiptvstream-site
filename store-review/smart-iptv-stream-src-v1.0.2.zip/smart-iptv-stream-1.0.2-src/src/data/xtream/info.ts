// ---------------------------------------------------------------------------
// Bulletproof normalizers for Xtream `get_series_info` and `get_vod_info`.
//
// Xtream panels are wildly inconsistent between providers, so detail screens
// must never trust a single shape. Everything funnels through these two
// functions so Movies and Series behave identically across every provider.
//
// Series `episodes` has been observed as ALL of these in the wild:
//   • object keyed by season number:   { "1": [ep, ep], "2": [ep] }
//   • object keyed by season, of maps: { "1": { "0": ep, "1": ep } }
//   • a flat array of every episode:   [ ep, ep, ep ]
//   • all episodes dumped under one    { "1": [ep(season:1), ep(season:2) ] }
//     key while the real season lives on each episode's own `season` field
//   • missing / null / a string
//
// Field names also drift (snake_case vs camelCase, info{} nesting, etc.), so we
// probe every known alias and coerce types defensively.
// ---------------------------------------------------------------------------
import { asInt, asStr } from "../models";

export interface NormEpisode {
  id: string;
  title: string;
  season: string;
  episodeNum: number;
  ext: string;
  plot: string;
  image: string;
  durationSecs: number;
  // Direct playback URL (M3U only); empty for Xtream which builds it from the id.
  url: string;
}

export interface NormSeriesInfo {
  cover: string;
  plot: string;
  genre: string;
  cast: string;
  director: string;
  releaseDate: string;
  rating: string;
  seasons: string[]; // sorted unique season ids (as strings)
  bySeason: Record<string, NormEpisode[]>;
  total: number;
}

export interface NormVodInfo {
  cover: string;
  plot: string;
  genre: string;
  cast: string;
  director: string;
  releaseDate: string;
  rating: string;
  durationSecs: number;
  ext: string; // container extension for the play URL
}

/** First non-empty string among the given candidate values. */
function pick(...vals: unknown[]): string {
  for (const v of vals) {
    const s = asStr(v).trim();
    if (s) return s;
  }
  return "";
}

/** Parse a "HH:MM:SS" / "MM:SS" / seconds string into seconds. */
function durationToSecs(raw: unknown): number {
  if (raw == null) return 0;
  if (typeof raw === "number") return Math.trunc(raw);
  const s = String(raw).trim();
  if (!s) return 0;
  if (/^\d+$/.test(s)) return parseInt(s, 10);
  const parts = s.split(":").map((p) => parseInt(p, 10));
  if (parts.some((n) => Number.isNaN(n))) return 0;
  return parts.reduce((acc, n) => acc * 60 + n, 0);
}

function normEpisode(e: any, fallbackSeason: string): NormEpisode | null {
  if (!e || typeof e !== "object") return null;
  const info = e.info || e.movie_data || {};
  const seasonRaw = e.season ?? e.season_number ?? info.season;
  const season =
    seasonRaw != null && String(seasonRaw).trim() !== ""
      ? String(seasonRaw)
      : fallbackSeason;
  const id = pick(e.id, e.episode_id, e.stream_id, info.id);
  const episodeNum = asInt(e.episode_num ?? e.episodeNum ?? info.episode_num, 0);
  return {
    id,
    title: pick(e.title, info.name, info.title) || `Episode ${episodeNum || ""}`.trim(),
    season,
    episodeNum,
    ext: pick(e.container_extension, e.containerExtension, info.container_extension, "mp4"),
    plot: pick(info.plot, info.description, e.plot),
    image: pick(info.movie_image, info.cover_big, info.cover, e.movie_image, e.cover),
    durationSecs: durationToSecs(info.duration_secs ?? info.duration ?? e.duration),
    url: pick(e.direct_source, e.url),
  };
}

export function normalizeSeriesInfo(raw: any): NormSeriesInfo {
  const info = raw?.info || {};
  const bySeason: Record<string, NormEpisode[]> = {};

  const add = (e: any, keySeason: string) => {
    const ep = normEpisode(e, keySeason);
    if (!ep) return;
    (bySeason[ep.season] ||= []).push(ep);
  };

  const eps = raw?.episodes;
  if (Array.isArray(eps)) {
    for (const e of eps) add(e, "1");
  } else if (eps && typeof eps === "object") {
    for (const [k, v] of Object.entries(eps)) {
      if (Array.isArray(v)) v.forEach((e) => add(e, k));
      else if (v && typeof v === "object") Object.values(v).forEach((e) => add(e, k));
    }
  }

  // Sort episodes within each season and collect the season list.
  for (const k of Object.keys(bySeason)) {
    bySeason[k].sort((a, b) => a.episodeNum - b.episodeNum);
  }
  const seasons = Object.keys(bySeason).sort((a, b) => Number(a) - Number(b));
  const total = seasons.reduce((n, k) => n + bySeason[k].length, 0);

  return {
    cover: pick(info.cover, info.cover_big, info.movie_image),
    plot: pick(info.plot, info.description),
    genre: pick(info.genre),
    cast: pick(info.cast, info.actors),
    director: pick(info.director),
    releaseDate: pick(info.releasedate, info.releaseDate, info.release_date),
    rating: pick(info.rating, info.rating_5based),
    seasons,
    bySeason,
    total,
  };
}

export function normalizeVodInfo(raw: any): NormVodInfo {
  const info = raw?.info || {};
  const md = raw?.movie_data || {};
  return {
    cover: pick(info.movie_image, info.cover_big, info.cover),
    plot: pick(info.plot, info.description),
    genre: pick(info.genre),
    cast: pick(info.cast, info.actors),
    director: pick(info.director),
    releaseDate: pick(info.releasedate, info.releaseDate, info.release_date),
    rating: pick(info.rating, info.rating_5based),
    durationSecs: durationToSecs(info.duration_secs ?? info.duration ?? md.duration_secs),
    ext: pick(md.container_extension, info.container_extension, raw?.container_extension, "mp4"),
  };
}

/** True when a series_info payload actually carries playable episodes. */
export function hasEpisodes(n: NormSeriesInfo): boolean {
  return n.total > 0;
}
