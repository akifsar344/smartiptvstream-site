import {
  Category,
  LiveStream,
  MovieStream,
  SeriesStream,
  UserData,
  parseCategory,
  parseLiveStream,
  parseMovieStream,
  parseSeriesStream,
  parseShortEpg,
  parseUserData,
  ShortEpgItem,
} from "../models";
import { apiFetchUrl } from "../../platform/net";

const USER_AGENTS = [
  "IPTV Smart Player",
  "IPTVSmart/1.0",
  "okhttp/4.9.3",
  "Dalvik/2.1.0",
  "Mozilla/5.0 (compatible; SmartIPTV/1.0)",
];

export interface XtreamCreds {
  baseUrl: string; // ends with "/"
  username: string;
  password: string;
}

function cleanRaw(s: string): string {
  let t = s;
  if (t.charCodeAt(0) === 0xfeff) t = t.slice(1);
  t = t.replace(/\x00/g, "");
  // eslint-disable-next-line no-control-regex
  t = t.replace(/[\x01-\x08\x0B\x0C\x0E-\x1F]/g, "");
  return t.trim();
}

function decodeBestEffort(raw: string): any {
  const t = cleanRaw(raw);
  if (!t) return null;
  try {
    return JSON.parse(t);
  } catch {
    /* try jsonp */
  }
  const jsonp = /^\w*\s*\(\s*([\s\S]+?)\s*\)\s*;?\s*$/.exec(t);
  if (jsonp) {
    try {
      return JSON.parse(jsonp[1]);
    } catch {
      /* continue */
    }
  }
  const firstObj = t.indexOf("{");
  const firstArr = t.indexOf("[");
  let start = -1;
  if (firstObj >= 0 && firstArr >= 0) start = Math.min(firstObj, firstArr);
  else start = Math.max(firstObj, firstArr);
  if (start < 0) return null;
  const lastObj = t.lastIndexOf("}");
  const lastArr = t.lastIndexOf("]");
  const end = Math.max(lastObj, lastArr);
  if (end <= start) return null;
  try {
    return JSON.parse(t.substring(start, end + 1));
  } catch {
    return null;
  }
}

function looksHtml(s: string): boolean {
  const l = s.toLowerCase();
  return (
    l.includes("<html") || l.includes("<!doctype html") || l.includes("<body")
  );
}

export class XtreamClient {
  private uaIndex = 0;

  constructor(public creds: XtreamCreds) {}

  private get playerApi(): string {
    return `${this.creds.baseUrl}player_api.php`;
  }

  private async fetchJson(
    params: Record<string, string>,
    retryUA = true
  ): Promise<any> {
    const url = new URL(this.playerApi);
    url.searchParams.set("username", this.creds.username);
    url.searchParams.set("password", this.creds.password);
    for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);

    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 25000);
    try {
      // On the web build this routes cross-origin panel calls through our
      // backend proxy (CORS + http/https), and is a no-op on same-origin.
      const res = await fetch(apiFetchUrl(url.toString()), {
        method: "GET",
        headers: { "User-Agent": USER_AGENTS[this.uaIndex % USER_AGENTS.length] },
        signal: ctrl.signal,
      });
      if (!res.ok && res.status >= 400) {
        return null;
      }
      const text = await res.text();
      if (looksHtml(text) && retryUA) {
        this.uaIndex++;
        return this.fetchJson(params, false);
      }
      return decodeBestEffort(text);
    } catch (e) {
      if (retryUA) {
        this.uaIndex++;
        return this.fetchJson(params, false);
      }
      throw e;
    } finally {
      clearTimeout(timeout);
    }
  }

  async authenticate(): Promise<UserData | null> {
    const data = await this.fetchJson({});
    if (!data || typeof data !== "object") return null;
    const parsed = parseUserData(data);
    if (parsed.userInfo.auth !== 1 && parsed.userInfo.status !== "Active") {
      // Some panels omit auth but still return user_info; accept if username present.
      if (!parsed.userInfo.username) return null;
    }
    return parsed;
  }

  private async list<T>(action: string, parse: (j: any) => T): Promise<T[]> {
    const data = await this.fetchJson({ action });
    if (!Array.isArray(data)) return [];
    return data.map(parse);
  }

  getLiveCategories(): Promise<Category[]> {
    return this.list("get_live_categories", parseCategory);
  }
  getVodCategories(): Promise<Category[]> {
    return this.list("get_vod_categories", parseCategory);
  }
  getSeriesCategories(): Promise<Category[]> {
    return this.list("get_series_categories", parseCategory);
  }

  getLiveStreams(categoryId?: string): Promise<LiveStream[]> {
    const params: Record<string, string> = { action: "get_live_streams" };
    if (categoryId && categoryId !== "all") params.category_id = categoryId;
    return this.fetchJson(params).then((d) =>
      Array.isArray(d) ? d.map(parseLiveStream) : []
    );
  }
  getVodStreams(categoryId?: string): Promise<MovieStream[]> {
    const params: Record<string, string> = { action: "get_vod_streams" };
    if (categoryId && categoryId !== "all") params.category_id = categoryId;
    return this.fetchJson(params).then((d) =>
      Array.isArray(d) ? d.map(parseMovieStream) : []
    );
  }
  getSeries(categoryId?: string): Promise<SeriesStream[]> {
    const params: Record<string, string> = { action: "get_series" };
    if (categoryId && categoryId !== "all") params.category_id = categoryId;
    return this.fetchJson(params).then((d) =>
      Array.isArray(d) ? d.map(parseSeriesStream) : []
    );
  }

  getVodInfo(vodId: number): Promise<any> {
    return this.fetchJson({
      action: "get_vod_info",
      vod_id: String(vodId),
    });
  }
  getSeriesInfo(seriesId: number): Promise<any> {
    return this.fetchJson({
      action: "get_series_info",
      series_id: String(seriesId),
    });
  }

  async getShortEpg(streamId: number, limit = 10): Promise<ShortEpgItem[]> {
    const data = await this.fetchJson({
      action: "get_short_epg",
      stream_id: String(streamId),
      limit: String(limit),
    });
    const arr = data?.epg_listings;
    if (!Array.isArray(arr)) return [];
    return arr.map(parseShortEpg);
  }

  // Mirrors the Android TV source: full guide for a channel via
  // get_simple_data_table. Optional start/end (unix seconds) + limit drive the
  // catch-up window query.
  async getSimpleDataTable(
    streamId: number,
    opts?: { start?: number; end?: number; limit?: number }
  ): Promise<ShortEpgItem[]> {
    const params: Record<string, string> = {
      action: "get_simple_data_table",
      stream_id: String(streamId),
    };
    if (opts?.start != null) params.start = String(opts.start);
    if (opts?.end != null) params.end = String(opts.end);
    if (opts?.limit != null) params.limit = String(opts.limit);
    const data = await this.fetchJson(params);
    const arr = data?.epg_listings;
    if (!Array.isArray(arr)) return [];
    return arr.map(parseShortEpg);
  }

  // EPG browser fetch order from the source: get_simple_data_table first, then
  // get_short_epg, so the guide still fills in on panels that only support one.
  async getGuide(streamId: number): Promise<ShortEpgItem[]> {
    const simple = await this.getSimpleDataTable(streamId).catch(() => [] as ShortEpgItem[]);
    if (simple.length) return simple;
    return this.getShortEpg(streamId, 20).catch(() => [] as ShortEpgItem[]);
  }

  // ----- Stream URL builders -----

  private get u() {
    return this.creds.username;
  }
  private get p() {
    return this.creds.password;
  }

  liveUrl(streamId: number, ext = "m3u8"): string {
    return `${this.creds.baseUrl}live/${this.u}/${this.p}/${streamId}.${ext}`;
  }
  liveTsUrl(streamId: number): string {
    return `${this.creds.baseUrl}live/${this.u}/${this.p}/${streamId}.ts`;
  }
  movieUrl(streamId: number, ext = "mp4"): string {
    return `${this.creds.baseUrl}movie/${this.u}/${this.p}/${streamId}.${ext}`;
  }
  seriesUrl(streamId: number, ext = "mp4"): string {
    return `${this.creds.baseUrl}series/${this.u}/${this.p}/${streamId}.${ext}`;
  }
  catchupUrl(streamId: number, start: string, durationMin: number): string {
    // start format: YYYY-MM-DD:HH-MM
    return `${this.creds.baseUrl}streaming/timeshift.php?username=${encodeURIComponent(
      this.u
    )}&password=${encodeURIComponent(this.p)}&stream=${streamId}&start=${encodeURIComponent(
      start
    )}&duration=${durationMin}`;
  }
  // Path-style timeshift URL used by the Android TV source for catch-up:
  //   {base}timeshift/{user}/{pass}/{durationMin}/{YYYY-MM-DD:HH-MM}/{streamId}.ts
  // ext defaults to "ts"; pass "m3u8" for the HLS variant where the panel
  // supports it (smoother buffering via hls.js).
  timeshiftUrl(streamId: number, durationMin: number, startFmt: string, ext = "ts"): string {
    return `${this.creds.baseUrl}timeshift/${this.u}/${this.p}/${durationMin}/${startFmt}/${streamId}.${ext}`;
  }
  epgXmlUrl(): string {
    return `${this.creds.baseUrl}xmltv.php?username=${encodeURIComponent(
      this.u
    )}&password=${encodeURIComponent(this.p)}`;
  }
}
