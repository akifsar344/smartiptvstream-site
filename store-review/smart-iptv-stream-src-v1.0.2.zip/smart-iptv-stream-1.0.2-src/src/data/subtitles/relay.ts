// Cross-origin fetch helper for subtitle CDNs that misbehave on old webOS
// Chromium.
//
// SubDL is fronted by Cloudflare and returns BOTH `Access-Control-Allow-Origin:
// *` AND `Access-Control-Allow-Credentials: true`. That contradictory combo is
// rejected by the older Chromium in webOS WebViews → fetch throws "Failed to
// fetch" (works fine on desktop Chrome). A server-side relay re-issues clean
// CORS headers, so we fall back to one when the direct request fails.
//
// Direct is always tried first (fast path on desktop / capable TVs); relays are
// only used when the direct request errors or returns a non-OK status.
//
// CRITICAL: every attempt is wrapped in its own timeout. Public relays are
// flaky — some (allorigins, corsproxy.io) routinely hang for 60s+. Without a
// per-attempt timeout a single hung relay would freeze the subtitle search on
// an infinite spinner, which looks like "no subtitles found at all" on the TV.
const RELAYS: ((u: string) => string)[] = [
  // codetabs is the most reliable; it streams binary (zip) responses cleanly.
  (u) => `https://api.codetabs.com/v1/proxy/?quest=${encodeURIComponent(u)}`,
  (u) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
];

const DIRECT_TIMEOUT = 7000;
const RELAY_TIMEOUT = 12000;

/** fetch() that rejects (rather than hanging) once `ms` elapses. */
async function fetchWithTimeout(url: string, init: RequestInit | undefined, ms: number): Promise<Response> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...init, signal: ctrl.signal });
  } finally {
    clearTimeout(timer);
  }
}

export async function corsFetch(url: string, init?: RequestInit): Promise<Response> {
  // 1) Direct (fast path on desktop / capable TVs).
  try {
    const r = await fetchWithTimeout(url, init, DIRECT_TIMEOUT);
    if (r.ok) return r;
  } catch {
    /* network/CORS failure or timeout → fall through to relays */
  }

  // 2) Relays (clean CORS, server-side request bypasses CF client quirks).
  for (const wrap of RELAYS) {
    try {
      const r = await fetchWithTimeout(wrap(url), init, RELAY_TIMEOUT);
      if (r.ok) return r;
    } catch {
      /* timeout or failure → try next relay */
    }
  }

  // 3) Last resort: re-issue the direct request so the caller can read the
  //    real status / error body (e.g. a genuine 403 invalid-key response).
  return fetchWithTimeout(url, init, DIRECT_TIMEOUT);
}
