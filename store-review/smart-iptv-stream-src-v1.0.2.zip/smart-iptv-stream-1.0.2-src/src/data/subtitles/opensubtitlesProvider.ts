import { osRestSearch, osRestDownload } from "./opensubtitlesRest";
import { SubtitleProvider, SubHit, SubSearchParams } from "./types";

export function makeOpenSubtitlesProvider(
  apiKey: string,
  token: string,
  baseUrl: string,
): SubtitleProvider {
  return {
    id: "opensubtitles",
    name: "OpenSubtitles",

    async search(p: SubSearchParams): Promise<SubHit[]> {
      return osRestSearch({ apiKey, token, baseUrl }, p);
    },

    async download(hit: SubHit) {
      const { fileId } = hit.payload as { fileId: string };
      const res = await osRestDownload({ apiKey, token, baseUrl }, fileId);
      return { vtt: res.vtt, cues: res.cues, limited: res.limited };
    },
  };
}
