import { srtToVtt, countCues, buildOsQuery } from "./opensubtitles";
import { corsFetch } from "./relay";
import { SubHit, SubSearchParams } from "./types";
import { storage } from "../../platform/storage";
import { detectInitialLanguage } from "../../i18n";

// OpenSubtitles modern REST API (api.opensubtitles.com).
//
// Unlike the legacy XML-RPC bridge, this one honours VIP accounts properly:
// /download returns a real, decompressed subtitle file (no "Become VIP"
// placeholder) and a per-day quota counter. It needs an Api-Key from a
// registered consumer (https://www.opensubtitles.com/en/consumers) plus the
// user's own login for downloads.
//
// CORS: the API answers preflight with Allow-Origin:* / Allow-Headers:* and
// only blocks empty/curl User-Agents, so a webOS browser fetch works directly.
const DEFAULT_BASE = "api.opensubtitles.com";

// OpenSubtitles "consumer" Api-Key. This identifies the *application* (registered
// once by the developer at https://www.opensubtitles.com/en/consumers) and is the
// SAME for every user — it is not something an end user creates. End users only
// sign in with their own OpenSubtitles username/password to download subtitles.
//
// It is safe to ship this in the client: OpenSubtitles consumer keys are meant to
// identify an app, and this app has no backend to hide it behind.
export const OS_CONSUMER_API_KEY = "aUDQLLbXd00nzHUU5sxO1kSblVt5yUDH";

function apiUrl(base: string, path: string): string {
  const host = (base || DEFAULT_BASE).replace(/^https?:\/\//, "").replace(/\/+$/, "");
  return `https://${host}/api/v1${path}`;
}

/**
 * Preferred subtitle languages for the search, mirroring the desktop app: the
 * user's current UI language first, then English as a universal fallback. Uses
 * ISO-639-1 (2-letter) codes as required by the REST API. Returning a focused
 * set (instead of every language) keeps the results relevant and readable.
 */
function preferredLanguages(): string {
  let lang = "";
  try {
    lang = storage.getString("app_language") || "";
  } catch {
    /* storage unavailable → fall back to the detected locale below */
  }
  if (!lang) {
    try {
      lang = detectInitialLanguage();
    } catch {
      lang = "en";
    }
  }
  const base = (lang || "en").split("_")[0].split("-")[0].toLowerCase();
  const langs = base && base !== "en" ? [base, "en"] : ["en"];
  return langs.join(",");
}

export interface OsRestUser {
  vip: boolean;
  level: string;
  allowedDownloads: number;
  userId: number;
}

export interface OsRestSession {
  token: string;
  baseUrl: string;
  user: OsRestUser;
}

interface CommonAuth {
  apiKey: string;
  token?: string;
  baseUrl?: string;
}

function headers(apiKey: string, token?: string, json = false): Record<string, string> {
  const h: Record<string, string> = { Accept: "application/json", "Api-Key": apiKey };
  if (json) h["Content-Type"] = "application/json";
  if (token) h["Authorization"] = `Bearer ${token}`;
  return h;
}

export async function osRestLogin(
  apiKey: string,
  username: string,
  password: string,
): Promise<OsRestSession> {
  const u = username.trim();
  if (!apiKey.trim()) throw new Error("OpenSubtitles API key is empty");
  if (!u) throw new Error("OpenSubtitles username is empty");
  if (!password) throw new Error("OpenSubtitles password is empty");

  const res = await fetch(apiUrl(DEFAULT_BASE, "/login"), {
    method: "POST",
    headers: headers(apiKey, undefined, true),
    body: JSON.stringify({ username: u, password }),
  });
  const json = await res.json().catch(() => null);
  if (!res.ok || !json?.token) {
    const msg = json?.message || json?.error || `HTTP ${res.status}`;
    throw new Error(`OpenSubtitles login failed: ${msg}`);
  }
  const user = json.user || {};
  return {
    token: String(json.token),
    baseUrl: String(json.base_url || DEFAULT_BASE),
    user: {
      vip: !!user.vip,
      level: String(user.level || ""),
      allowedDownloads: Number(user.allowed_downloads) || 0,
      userId: Number(user.user_id) || 0,
    },
  };
}

/** Validates a token and returns the live VIP/quota state, or null if the
 *  token is invalid/expired (HTTP 401). */
export async function osRestUserInfo(
  apiKey: string,
  token: string,
  baseUrl?: string,
): Promise<OsRestUser | null> {
  const res = await fetch(apiUrl(baseUrl || DEFAULT_BASE, "/infos/user"), {
    headers: headers(apiKey, token),
  });
  if (res.status === 401) return null;
  const json = await res.json().catch(() => null);
  const u = json?.data;
  if (!u) return null;
  return {
    vip: !!u.vip,
    level: String(u.level || ""),
    allowedDownloads: Number(u.remaining_downloads ?? u.allowed_downloads) || 0,
    userId: Number(u.user_id) || 0,
  };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function toHit(row: any): SubHit | null {
  const attr = row?.attributes;
  if (!attr) return null;
  const files = Array.isArray(attr.files) ? attr.files : [];
  const file = files[0];
  const fileId = file ? String(file.file_id ?? "") : "";
  if (!fileId) return null;
  return {
    id: `osrest-${fileId}`,
    provider: "opensubtitles",
    providerName: "OpenSubtitles",
    language: String(attr.language || "").toUpperCase(),
    fileName: String(file?.file_name || attr.release || ""),
    format: "srt",
    downloadCount: Number(attr.download_count) || 0,
    rating: Number(attr.ratings) || 0,
    hearingImpaired: !!attr.hearing_impaired,
    payload: { fileId },
  };
}

export async function osRestSearch(auth: CommonAuth, p: SubSearchParams): Promise<SubHit[]> {
  const q = buildOsQuery(p.title);
  const year = p.year || q.year;
  const params = new URLSearchParams();

  const imdb = (p.imdbid ?? "").replace(/[^0-9]/g, "");
  if (imdb) params.set("imdb_id", imdb);
  else params.set("query", q.query || p.title);

  if (p.season && p.season > 0) {
    params.set("type", "episode");
    params.set("season_number", String(p.season));
    if (p.episode && p.episode > 0) params.set("episode_number", String(p.episode));
  } else {
    params.set("type", "movie");
  }
  params.set("languages", preferredLanguages());
  params.set("order_by", "download_count");

  const res = await fetch(apiUrl(auth.baseUrl || DEFAULT_BASE, `/subtitles?${params.toString()}`), {
    headers: headers(auth.apiKey),
  });
  const json = await res.json().catch(() => null);
  if (!res.ok || !json) {
    const msg = json?.message || json?.error || `HTTP ${res.status}`;
    throw new Error(msg);
  }
  const data = Array.isArray(json.data) ? json.data : [];
  let hits = data.map(toHit).filter((h: SubHit | null): h is SubHit => h != null);

  // When we extracted a year, prefer subtitles whose feature matches it.
  if (year && !imdb) {
    const matched = data.filter(
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (row: any) => String(row?.attributes?.feature_details?.year ?? "") === year,
    );
    if (matched.length) {
      hits = matched.map(toHit).filter((h: SubHit | null): h is SubHit => h != null);
    }
  }
  return hits;
}

export interface OsRestDownloadResult {
  vtt: string;
  cues: number;
  limited: boolean;
  remaining: number;
}

export async function osRestDownload(
  auth: Required<Pick<CommonAuth, "apiKey" | "token">> & Pick<CommonAuth, "baseUrl">,
  fileId: string,
): Promise<OsRestDownloadResult> {
  const res = await fetch(apiUrl(auth.baseUrl || DEFAULT_BASE, "/download"), {
    method: "POST",
    headers: headers(auth.apiKey, auth.token, true),
    body: JSON.stringify({ file_id: Number(fileId) }),
  });
  const json = await res.json().catch(() => null);

  // Quota exhausted → 406 with a message and remaining:0.
  const remaining = Number(json?.remaining);
  if (!res.ok || !json?.link) {
    const msg = json?.message || json?.error || `HTTP ${res.status}`;
    if (res.status === 406 || /download.*limit|quota/i.test(String(msg))) {
      return { vtt: "WEBVTT\n\n", cues: 0, limited: true, remaining: 0 };
    }
    throw new Error(msg);
  }

  // The link serves the actual (decompressed) subtitle file.
  const fileRes = await corsFetch(String(json.link));
  if (!fileRes.ok) throw new Error(`OpenSubtitles file HTTP ${fileRes.status}`);
  const text = await fileRes.text();
  const vtt = srtToVtt(text);
  return {
    vtt,
    cues: countCues(vtt),
    limited: false,
    remaining: Number.isFinite(remaining) ? remaining : 0,
  };
}
