import pako from "pako";

// OpenSubtitles.org legacy XML-RPC bridge.
//
// The user logs in with their own OpenSubtitles account (no API key needed).
// We proxy LogIn / SearchSubtitles / DownloadSubtitles. DownloadSubtitles
// returns the subtitle inline as base64(gzip(text)), so there is no separate
// CDN fetch to fight CORS with — important on webOS web apps.
const ENDPOINT = "https://api.opensubtitles.org/xml-rpc";

// OpenSubtitles requires a User-Agent string registered with them. Browsers
// forbid setting the HTTP User-Agent header, but the XML-RPC LogIn call takes
// it as a *parameter*, so we pass it there instead.
const USER_AGENT = "IPTV Smart Player";

export interface OsHit {
  fileId: string;
  language: string;
  fileName: string;
  rating: number;
  downloadCount: number;
  format: string;
  hearingImpaired: boolean;
  /** Direct gzipped download URL (real file, no VIP-promo placeholder). */
  downloadLink: string;
}

export interface OsSession {
  token: string;
  username: string;
  status: string;
}

export interface OsSearchParams {
  query?: string;
  /** IMDb id (numeric, with or without the "tt" prefix). Precise match. */
  imdbid?: string;
  year?: string;
  season?: number;
  episode?: number;
  /** ISO 639-2 codes, e.g. ["tur","eng"]. Empty = all languages. */
  languages?: string[];
}

export interface OsMovie {
  id: string; // IMDb numeric id
  title: string; // e.g. "Batman (1989)"
  year?: string;
}

// ─── XML-RPC encoding ───────────────────────────────────────────────

function xmlEscape(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

type RpcValue = string | number | boolean | null | RpcValue[] | { [k: string]: RpcValue };

function encodeValue(v: RpcValue): string {
  if (v === null || v === undefined) return "<value><nil/></value>";
  if (typeof v === "boolean") return `<value><boolean>${v ? 1 : 0}</boolean></value>`;
  if (typeof v === "number")
    return Number.isInteger(v)
      ? `<value><int>${v}</int></value>`
      : `<value><double>${v}</double></value>`;
  if (typeof v === "string") return `<value><string>${xmlEscape(v)}</string></value>`;
  if (Array.isArray(v))
    return `<value><array><data>${v.map(encodeValue).join("")}</data></array></value>`;
  // struct
  const members = Object.keys(v)
    .map(
      (k) =>
        `<member><name>${xmlEscape(k)}</name>${encodeValue((v as Record<string, RpcValue>)[k])}</member>`,
    )
    .join("");
  return `<value><struct>${members}</struct></value>`;
}

function methodCall(name: string, params: RpcValue[]): string {
  const body = params.map((p) => `<param>${encodeValue(p)}</param>`).join("");
  return `<?xml version="1.0"?><methodCall><methodName>${xmlEscape(
    name,
  )}</methodName><params>${body}</params></methodCall>`;
}

// ─── XML-RPC decoding (DOMParser) ───────────────────────────────────

function directChildren(el: Element, tag: string): Element[] {
  const out: Element[] = [];
  for (let i = 0; i < el.children.length; i++) {
    const c = el.children[i];
    if (c.tagName === tag) out.push(c);
  }
  return out;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function decodeValue(valueEl: Element): any {
  const child = valueEl.firstElementChild;
  if (!child) return valueEl.textContent ?? "";
  const txt = (child.textContent ?? "").trim();
  switch (child.tagName) {
    case "string":
      return child.textContent ?? "";
    case "int":
    case "i4":
      return parseInt(txt, 10) || 0;
    case "double":
      return parseFloat(txt) || 0;
    case "boolean":
      return txt === "1" || txt.toLowerCase() === "true";
    case "array": {
      const dataEl = child.firstElementChild; // <data>
      if (!dataEl) return [];
      return directChildren(dataEl, "value").map((v) => decodeValue(v));
    }
    case "struct": {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const out: Record<string, any> = {};
      for (const m of directChildren(child, "member")) {
        const nameEl = directChildren(m, "name")[0];
        const valEl = directChildren(m, "value")[0];
        if (!nameEl || !valEl) continue;
        out[(nameEl.textContent ?? "").trim()] = decodeValue(valEl);
      }
      return out;
    }
    default:
      return child.textContent ?? "";
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function decodeResponse(xmlText: string): any {
  const doc = new DOMParser().parseFromString(xmlText, "text/xml");
  const param = doc.querySelector("methodResponse params param value");
  if (!param) return {};
  return decodeValue(param as Element);
}

async function post(body: string): Promise<string> {
  const res = await fetch(ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "text/xml", Accept: "text/xml" },
    body,
  });
  if (!res.ok) throw new Error(`OpenSubtitles HTTP ${res.status}`);
  return res.text();
}

// ─── Public API ─────────────────────────────────────────────────────

export async function osLogin(
  username: string,
  password: string,
  language = "en",
): Promise<OsSession> {
  const u = username.trim();
  if (!u) throw new Error("OpenSubtitles username is empty");
  if (!password) throw new Error("OpenSubtitles password is empty");

  const body = methodCall("LogIn", [u, password, language, USER_AGENT]);
  const decoded = decodeResponse(await post(body));
  const status = String(decoded.status ?? "");
  const token = String(decoded.token ?? "").trim();
  if (!token) {
    throw new Error(`OpenSubtitles login failed: ${status || decoded.message || "unknown"}`);
  }
  return { token, username: u, status };
}

function asInt(v: unknown): number {
  return parseInt(String(v ?? ""), 10) || 0;
}
function asFloat(v: unknown): number {
  return parseFloat(String(v ?? "")) || 0;
}
function asBool(v: unknown): boolean {
  const s = String(v ?? "").trim().toLowerCase();
  return s === "1" || s === "true" || s === "yes";
}

/**
 * Looks up movie/series titles by name (IMDb). Lets the user disambiguate
 * "Batman" → the exact title before we pull that title's subtitles.
 */
export async function osSearchMovies(token: string, query: string): Promise<OsMovie[]> {
  const q = query.trim();
  if (!q) return [];
  const body = methodCall("SearchMoviesOnIMDB", [token, q]);
  const decoded = decodeResponse(await post(body));
  const data = decoded.data;
  if (!Array.isArray(data)) return [];
  const out: OsMovie[] = [];
  for (const row of data) {
    if (!row || typeof row !== "object") continue;
    const id = String(row.id ?? "").trim();
    const title = String(row.title ?? "").trim();
    if (!id || !title || !/^\d+$/.test(id)) continue;
    const ym = title.match(/\((\d{4})\)\s*$/);
    out.push({ id, title, year: ym ? ym[1] : undefined });
  }
  return out;
}

export async function osSearch(token: string, p: OsSearchParams): Promise<OsHit[]> {
  const lang = (p.languages ?? []).filter((x) => x.trim()).join(",");
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const q: Record<string, any> = {};
  const imdb = (p.imdbid ?? "").replace(/[^0-9]/g, "");
  if (imdb) q.imdbid = imdb;
  else if (p.query && p.query.trim()) q.query = p.query.trim();
  if (lang) q.sublanguageid = lang;
  if (p.year && p.year.trim()) q.year = p.year.trim();
  if (p.season && p.season > 0) q.season = p.season;
  if (p.episode && p.episode > 0) q.episode = p.episode;

  const body = methodCall("SearchSubtitles", [token, [q]]);
  const decoded = decodeResponse(await post(body));
  const status = String(decoded.status ?? "");
  if (!status.startsWith("200")) {
    throw new Error(`OpenSubtitles search failed: ${decoded.message || status}`);
  }
  const data = decoded.data;
  if (!Array.isArray(data)) return [];

  const out: OsHit[] = [];
  for (const row of data) {
    if (!row || typeof row !== "object") continue;
    const fileId = String(row.IDSubtitleFile ?? "").trim();
    if (!fileId) continue;
    out.push({
      fileId,
      language: String(row.LanguageName ?? row.SubLanguageID ?? ""),
      fileName: String(row.SubFileName ?? ""),
      rating: asFloat(row.SubRating),
      downloadCount: asInt(row.SubDownloadsCnt),
      format: String(row.SubFormat ?? ""),
      hearingImpaired: asBool(row.SubHearingImpaired),
      downloadLink: String(row.SubDownloadLink ?? ""),
    });
  }
  out.sort((a, b) => b.downloadCount - a.downloadCount || b.rating - a.rating);
  return out;
}

function base64ToBytes(b64: string): Uint8Array {
  const clean = b64.replace(/\s+/g, "");
  const bin = atob(clean);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

// OpenSubtitles injects advertising cues ("OpenSubtitles VIP", "osdb link",
// "support us and become VIP", etc.) into free downloads. Drop any cue block
// whose text mentions them so they don't show on screen.
const PROMO_RE =
  /opensubtitles|osdb|vip\s*member|support\s+us|api\.the|www\.|http|\.org|\.com\b/i;

export function srtToVtt(text: string): string {
  let s = text.replace(/\uFEFF/g, "").replace(/\r+/g, "");
  const alreadyVtt = /^\s*WEBVTT/.test(s);
  if (alreadyVtt) s = s.replace(/^\s*WEBVTT[^\n]*\n+/, "");

  // SRT uses "," as the millisecond separator; WebVTT requires ".".
  s = s.replace(/(\d{2}:\d{2}:\d{2}),(\d{3})/g, "$1.$2");

  // Split into cue blocks and drop advertising ones.
  const blocks = s
    .split(/\n{2,}/)
    .map((b) => b.trim())
    .filter((b) => b.length > 0)
    .filter((b) => {
      // The text lives after the timing line; only inspect non-timing lines.
      const lines = b.split("\n").filter((l) => !/-->/.test(l) && !/^\d+$/.test(l.trim()));
      return !lines.some((l) => PROMO_RE.test(l));
    });

  return "WEBVTT\n\n" + blocks.join("\n\n") + "\n";
}

function bytesToText(buf: Uint8Array): string {
  // Try gzip first (download links and XML-RPC payloads are gzipped); if that
  // fails the bytes are already plain text.
  let raw = buf;
  try {
    raw = pako.ungzip(buf);
  } catch {
    raw = buf;
  }
  return new TextDecoder("utf-8", { fatal: false }).decode(raw);
}

export interface OsDownloadResult {
  vtt: string;
  cues: number;
  /** True when the response was the "Become OpenSubtitles VIP" placeholder
   *  returned once the daily download quota is exhausted. */
  limited: boolean;
}

// The quota-exceeded placeholder is a single cue spanning 0 → 4h that says
// "Become OpenSubtitles VIP member ...".
function isLimitPlaceholder(text: string): boolean {
  return /become\s+opensubtitles|vip\s*member|opensubtitles\.org[^\n]*vip/i.test(text);
}

/** Downloads a subtitle and returns it as WebVTT text. */
export async function osDownloadVtt(token: string, hit: OsHit): Promise<OsDownloadResult> {
  let limited = false;

  // 1) Preferred: the direct gz link. The XML-RPC DownloadSubtitles endpoint
  //    frequently returns a VIP-promo placeholder (no real cues) for free
  //    accounts, whereas the direct link serves the actual file.
  if (hit.downloadLink) {
    try {
      const res = await fetch(hit.downloadLink);
      if (res.ok) {
        const text = bytesToText(new Uint8Array(await res.arrayBuffer()));
        if (isLimitPlaceholder(text)) limited = true;
        const vtt = srtToVtt(text);
        const c = countCues(vtt);
        if (c > 0) return { vtt, cues: c, limited: false };
      }
    } catch {
      /* fall through to XML-RPC */
    }
  }

  // 2) Fallback: XML-RPC inline base64(gzip(text)).
  const body = methodCall("DownloadSubtitles", [token, [hit.fileId]]);
  const decoded = decodeResponse(await post(body));
  const status = String(decoded.status ?? "");
  if (!status.startsWith("200")) {
    throw new Error(`OpenSubtitles download failed: ${decoded.message || status}`);
  }
  const data = decoded.data;
  const first = Array.isArray(data) && data.length ? data[0] : null;
  const b64 = first ? String(first.data ?? "") : "";
  if (!b64.trim()) return { vtt: "WEBVTT\n\n", cues: 0, limited };
  const text = bytesToText(base64ToBytes(b64));
  if (isLimitPlaceholder(text)) limited = true;
  const vtt = srtToVtt(text);
  return { vtt, cues: countCues(vtt), limited };
}

export function countCues(vtt: string): number {
  return (vtt.match(/-->/g) || []).length;
}

// ─── Title → query builder ──────────────────────────────────────────

export interface OsQuery {
  query: string;
  year?: string;
}

const SCENE_TOKENS = new Set([
  "4k", "8k", "uhd", "fhd", "hd", "sd", "2160p", "1080p", "720p", "480p",
  "hdr", "hdr10", "dv", "dolby", "vision", "hevc", "x265", "h265", "x264", "h264",
  "web", "webdl", "webrip", "bluray", "bluray", "brrip", "hdrip", "dvdrip", "hdtv",
  "nf", "netflix", "amzn", "amazon", "dsnp", "hulu", "apple", "atvp",
  "dts", "ddp", "aac", "ac3", "eac3", "sub", "subs", "esub", "forced", "hi", "tr", "en",
]);

/** Strips scene/IPTV decorations and extracts a year from a raw title. */
export function buildOsQuery(rawTitle: string): OsQuery {
  let s = (rawTitle || "").trim();
  if (!s) return { query: "" };
  s = s.replace(/[_.]+/g, " ").replace(/\s+/g, " ").trim();

  let year: string | undefined;
  const ym = s.match(/\b(19\d{2}|20\d{2})\b/);
  if (ym) year = ym[1];

  s = s.replace(/\[[^\]]*\]/g, " ").replace(/\([^)]*\)/g, " ");
  s = s.replace(/[-|]+/g, " ");
  s = s
    .split(/\s+/)
    .filter((w) => w && !SCENE_TOKENS.has(w.toLowerCase()))
    .join(" ")
    .replace(/\s+/g, " ")
    .trim();

  if (s.length < 2) return { query: rawTitle.trim(), year };
  return { query: s, year };
}
