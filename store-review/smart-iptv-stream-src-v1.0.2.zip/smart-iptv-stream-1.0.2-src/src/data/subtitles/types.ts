// Provider-agnostic subtitle layer.
//
// Every subtitle source (OpenSubtitles, SubDL, …) implements SubtitleProvider.
// The player's SubtitleDialog queries all *ready* providers (logged-in /
// API-key configured) in parallel, merges the hits, and dispatches the
// download back to the owning provider — so adding a new source is just a new
// file + one registry line.

export interface SubHit {
  /** Unique within a single provider's result set. */
  id: string;
  /** Provider id, e.g. "opensubtitles" | "subdl". */
  provider: string;
  /** Human-readable provider name shown as a source badge. */
  providerName: string;
  /** Language name or code as the provider reports it. */
  language: string;
  fileName: string;
  format: string;
  downloadCount: number;
  rating: number;
  hearingImpaired: boolean;
  /** Opaque payload the provider needs to fetch the actual file. */
  payload: unknown;
}

export interface SubSearchParams {
  /** Raw title (may contain scene/IPTV decorations; providers clean it). */
  title: string;
  year?: string;
  /** Numeric IMDb id (no "tt" prefix) when known. */
  imdbid?: string;
  season?: number;
  episode?: number;
}

export interface SubDownloadResult {
  vtt: string;
  cues: number;
  /** True when the provider returned a quota/VIP placeholder, not real cues. */
  limited: boolean;
}

export interface SubtitleProvider {
  id: string;
  name: string;
  search(p: SubSearchParams): Promise<SubHit[]>;
  download(hit: SubHit): Promise<SubDownloadResult>;
}
