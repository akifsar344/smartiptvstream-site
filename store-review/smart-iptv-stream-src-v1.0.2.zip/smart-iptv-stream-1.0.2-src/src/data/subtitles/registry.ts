import { useOpenSubtitles } from "../../store/opensubtitles";
import { makeOpenSubtitlesProvider } from "./opensubtitlesProvider";
import { SubtitleProvider, SubHit, SubSearchParams } from "./types";

/** Builds the list of providers the user has configured / signed into. */
export function readyProviders(): SubtitleProvider[] {
  const out: SubtitleProvider[] = [];

  const os = useOpenSubtitles.getState();
  if (os.loggedIn && os.token && os.apiKey) {
    out.push(makeOpenSubtitlesProvider(os.apiKey, os.token, os.baseUrl));
  }

  return out;
}

export interface ProviderGroup {
  id: string;
  name: string;
  hits: SubHit[];
  /** Failure reason (invalid key, blocked, network…) when the search threw. */
  error?: string;
}

/**
 * Searches every ready provider in parallel and returns one group per provider
 * (in provider order) so the dialog can render a tab per source. A provider's
 * failure is captured as group.error instead of sinking the whole search.
 */
export async function searchAllProviders(p: SubSearchParams): Promise<ProviderGroup[]> {
  const providers = readyProviders();
  if (providers.length === 0) return [];

  return Promise.all(
    providers.map(async (prov): Promise<ProviderGroup> => {
      try {
        const hits = await prov.search(p);
        hits.sort((a, b) => b.downloadCount - a.downloadCount || b.rating - a.rating);
        return { id: prov.id, name: prov.name, hits };
      } catch (e) {
        return {
          id: prov.id,
          name: prov.name,
          hits: [],
          error: e instanceof Error ? e.message : String(e),
        };
      }
    }),
  );
}

const byId = new Map<string, () => SubtitleProvider | null>([
  ["opensubtitles", () => {
    const os = useOpenSubtitles.getState();
    return os.loggedIn && os.token && os.apiKey
      ? makeOpenSubtitlesProvider(os.apiKey, os.token, os.baseUrl)
      : null;
  }],
]);

/** Resolves a provider instance for a given hit so we can download it. */
export function providerFor(hit: SubHit): SubtitleProvider | null {
  const make = byId.get(hit.provider);
  return make ? make() : null;
}
