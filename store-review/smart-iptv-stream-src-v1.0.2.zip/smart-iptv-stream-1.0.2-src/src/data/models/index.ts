// Data models mirroring the Android TV (Flutter) source field-by-field, mapped
// from the Xtream Codes player_api.php JSON shapes.

export function asStr(v: unknown, fallback = ""): string {
  if (v == null) return fallback;
  return typeof v === "string" ? v : String(v);
}

export function asInt(v: unknown, fallback = 0): number {
  if (v == null) return fallback;
  if (typeof v === "number") return Math.trunc(v);
  const n = parseInt(String(v).trim(), 10);
  return Number.isNaN(n) ? fallback : n;
}

export function asNum(v: unknown, fallback = 0): number {
  if (v == null) return fallback;
  if (typeof v === "number") return v;
  const n = parseFloat(String(v).trim());
  return Number.isNaN(n) ? fallback : n;
}

export interface Category {
  categoryId: string;
  categoryName: string;
  parentId: number;
}

export function parseCategory(j: any): Category {
  return {
    categoryId: asStr(j.category_id),
    categoryName: asStr(j.category_name),
    parentId: asInt(j.parent_id),
  };
}

export interface LiveStream {
  num: number;
  name: string;
  streamType: string;
  streamId: number;
  streamIcon: string;
  epgChannelId: string;
  added: string;
  isAdult: number;
  categoryId: string;
  customSid: string;
  tvArchive: number;
  directSource: string;
  tvArchiveDuration: number;
}

export function parseLiveStream(j: any): LiveStream {
  return {
    num: asInt(j.num),
    name: asStr(j.name),
    streamType: asStr(j.stream_type, "live"),
    streamId: asInt(j.stream_id),
    streamIcon: asStr(j.stream_icon),
    epgChannelId: asStr(j.epg_channel_id),
    added: asStr(j.added),
    isAdult: asInt(j.is_adult),
    categoryId: asStr(j.category_id),
    customSid: asStr(j.custom_sid),
    tvArchive: asInt(j.tv_archive),
    directSource: asStr(j.direct_source),
    tvArchiveDuration: asInt(j.tv_archive_duration),
  };
}

export interface MovieStream {
  num: number;
  name: string;
  streamType: string;
  streamId: number;
  streamIcon: string;
  rating: string;
  rating5based: number;
  added: string;
  categoryId: string;
  containerExtension: string;
  customSid: string;
  directSource: string;
}

export function parseMovieStream(j: any): MovieStream {
  return {
    num: asInt(j.num),
    name: asStr(j.name),
    streamType: asStr(j.stream_type, "movie"),
    streamId: asInt(j.stream_id),
    streamIcon: asStr(j.stream_icon),
    rating: asStr(j.rating),
    rating5based: asNum(j.rating_5based),
    added: asStr(j.added),
    categoryId: asStr(j.category_id),
    containerExtension: asStr(j.container_extension, "mp4"),
    customSid: asStr(j.custom_sid),
    directSource: asStr(j.direct_source),
  };
}

export interface SeriesStream {
  num: number;
  name: string;
  seriesId: number;
  cover: string;
  plot: string;
  cast: string;
  director: string;
  genre: string;
  releaseDate: string;
  lastModified: string;
  rating: string;
  rating5based: number;
  categoryId: string;
  youtubeTrailer: string;
}

export function parseSeriesStream(j: any): SeriesStream {
  return {
    num: asInt(j.num),
    name: asStr(j.name),
    seriesId: asInt(j.series_id),
    cover: asStr(j.cover),
    plot: asStr(j.plot),
    cast: asStr(j.cast),
    director: asStr(j.director),
    genre: asStr(j.genre),
    releaseDate: asStr(j.releaseDate || j.release_date),
    lastModified: asStr(j.last_modified),
    rating: asStr(j.rating),
    rating5based: asNum(j.rating_5based),
    categoryId: asStr(j.category_id),
    youtubeTrailer: asStr(j.youtube_trailer),
  };
}

export interface UserInfo {
  username: string;
  password: string;
  message: string;
  auth: number;
  status: string;
  expDate: string;
  isTrial: string;
  activeCons: string;
  createdAt: string;
  maxConnections: string;
  allowedOutputFormats: string[];
}

export interface ServerInfo {
  url: string;
  port: string;
  httpsPort: string;
  serverProtocol: string;
  rtmpPort: string;
  timezone: string;
  timestampNow: number;
  timeNow: string;
}

export interface UserData {
  userInfo: UserInfo;
  serverInfo: ServerInfo;
}

export function parseUserData(j: any): UserData {
  const ui = j?.user_info ?? {};
  const si = j?.server_info ?? {};
  let formats: string[] = [];
  const raw = ui.allowed_output_formats;
  if (Array.isArray(raw)) formats = raw.map((x: any) => asStr(x));
  else if (typeof raw === "string" && raw.trim())
    formats = raw.split(",").map((s) => s.trim());
  return {
    userInfo: {
      username: asStr(ui.username),
      password: asStr(ui.password),
      message: asStr(ui.message),
      auth: asInt(ui.auth),
      status: asStr(ui.status),
      expDate: asStr(ui.exp_date),
      isTrial: asStr(ui.is_trial),
      activeCons: asStr(ui.active_cons, "0"),
      createdAt: asStr(ui.created_at),
      maxConnections: asStr(ui.max_connections),
      allowedOutputFormats: formats,
    },
    serverInfo: {
      url: asStr(si.url),
      port: asStr(si.port),
      httpsPort: asStr(si.https_port),
      serverProtocol: asStr(si.server_protocol, "http"),
      rtmpPort: asStr(si.rtmp_port),
      timezone: asStr(si.timezone),
      timestampNow: asInt(si.timestamp_now),
      timeNow: asStr(si.time_now),
    },
  };
}

export interface ShortEpgItem {
  id: string;
  epgId: string;
  title: string;
  lang: string;
  start: string;
  end: string;
  description: string;
  channelId: string;
  startTimestamp: string;
  stopTimestamp: string;
  /** 1 when this programme is available from the catch-up / TV archive. */
  hasArchive: number;
}

export function parseShortEpg(j: any): ShortEpgItem {
  const decode = (s: string) => {
    try {
      return typeof atob === "function" ? decodeURIComponent(escape(atob(s))) : s;
    } catch {
      return s;
    }
  };
  return {
    id: asStr(j.id),
    epgId: asStr(j.epg_id),
    title: decode(asStr(j.title)),
    lang: asStr(j.lang),
    start: asStr(j.start),
    end: asStr(j.end),
    description: decode(asStr(j.description)),
    channelId: asStr(j.channel_id),
    startTimestamp: asStr(j.start_timestamp),
    stopTimestamp: asStr(j.stop_timestamp),
    hasArchive: asInt(j.has_archive),
  };
}

export interface SeriesEpisode {
  id: string;
  episodeNum: number;
  title: string;
  containerExtension: string;
  season: number;
  plot: string;
  durationSecs: number;
  duration: string;
  rating: string;
  movieImage: string;
  releaseDate: string;
}

export interface SeriesSeason {
  seasonNumber: number;
  episodes: SeriesEpisode[];
}

export interface SeriesDetail {
  info: {
    name: string;
    cover: string;
    plot: string;
    cast: string;
    director: string;
    genre: string;
    releaseDate: string;
    rating: string;
    rating5based: number;
    youtubeTrailer: string;
  };
  seasons: SeriesSeason[];
}

export interface MovieInfo {
  name: string;
  cover: string;
  plot: string;
  cast: string;
  director: string;
  genre: string;
  releaseDate: string;
  rating: string;
  duration: string;
  durationSecs: number;
  containerExtension: string;
  youtubeTrailer: string;
  tmdbId: string;
}
