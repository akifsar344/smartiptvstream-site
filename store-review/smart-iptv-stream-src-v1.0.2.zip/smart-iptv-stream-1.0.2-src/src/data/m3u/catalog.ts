// Turns a flat M3U playlist into the same catalog shape the rest of the app
// already understands (Live / Movies / Series), so M3U profiles light up the
// whole UI (dashboard counts, Live TV, Movies, Series) exactly like Xtream.
//
// M3U has no categories/seasons API, so everything is derived from each entry's
// group-title + name + URL via heuristics. Direct playback URLs are carried on
// each item's `directSource` (and on each series episode) so playback never has
// to build an Xtream URL.
import {
  Category,
  LiveStream,
  MovieStream,
  SeriesStream,
} from "../models";
import { M3uEntry } from "./parser";

export interface M3uCatalog {
  liveCategories: Category[];
  liveStreams: LiveStream[];
  movieCategories: Category[];
  movieStreams: MovieStream[];
  seriesCategories: Category[];
  seriesStreams: SeriesStream[];
  // Raw `get_series_info`-shaped payloads keyed by synthetic seriesId, consumed
  // by SeriesDetailScreen through the same normalizeSeriesInfo() path as Xtream.
  seriesInfo: Record<number, any>;
}

// Stable 32-bit FNV-1a hash → positive int. Stable across reloads so favorites,
// locks and continue-watching keep working for the same stream URL.
function hashId(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0) % 2_000_000_000 + 1;
}

function slug(s: string): string {
  return (s || "uncategorized").trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "uncategorized";
}

// Container extension from a URL path (mp4/mkv/avi/ts/…); "" when none/HLS.
function extFromUrl(url: string): string {
  const noQuery = url.split(/[?#]/)[0];
  const m = /\.([a-z0-9]{2,4})$/i.exec(noQuery);
  const ext = m ? m[1].toLowerCase() : "";
  if (!ext || ext === "m3u8" || ext === "php") return "";
  return ext;
}

const SERIES_GROUP = /(series|serie|dizi|diziler|tv\s*show|tvshow|shows|sezon|season)/i;
const VOD_GROUP = /(vod|movie|movies|film|filmler|sinema|cinema)/i;
// "S01 E02", "S01E02", "1x02", "Season 1", "Sezon 1 Bölüm 2"
const SXXEYY = /\bS\s*(\d{1,2})\s*[\sxe._-]*\s*E\s*(\d{1,3})\b/i;
const NXM = /\b(\d{1,2})\s*x\s*(\d{1,3})\b/i;
const SEASON_WORD = /(season|sezon)\s*\d+/i;

type Kind = "live" | "movie" | "series";

function classify(e: M3uEntry): Kind {
  const url = e.url.toLowerCase();
  const group = e.group || "";
  const name = e.name || "";
  // Series: Xtream `/series/` VOD path, a "series/dizi/season" group, or an
  // episodic name like "Show S01 E02" / "1x02".
  if (/\/series\//.test(url) || SERIES_GROUP.test(group) || SXXEYY.test(name) || NXM.test(name) || SEASON_WORD.test(name)) {
    return "series";
  }
  // Movie: Xtream `/movie/` VOD path or an explicit VOD/Movie/Film group.
  // NOTE: we intentionally do NOT infer "movie" from a file extension alone —
  // many live channels are direct `.ts`/`.mp4` streams and would be misfiled.
  if (/\/movie\//.test(url) || VOD_GROUP.test(group)) {
    return "movie";
  }
  return "live";
}

// Pull season/episode numbers + a clean series base title out of an entry name.
function parseEpisode(name: string): { base: string; season: number; episode: number } {
  let season = 1;
  let episode = 0;
  let base = name;
  let m = SXXEYY.exec(name);
  if (m) {
    season = parseInt(m[1], 10);
    episode = parseInt(m[2], 10);
    base = name.slice(0, m.index);
  } else if ((m = NXM.exec(name))) {
    season = parseInt(m[1], 10);
    episode = parseInt(m[2], 10);
    base = name.slice(0, m.index);
  } else {
    const sw = SEASON_WORD.exec(name);
    if (sw) {
      season = parseInt(sw[0].replace(/\D+/g, ""), 10) || 1;
      base = name.slice(0, sw.index);
    }
  }
  base = base.replace(/[\s._\-:|]+$/g, "").trim() || name.trim();
  return { base, season, episode };
}

function addCategory(map: Map<string, Category>, group: string) {
  const name = (group || "").trim() || "Uncategorized";
  const id = slug(name);
  if (!map.has(id)) map.set(id, { categoryId: id, categoryName: name, parentId: 0 });
  return id;
}

export function buildM3uCatalog(entries: M3uEntry[]): M3uCatalog {
  const liveCatMap = new Map<string, Category>();
  const movieCatMap = new Map<string, Category>();
  const seriesCatMap = new Map<string, Category>();
  const liveStreams: LiveStream[] = [];
  const movieStreams: MovieStream[] = [];

  // seriesId -> aggregation
  interface SeriesAgg {
    seriesId: number;
    name: string;
    cover: string;
    categoryId: string;
    episodes: any[];
  }
  const seriesMap = new Map<number, SeriesAgg>();
  const epCounter = new Map<number, number>();

  let liveNum = 0;
  let movieNum = 0;

  for (const e of entries) {
    if (!e.url) continue;
    const kind = classify(e);
    const group = (e.group || "").trim() || "Uncategorized";

    if (kind === "live") {
      const catId = addCategory(liveCatMap, group);
      liveNum += 1;
      liveStreams.push({
        num: liveNum,
        name: e.name,
        streamType: "live",
        streamId: hashId("live|" + e.url),
        streamIcon: e.logo || "",
        epgChannelId: e.tvgId || "",
        added: "",
        isAdult: 0,
        categoryId: catId,
        customSid: "",
        tvArchive: 0,
        directSource: e.url,
        tvArchiveDuration: 0,
      });
    } else if (kind === "movie") {
      const catId = addCategory(movieCatMap, group);
      movieNum += 1;
      movieStreams.push({
        num: movieNum,
        name: e.name,
        streamType: "movie",
        streamId: hashId("movie|" + e.url),
        streamIcon: e.logo || "",
        rating: "",
        rating5based: 0,
        added: "",
        categoryId: catId,
        containerExtension: extFromUrl(e.url) || "mp4",
        customSid: "",
        directSource: e.url,
      });
    } else {
      const catId = addCategory(seriesCatMap, group);
      const { base, season, episode } = parseEpisode(e.name);
      const seriesId = hashId("series|" + slug(group) + "|" + base.toLowerCase());
      let agg = seriesMap.get(seriesId);
      if (!agg) {
        agg = { seriesId, name: base, cover: e.logo || "", categoryId: catId, episodes: [] };
        seriesMap.set(seriesId, agg);
      }
      if (!agg.cover && e.logo) agg.cover = e.logo;
      const seq = (epCounter.get(seriesId) || 0) + 1;
      epCounter.set(seriesId, seq);
      agg.episodes.push({
        id: hashId("ep|" + e.url),
        title: e.name,
        season: String(season),
        episode_num: episode || seq,
        container_extension: extFromUrl(e.url) || "mp4",
        direct_source: e.url,
        info: { movie_image: e.logo || "" },
      });
    }
  }

  const seriesStreams: SeriesStream[] = [];
  const seriesInfo: Record<number, any> = {};
  let seriesNum = 0;
  for (const agg of seriesMap.values()) {
    seriesNum += 1;
    seriesStreams.push({
      num: seriesNum,
      name: agg.name,
      seriesId: agg.seriesId,
      cover: agg.cover,
      plot: "",
      cast: "",
      director: "",
      genre: "",
      releaseDate: "",
      lastModified: "",
      rating: "",
      rating5based: 0,
      categoryId: agg.categoryId,
      youtubeTrailer: "",
    });
    // Group episodes into the season-keyed shape normalizeSeriesInfo() accepts.
    const bySeason: Record<string, any[]> = {};
    for (const ep of agg.episodes) (bySeason[ep.season] ||= []).push(ep);
    seriesInfo[agg.seriesId] = {
      info: { name: agg.name, cover: agg.cover, plot: "" },
      episodes: bySeason,
    };
  }

  return {
    liveCategories: Array.from(liveCatMap.values()),
    liveStreams,
    movieCategories: Array.from(movieCatMap.values()),
    movieStreams,
    seriesCategories: Array.from(seriesCatMap.values()),
    seriesStreams,
    seriesInfo,
  };
}
