// Minimal but resilient M3U / M3U8 playlist parser supporting the common
// #EXTINF attributes used by IPTV providers (tvg-id, tvg-logo, group-title).

export interface M3uEntry {
  num: number;
  name: string;
  url: string;
  logo: string;
  group: string;
  tvgId: string;
  tvgName: string;
  streamId: number;
}

const ATTR_RE = /([a-zA-Z0-9_-]+)="([^"]*)"/g;

export function parseM3u(content: string): M3uEntry[] {
  const lines = content.split(/\r?\n/);
  const entries: M3uEntry[] = [];
  let pending: Partial<M3uEntry> | null = null;
  let idx = 0;

  for (let raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith("#EXTM3U")) continue;

    if (line.startsWith("#EXTINF")) {
      const attrs: Record<string, string> = {};
      let m: RegExpExecArray | null;
      ATTR_RE.lastIndex = 0;
      while ((m = ATTR_RE.exec(line)) !== null) {
        attrs[m[1].toLowerCase()] = m[2];
      }
      const commaIdx = line.lastIndexOf(",");
      const name = commaIdx >= 0 ? line.slice(commaIdx + 1).trim() : "";
      pending = {
        name: name || attrs["tvg-name"] || "Unknown",
        logo: attrs["tvg-logo"] || "",
        group: attrs["group-title"] || "",
        tvgId: attrs["tvg-id"] || "",
        tvgName: attrs["tvg-name"] || "",
      };
      continue;
    }

    if (line.startsWith("#")) continue;

    // A URL line
    if (pending) {
      idx += 1;
      entries.push({
        num: idx,
        name: pending.name || "Unknown",
        url: line,
        logo: pending.logo || "",
        group: pending.group || "",
        tvgId: pending.tvgId || "",
        tvgName: pending.tvgName || "",
        streamId: idx,
      });
      pending = null;
    }
  }
  return entries;
}

export function groupsFromM3u(entries: M3uEntry[]): string[] {
  const set = new Set<string>();
  for (const e of entries) set.add(e.group || "Uncategorized");
  return Array.from(set);
}
