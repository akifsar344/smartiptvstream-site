// External billing client for webOS (no Firebase SDK — plain fetch only, so it
// runs on old webOS Chromium). Mirrors the Fire TV flow:
//   1. createPairing()        -> writes a `pairing_codes` doc (Firestore REST)
//   2. user scans the QR -> pays on smarttvsetup.app/link?code=CODE
//   3. checkLicense(code) -> callable that syncs the paid pairing into a license
//
// Firestore security rules allow unauthenticated read of pairing_codes and
// create of a `pending` direct pairing, and the callables are `invoker:public`,
// so we need no auth token at all.

import { storage } from "../../platform/storage";
import { getDeviceId } from "../../platform/deviceId";
import { getDeviceInfo } from "../../platform/device";

const PROJECT_ID = "discoverapp-86c2f";
const API_KEY = "AIzaSyAcsShkoemlXL2_fGpAo48MHtvaoChciak";
const REGION = "us-central1";

const FIRESTORE_BASE = `https://firestore.googleapis.com/v1/projects/${PROJECT_ID}/databases/(default)/documents`;
const FUNCTIONS_BASE = `https://${REGION}-${PROJECT_ID}.cloudfunctions.net`;
const WEB_LINK_BASE = "https://smarttvsetup.app/link";

const CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const CODE_LEN = 6;
const EXPIRY_MS = 30 * 60 * 1000;
const PAIRING_KEY = "license.pairing";

export interface LicenseResult {
  active: boolean;
  status: string; // active | not_found | refunded | inactive | …
  plan: string | null;
  message: string;
  /** Server-authoritative trial start (ISO string) for this device, returned
   *  by checkDeviceLicense when the device is not yet licensed. Used so the
   *  trial can't be reset by clearing local storage. */
  trialStartedAt: string | null;
}

export interface PairingSession {
  code: string;
  qrUrl: string;
  expiresAt: number; // epoch ms
}

// Built-in fallback used whenever the remote price cannot be read (offline,
// missing doc, malformed value). Keep this in sync with the web checkout.
export const DEFAULT_PAYWALL_PRICE = "$5.99";

/**
 * Reads the displayed paywall price from Firestore `app_config/paywall`
 * (public read, unauthenticated) so the price can be changed server-side
 * without shipping a new app build / LG store review. Falls back to the
 * built-in default on any failure so the paywall never breaks.
 */
export async function fetchPaywallPrice(): Promise<string> {
  try {
    const res = await fetch(`${FIRESTORE_BASE}/app_config/paywall?key=${API_KEY}`);
    if (!res.ok) return DEFAULT_PAYWALL_PRICE;
    const json = await res.json();
    const price = json?.fields?.price?.stringValue;
    return typeof price === "string" && price.trim() ? price.trim() : DEFAULT_PAYWALL_PRICE;
  } catch {
    return DEFAULT_PAYWALL_PRICE;
  }
}

function randomCode(): string {
  let out = "";
  const buf = new Uint8Array(CODE_LEN);
  try {
    crypto.getRandomValues(buf);
  } catch {
    for (let i = 0; i < CODE_LEN; i++) buf[i] = Math.floor(Math.random() * 256);
  }
  for (let i = 0; i < CODE_LEN; i++) out += CODE_CHARS[buf[i] % CODE_CHARS.length];
  return out;
}

/** Calls the public `checkDeviceLicense` callable (Cloud Functions gen2). */
export async function checkLicense(pairingCode?: string): Promise<LicenseResult> {
  const deviceId = getDeviceId();
  const body = {
    data: {
      deviceId,
      platform: "webos",
      ...(pairingCode ? { pairingCode } : {}),
    },
  };
  const res = await fetch(`${FUNCTIONS_BASE}/checkDeviceLicense`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`license http ${res.status}`);
  const json = await res.json();
  const r = json?.result ?? {};
  return {
    active: !!r.active,
    status: String(r.status ?? "unknown"),
    plan: r.plan ?? null,
    message: String(r.message ?? ""),
    trialStartedAt:
      typeof r.trialStartedAt === "string" ? r.trialStartedAt : null,
  };
}

/** Reads a pairing doc's status via the Firestore REST API (unauthenticated). */
export async function readPairingStatus(code: string): Promise<string> {
  try {
    const res = await fetch(
      `${FIRESTORE_BASE}/pairing_codes/${encodeURIComponent(code)}?key=${API_KEY}`
    );
    if (!res.ok) return "pending";
    const json = await res.json();
    return json?.fields?.status?.stringValue ?? "pending";
  } catch {
    return "pending";
  }
}

/**
 * Creates (or reuses a still-valid) direct pairing code for this device and
 * writes it to Firestore so the web checkout can link it.
 */
export async function createPairing(forceNew = false): Promise<PairingSession> {
  if (!forceNew) {
    const cached = storage.get<PairingSession | null>(PAIRING_KEY, null);
    if (cached && cached.expiresAt > Date.now() + 30_000) return cached;
  }

  const deviceId = getDeviceId().toLowerCase();
  const code = randomCode();
  const now = new Date();
  const expires = new Date(now.getTime() + EXPIRY_MS);
  const info = getDeviceInfo();

  const fields = {
    code: { stringValue: code },
    deviceId: { stringValue: deviceId },
    platform: { stringValue: "webos" },
    deviceName: { stringValue: "LG webOS TV" },
    manufacturer: { stringValue: info.brand || "LG" },
    model: { stringValue: "webOS" },
    deviceType: { stringValue: "tv" },
    status: { stringValue: "pending" },
    activationMode: { stringValue: "direct" },
    createdAt: { timestampValue: now.toISOString() },
    expiresAt: { timestampValue: expires.toISOString() },
    linkedUserId: { nullValue: null },
  };

  const res = await fetch(
    `${FIRESTORE_BASE}/pairing_codes?documentId=${code}&key=${API_KEY}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fields }),
    }
  );
  if (!res.ok) throw new Error(`pairing http ${res.status}`);

  const session: PairingSession = {
    code,
    qrUrl: `${WEB_LINK_BASE}?code=${code}`,
    expiresAt: expires.getTime(),
  };
  storage.set(PAIRING_KEY, session);
  return session;
}

export const PAIRING_WEB_LINK = WEB_LINK_BASE;
