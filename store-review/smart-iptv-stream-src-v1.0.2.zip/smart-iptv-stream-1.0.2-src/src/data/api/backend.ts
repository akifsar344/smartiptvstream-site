import { apiBase } from "../../platform/net";
import { getDeviceInfo } from "../../platform/deviceId";

export interface AccessView {
  email: string;
  isPro: boolean;
  plan: string | null;
  status: string; // trial | active | expired
  trialStartedAt: number;
  trialEndsAt: number;
  trialActive: boolean;
  blocked: boolean;
}

export interface AuthResult {
  token: string;
  access: AccessView;
}

export class ApiError extends Error {
  constructor(public code: string, public httpStatus: number) {
    super(code);
  }
}

async function call<T>(path: string, opts: RequestInit & { token?: string } = {}): Promise<T> {
  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (opts.token) headers.Authorization = `Bearer ${opts.token}`;
  const res = await fetch(`${apiBase()}${path}`, { ...opts, headers: { ...headers, ...(opts.headers as any) } });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(json?.error || `http_${res.status}`, res.status);
  return json as T;
}

export const backend = {
  signup: (email: string, password: string) =>
    call<AuthResult>("/api/auth/signup", {
      method: "POST",
      body: JSON.stringify({ email, password, ...getDeviceInfo() }),
    }),

  login: (email: string, password: string) =>
    call<AuthResult>("/api/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }),

  me: (token: string) => call<{ access: AccessView }>("/api/auth/me", { token }),

  createExtensionHandoff: (token: string) =>
    call<{ code: string; expiresAt: number }>("/api/auth/extension-handoff", {
      method: "POST",
      token,
    }),

  redeemExtensionHandoff: (code: string) =>
    call<AuthResult>("/api/auth/extension-handoff/redeem", {
      method: "POST",
      body: JSON.stringify({ code }),
    }),

  forgot: (email: string) =>
    call<{ ok: true }>("/api/auth/forgot", { method: "POST", body: JSON.stringify({ email }) }),

  reset: (token: string, password: string) =>
    call<AuthResult>("/api/auth/reset", { method: "POST", body: JSON.stringify({ token, password }) }),

  changePassword: (token: string, currentPassword: string, newPassword: string) =>
    call<{ ok: true }>("/api/auth/change-password", {
      method: "POST",
      token,
      body: JSON.stringify({ currentPassword, newPassword }),
    }),

  getData: (token: string) =>
    call<{ data: Record<string, unknown>; version: number; updatedAt: number; access: AccessView }>(
      "/api/data",
      { token }
    ),

  putData: (token: string, data: Record<string, unknown>) =>
    call<{ ok: true; version: number; updatedAt: number }>("/api/data", {
      method: "PUT",
      token,
      body: JSON.stringify({ data }),
    }),

  cleengCheckout: (token: string) =>
    call<CleengCheckout>("/api/billing/cleeng-checkout", { method: "POST", token }),

  cleengCheckoutPublic: (t: string) =>
    call<CleengCheckout>("/api/billing/cleeng-checkout-public", {
      method: "POST",
      body: JSON.stringify({ t }),
    }),
};

export interface CleengCheckout {
  publisherId: string;
  offerId: string;
  sandbox: boolean;
  jwt: string | null;
  refreshToken: string | null;
  email: string;
  // Only present on the authenticated /cleeng-checkout response: a short-lived
  // token to embed in the phone checkout QR link.
  linkToken?: string;
}
