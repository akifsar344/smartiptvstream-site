import { XMLParser } from "fast-xml-parser";

// Parses XMLTV EPG feeds (the format Xtream xmltv.php returns) into a map of
// channelId -> programmes.

export interface EpgProgramme {
  channelId: string;
  start: number; // epoch ms
  stop: number; // epoch ms
  title: string;
  description: string;
}

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: "@_",
  textNodeName: "#text",
});

// XMLTV time format: 20240115203000 +0000
function parseXmltvTime(s: string): number {
  if (!s) return 0;
  const m = /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{4})?/.exec(
    s.trim()
  );
  if (!m) {
    const d = Date.parse(s);
    return Number.isNaN(d) ? 0 : d;
  }
  const [, y, mo, d, h, mi, se, tz] = m;
  const iso = `${y}-${mo}-${d}T${h}:${mi}:${se}${
    tz ? `${tz.slice(0, 3)}:${tz.slice(3)}` : "Z"
  }`;
  const t = Date.parse(iso);
  return Number.isNaN(t) ? 0 : t;
}

function textOf(node: any): string {
  if (node == null) return "";
  if (typeof node === "string") return node;
  if (Array.isArray(node)) return textOf(node[0]);
  if (typeof node === "object") return String(node["#text"] ?? "");
  return String(node);
}

export function parseXmltv(xml: string): Map<string, EpgProgramme[]> {
  const map = new Map<string, EpgProgramme[]>();
  let doc: any;
  try {
    doc = parser.parse(xml);
  } catch {
    return map;
  }
  const tv = doc?.tv;
  if (!tv) return map;
  let programmes = tv.programme;
  if (!programmes) return map;
  if (!Array.isArray(programmes)) programmes = [programmes];

  for (const p of programmes) {
    const channelId = String(p["@_channel"] ?? "");
    if (!channelId) continue;
    const prog: EpgProgramme = {
      channelId,
      start: parseXmltvTime(String(p["@_start"] ?? "")),
      stop: parseXmltvTime(String(p["@_stop"] ?? "")),
      title: textOf(p.title),
      description: textOf(p.desc),
    };
    const arr = map.get(channelId) || [];
    arr.push(prog);
    map.set(channelId, arr);
  }

  for (const arr of map.values()) arr.sort((a, b) => a.start - b.start);
  return map;
}

export function currentAndNext(
  programmes: EpgProgramme[],
  now = Date.now()
): { current?: EpgProgramme; next?: EpgProgramme } {
  if (!programmes?.length) return {};
  for (let i = 0; i < programmes.length; i++) {
    const p = programmes[i];
    if (now >= p.start && now < p.stop) {
      return { current: p, next: programmes[i + 1] };
    }
    if (now < p.start) {
      return { current: undefined, next: p };
    }
  }
  return {};
}
