// Lightweight i18n that consumes the Flutter .arb files (valid JSON) copied
// from the Android TV source. 48 languages are supported, lazily loaded.

const localeModules = import.meta.glob("./locales/*.json");

export interface LanguageOption {
  code: string;
  /** Native display name */
  name: string;
}

// Display names mirror the language list shown in the Android TV settings.
export const LANGUAGES: LanguageOption[] = [
  { code: "en", name: "English" },
  { code: "ar", name: "العربية" },
  { code: "af", name: "Afrikaans" },
  { code: "am", name: "አማርኛ" },
  { code: "az", name: "Azərbaycan" },
  { code: "be", name: "Беларуская" },
  { code: "bg", name: "Български" },
  { code: "bn", name: "বাংলা" },
  { code: "ca", name: "Català" },
  { code: "cs", name: "Čeština" },
  { code: "da", name: "Dansk" },
  { code: "de", name: "Deutsch" },
  { code: "el", name: "Ελληνικά" },
  { code: "es", name: "Español" },
  { code: "et", name: "Eesti" },
  { code: "eu", name: "Euskara" },
  { code: "fa", name: "فارسی" },
  { code: "fi", name: "Suomi" },
  { code: "fr", name: "Français" },
  { code: "ga_IE", name: "Gaeilge" },
  { code: "he", name: "עברית" },
  { code: "hi", name: "हिन्दी" },
  { code: "hr", name: "Hrvatski" },
  { code: "hu", name: "Magyar" },
  { code: "id", name: "Indonesia" },
  { code: "it", name: "Italiano" },
  { code: "ja", name: "日本語" },
  { code: "kk", name: "Қазақ" },
  { code: "ko", name: "한국어" },
  { code: "ku", name: "Kurdî" },
  { code: "lv", name: "Latviešu" },
  { code: "ms", name: "Melayu" },
  { code: "nl", name: "Nederlands" },
  { code: "no", name: "Norsk" },
  { code: "pl", name: "Polski" },
  { code: "pt", name: "Português" },
  { code: "pt_BR", name: "Português (BR)" },
  { code: "qu", name: "Runa Simi" },
  { code: "ro", name: "Română" },
  { code: "ru", name: "Русский" },
  { code: "sk", name: "Slovenčina" },
  { code: "sl", name: "Slovenščina" },
  { code: "sq", name: "Shqip" },
  { code: "sr", name: "Српски" },
  { code: "sv", name: "Svenska" },
  { code: "tr", name: "Türkçe" },
  { code: "ur", name: "اردو" },
  { code: "zh", name: "中文" },
];

export const RTL_LANGUAGES = new Set(["ar", "fa", "he", "ur", "ku"]);

export type Dict = Record<string, string>;

function sanitize(raw: Record<string, unknown>): Dict {
  const out: Dict = {};
  for (const [k, v] of Object.entries(raw)) {
    if (k.startsWith("@")) continue; // skip arb metadata
    if (typeof v === "string") out[k] = v;
  }
  return out;
}

const cache = new Map<string, Dict>();

export async function loadLocale(code: string): Promise<Dict> {
  if (cache.has(code)) return cache.get(code)!;
  const path = `./locales/${code}.json`;
  const loader = localeModules[path];
  if (!loader) {
    if (code !== "en") return loadLocale("en");
    return {};
  }
  const mod = (await loader()) as { default: Record<string, unknown> };
  const dict = sanitize(mod.default);
  cache.set(code, dict);
  return dict;
}

export function isSupported(code: string): boolean {
  return LANGUAGES.some((l) => l.code === code);
}

// ISO 639-2/T (3-letter) -> 639-1 (2-letter) for codes some TVs report.
const ISO3_TO_ISO1: Record<string, string> = {
  eng: "en",
  ara: "ar",
  afr: "af",
  amh: "am",
  aze: "az",
  bel: "be",
  bul: "bg",
  ben: "bn",
  cat: "ca",
  ces: "cs",
  cze: "cs",
  dan: "da",
  deu: "de",
  ger: "de",
  ell: "el",
  gre: "el",
  spa: "es",
  est: "et",
  eus: "eu",
  baq: "eu",
  fas: "fa",
  per: "fa",
  fin: "fi",
  fra: "fr",
  fre: "fr",
  gle: "ga_IE",
  heb: "he",
  hin: "hi",
  hrv: "hr",
  hun: "hu",
  ind: "id",
  ita: "it",
  jpn: "ja",
  kaz: "kk",
  kor: "ko",
  kur: "ku",
  lav: "lv",
  msa: "ms",
  may: "ms",
  nld: "nl",
  dut: "nl",
  nor: "no",
  pol: "pl",
  por: "pt",
  que: "qu",
  ron: "ro",
  rum: "ro",
  rus: "ru",
  slk: "sk",
  slo: "sk",
  slv: "sl",
  sqi: "sq",
  alb: "sq",
  srp: "sr",
  swe: "sv",
  tur: "tr",
  urd: "ur",
  zho: "zh",
  chi: "zh",
};

/**
 * Normalize a raw locale string from the OS (e.g. "tr-TR", "pt_BR",
 * "eng_USA", "zh-Hans-CN", "en_US.UTF-8") into a supported language code,
 * or null if unsupported.
 */
export function resolveLanguage(raw?: string | null): string | null {
  if (!raw) return null;
  // Strip encoding/charset and normalize separators.
  let s = String(raw).split(".")[0].split("@")[0].trim().replace(/-/g, "_");
  if (!s) return null;

  // Exact match with region (e.g. pt_BR, ga_IE).
  if (isSupported(s)) return s;

  const parts = s.split("_");
  let lang = parts[0].toLowerCase();

  // Map 3-letter codes to 2-letter when needed.
  if (lang.length === 3 && ISO3_TO_ISO1[lang]) {
    const mapped = ISO3_TO_ISO1[lang];
    if (isSupported(mapped)) return mapped;
    lang = mapped.split("_")[0];
  }

  // Region-specific variants we explicitly support.
  if (lang === "pt" && /br/i.test(parts[1] || "")) return "pt_BR";
  if (lang === "ga") return "ga_IE";

  if (isSupported(lang)) return lang;
  return null;
}

export function detectInitialLanguage(): string {
  if (typeof navigator !== "undefined") {
    for (const cand of navigator.languages || [navigator.language]) {
      const resolved = resolveLanguage(cand);
      if (resolved) return resolved;
    }
  }
  return "en";
}

export function interpolate(
  template: string,
  params?: Record<string, string | number>
): string {
  if (!params) return template;
  return template.replace(/\{(\w+)\}/g, (_, key) =>
    params[key] != null ? String(params[key]) : `{${key}}`
  );
}
