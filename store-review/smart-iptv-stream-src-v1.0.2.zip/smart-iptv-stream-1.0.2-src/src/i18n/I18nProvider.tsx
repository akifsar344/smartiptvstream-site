import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { storage } from "../platform/storage";
import { getSystemLocale } from "../platform/device";
import {
  Dict,
  RTL_LANGUAGES,
  detectInitialLanguage,
  interpolate,
  loadLocale,
  resolveLanguage,
} from "./index";

type TFunc = (key: string, params?: Record<string, string | number>) => string;

interface I18nContextValue {
  lang: string;
  setLang: (code: string) => void;
  t: TFunc;
  rtl: boolean;
  ready: boolean;
}

const I18nContext = createContext<I18nContextValue | null>(null);

const LANG_KEY = "app_language";

export function I18nProvider({ children }: { children: React.ReactNode }) {
  // If the user has explicitly chosen a language, honor it. Otherwise start
  // with a synchronous best guess and refine it from the TV system locale.
  const stored = storage.getString(LANG_KEY);
  const [lang, setLangState] = useState<string>(
    () => stored || detectInitialLanguage()
  );
  const [dict, setDict] = useState<Dict>({});
  const [fallback, setFallback] = useState<Dict>({});
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let active = true;
    loadLocale("en").then((d) => active && setFallback(d));
    return () => {
      active = false;
    };
  }, []);

  // Detect the TV's UI language (async luna/systeminfo) when the user has not
  // pinned a language manually.
  useEffect(() => {
    if (stored) return;
    let active = true;
    getSystemLocale()
      .then((raw) => {
        const resolved = resolveLanguage(raw);
        if (active && resolved) setLangState(resolved);
      })
      .catch(() => {
        /* keep best-guess language */
      });
    return () => {
      active = false;
    };
  }, [stored]);

  useEffect(() => {
    let active = true;
    setReady(false);
    loadLocale(lang).then((d) => {
      if (!active) return;
      setDict(d);
      setReady(true);
    });
    const rtl = RTL_LANGUAGES.has(lang) || RTL_LANGUAGES.has(lang.split("_")[0]);
    document.documentElement.dir = rtl ? "rtl" : "ltr";
    document.documentElement.lang = lang;
    return () => {
      active = false;
    };
  }, [lang]);

  const setLang = useCallback((code: string) => {
    storage.setString(LANG_KEY, code);
    setLangState(code);
  }, []);

  const t = useCallback<TFunc>(
    (key, params) => {
      const raw = dict[key] ?? fallback[key] ?? key;
      return interpolate(raw, params);
    },
    [dict, fallback]
  );

  const rtl = useMemo(
    () => RTL_LANGUAGES.has(lang) || RTL_LANGUAGES.has(lang.split("_")[0]),
    [lang]
  );

  const value = useMemo<I18nContextValue>(
    () => ({ lang, setLang, t, rtl, ready }),
    [lang, setLang, t, rtl, ready]
  );

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}

export function useT(): TFunc {
  return useI18n().t;
}
