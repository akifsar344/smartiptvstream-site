import { useEffect, useRef, useState } from "react";
import { useI18n, useT } from "../../i18n/I18nProvider";
import { backend } from "../../data/api/backend";
import { appHashUrl } from "../../platform/appUrl";
import { mountCleengCheckout } from "./cleengWidget";

// Standalone, login-free checkout page opened from the QR code on a phone. It
// reads the short-lived checkout token from the URL, mints Cleeng SSO tokens for
// the bound account, and mounts the hosted checkout widget. Rendered OUTSIDE the
// TV Stage so it is fully responsive on phones.
function tokenFromUrl(): string {
  try {
    // HashRouter URL looks like https://host/#/pay?t=XYZ
    const hash = window.location.hash || "";
    const q = hash.includes("?") ? hash.slice(hash.indexOf("?") + 1) : window.location.search.slice(1);
    return new URLSearchParams(q).get("t") || "";
  } catch {
    return "";
  }
}

export function PayLinkScreen() {
  const t = useT();
  const { lang } = useI18n();
  const hostRef = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<"loading" | "ready" | "success" | "error">("loading");
  const [error, setError] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      // Cleeng redirects here with ?checkout=success after a completed payment.
      if (/checkout=success/.test(window.location.href)) {
        setPhase("success");
        return;
      }
      const token = tokenFromUrl();
      if (!token) {
        setError(t("payLinkExpired"));
        setPhase("error");
        return;
      }
      try {
        const data = await backend.cleengCheckoutPublic(token);
        if (cancelled) return;
        const successUrl = appHashUrl("/pay", "checkout=success");
        if (hostRef.current) {
          await mountCleengCheckout(hostRef.current, data, lang, successUrl);
        }
        if (!cancelled) setPhase("ready");
      } catch {
        if (cancelled) return;
        setError(t("payLinkExpired"));
        setPhase("error");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [t, lang]);

  return (
    <div
      style={{
        minHeight: "100vh",
        width: "100%",
        background: "linear-gradient(160deg, #14002e 0%, #0a0a1a 100%)",
        color: "#fff",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "28px 16px 48px",
        boxSizing: "border-box",
      }}
    >
      <h1 style={{ fontSize: 22, fontWeight: 800, margin: "8px 0 18px", textAlign: "center" }}>
        {t("payLinkTitle")}
      </h1>

      {phase === "loading" && (
        <div style={{ marginTop: 40, color: "rgba(255,255,255,0.8)", fontWeight: 600 }}>{t("commonProcessing")}</div>
      )}

      {phase === "error" && (
        <div style={{ marginTop: 40, color: "#FFB74D", textAlign: "center", maxWidth: 420 }}>{error}</div>
      )}

      {phase === "success" && (
        <div style={{ marginTop: 40, color: "#A5D6A7", textAlign: "center", maxWidth: 420, fontSize: 16, fontWeight: 700 }}>
          {t("payLinkSuccess")}
        </div>
      )}

      <div
        ref={hostRef}
        style={{
          width: "100%",
          maxWidth: 460,
          background: "#fff",
          borderRadius: 16,
          overflow: "hidden",
          display: phase === "ready" ? "block" : "none",
        }}
      />
    </div>
  );
}
