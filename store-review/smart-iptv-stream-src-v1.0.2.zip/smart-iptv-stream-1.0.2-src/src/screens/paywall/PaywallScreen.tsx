import { useEffect, useRef, useState } from "react";
import QRCode from "qrcode";
import { useNavigate } from "react-router-dom";
import { useI18n, useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { ScreenHeader } from "../../components/ScreenHeader";
import { Button } from "../../components/Button";
import { Icon } from "../../components/Icon";
import { useBack } from "../../navigation/useBack";
import { useFocusable } from "../../navigation/useFocusable";
import { colors, gradient } from "../../styles/theme";
import { useAccess } from "../../store/access";
import { useAuth } from "../../store/auth";
import { backend } from "../../data/api/backend";
import { appHashUrl } from "../../platform/appUrl";
import { IS_EXT, IS_SAFARI_EXT, openHostedTab } from "../../platform/ext";
import { mountCleengCheckout } from "./cleengWidget";

// Displayed price is configured at build time (VITE_PRICE). Checkout itself uses
// Cleeng's embedded, SSO pre-authenticated widget — no external URL needed.
const PRICE = (import.meta.env.VITE_PRICE as string) || "$5.99";

function usePaywallPrice(): string {
  return PRICE;
}

function formatRemaining(ms: number): string {
  const totalMin = Math.max(0, Math.floor(ms / 60000));
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h > 0) return `${h}h ${m}m`;
  return `${m}m`;
}

export function PaywallScreen() {
  const t = useT();
  const navigate = useNavigate();
  const isPro = useAccess((s) => s.isPro);
  const blocked = useAccess((s) => s.blocked);
  const trialRemainingMs = useAccess((s) => s.trialRemainingMs);
  const refresh = useAccess((s) => s.refresh);

  const [view, setView] = useState<"plans" | "pair">("plans");

  // When the trial is still running (manual visit) Back returns home; when the
  // app is locked the only ways out are activating Pro or exiting the app.
  useBack(() => {
    if (view === "pair" && !isPro) {
      setView("plans");
      return true;
    }
    navigate(Routes.home);
    return true;
  });

  const onBack = () => {
    // Pro / trial users have a usable app to return to. A locked web user can't
    // "exit" a browser tab, so offer sign-out (switch account) instead.
    if (blocked && !isPro) useAuth.getState().logout();
    else navigate(Routes.home);
  };

  return (
    <div className="fullbg scrollable" style={{ display: "flex", flexDirection: "column", minHeight: "100%" }}>
      <ScreenHeader
        title={isPro ? t("paywallProUnlockedTitle") : blocked ? t("paywallTrialExpiredTitle") : t("premiumFeatures")}
        onBack={onBack}
      />
      {isPro ? (
        <ProUnlockedView onContinue={() => navigate(Routes.home, { replace: true })} />
      ) : view === "plans" ? (
        <PlansView
          blocked={blocked}
          trialMs={trialRemainingMs()}
          onActivate={() => setView("pair")}
          onRestore={async () => {
            await refresh();
          }}
        />
      ) : (
        <PairView onBack={() => setView("plans")} />
      )}
    </div>
  );
}

function ProUnlockedView({ onContinue }: { onContinue: () => void }) {
  const t = useT();
  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "40px", gap: 18 }}>
      <div
        style={{
          width: 96,
          height: 96,
          borderRadius: "50%",
          background: gradient(["#C2185B", "#6A1B9A"]),
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: "0 0 40px rgba(194,24,91,0.6)",
        }}
      >
        <Icon name="workspace_premium" size={56} color="#FFD700" />
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <h1 style={{ fontSize: 30, fontWeight: 900 }}>{t("paywallProUnlockedTitle")}</h1>
        <span style={{ padding: "4px 12px", borderRadius: 999, background: "#FFD700", color: "#3A1010", fontSize: 16, fontWeight: 900, letterSpacing: 1 }}>PRO</span>
      </div>
      <p style={{ color: "rgba(255,255,255,0.8)", fontSize: 16, textAlign: "center", maxWidth: 560 }}>
        {t("paywallProUnlockedSubtitle")}
      </p>
      <p style={{ color: "rgba(255,255,255,0.55)", fontSize: 14, textAlign: "center", maxWidth: 560 }}>
        {t("paywallProUnlockedThanks")}
      </p>
      <div style={{ marginTop: 14 }}>
        <Button label={t("paywallProUnlockedCta")} onTap={onContinue} focusKey="paywall-continue" autoFocus />
      </div>
    </div>
  );
}

function PlansView({
  blocked,
  trialMs,
  onActivate,
  onRestore,
}: {
  blocked: boolean;
  trialMs: number;
  onActivate: () => void;
  onRestore: () => void;
}) {
  const t = useT();
  const features = [
    t("paywallFeatureMultiscreenTitle"),
    t("paywallFeatureParentalTitle"),
    t("paywallFeatureTimeMachineTitle"),
    t("paywallFeaturePlaybackTitle"),
    t("paywallFeatureContinueWatchingTitle"),
    t("paywallFeatureAdFreeTitle"),
  ];

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", padding: "28px 40px 60px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 6 }}>
        <Icon name="workspace_premium" size={36} color={colors.iconFg.premium} />
        <h1 style={{ fontSize: 26, fontWeight: 800 }}>{t("paywallHeroTitle")}</h1>
      </div>
      <p style={{ color: "rgba(255,255,255,0.6)", marginBottom: 6, textAlign: "center" }}>
        {blocked ? t("paywallTrialExpiredBody") : t("paywallHeroSubtitle")}
      </p>
      {!blocked && trialMs > 0 && (
        <div style={{ marginBottom: 14, padding: "6px 14px", borderRadius: 999, background: "rgba(76,175,80,0.18)", border: "1px solid rgba(76,175,80,0.5)", color: "#A5D6A7", fontSize: 13, fontWeight: 700 }}>
          {t("paywallTrialRemaining", { time: formatRemaining(trialMs) })}
        </div>
      )}

      <div style={{ display: "flex", gap: 30, alignItems: "center", marginTop: 18, flexWrap: "wrap", justifyContent: "center" }}>
        {/* Features list */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, width: 460 }}>
          {features.map((f) => (
            <div key={f} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 14px", borderRadius: 10, background: gradient(["rgba(255,255,255,0.08)", "rgba(255,255,255,0.03)"]), border: "1px solid rgba(255,255,255,0.12)" }}>
              <Icon name="star" size={18} color={colors.iconFg.premium} />
              <span style={{ fontSize: 14, fontWeight: 600 }}>{f}</span>
            </div>
          ))}
        </div>

        {/* Plan card */}
        <PlanCard onActivate={onActivate} />
      </div>

      <div style={{ marginTop: 26 }}>
        <Button label={t("paywallTrialExpiredRestore")} variant="ghost" onTap={onRestore} focusKey="paywall-restore" />
      </div>
    </div>
  );
}

function PlanCard({ onActivate }: { onActivate: () => void }) {
  const t = useT();
  const price = usePaywallPrice();
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onActivate, autoFocus: true, focusKey: "paywall-plan" });
  return (
    <div
      ref={ref}
      onClick={onActivate}
      className="focusable"
      style={{
        width: 300,
        padding: 24,
        borderRadius: 18,
        cursor: "pointer",
        background: gradient(["#C2185B", "#6A1B9A"]),
        border: focused ? "3px solid #fff" : "2px solid rgba(255,255,255,0.25)",
        boxShadow: focused ? "0 0 30px rgba(194,24,91,0.7)" : "0 10px 30px rgba(0,0,0,0.4)",
        transform: focused ? "scale(1.04)" : "scale(1)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 8,
      }}
    >
      <div style={{ fontSize: 16, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", opacity: 0.9 }}>
        {t("paywallMembershipPlanLifetime")}
      </div>
      <div style={{ fontSize: 44, fontWeight: 900 }}>{price}</div>
      <div style={{ fontSize: 13, opacity: 0.85, textAlign: "center" }}>{t("paywallOneTime")}</div>
      <div
        style={{
          marginTop: 12,
          padding: "12px 28px",
          borderRadius: 12,
          background: focused ? "#fff" : "rgba(255,255,255,0.18)",
          color: focused ? "#6A1B9A" : "#fff",
          fontSize: 16,
          fontWeight: 800,
          display: "flex",
          alignItems: "center",
          gap: 8,
        }}
      >
        <Icon name="workspace_premium" size={20} color={focused ? "#6A1B9A" : "#FFD700"} />
        {t("paywallTrialExpiredCta")}
      </div>
    </div>
  );
}

function PairView({ onBack }: { onBack: () => void }) {
  const t = useT();
  const { lang } = useI18n();
  const price = usePaywallPrice();
  const refresh = useAccess((s) => s.refresh);
  const email = useAuth((s) => s.email);
  const hostRef = useRef<HTMLDivElement>(null);
  const [phase, setPhase] = useState<"loading" | "ready" | "error">("loading");
  const [error, setError] = useState<string>("");
  const [activating, setActivating] = useState(false);
  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [payToken, setPayToken] = useState<string>("");

  // Prepare & mount the Cleeng checkout widget, SSO-authenticated as this
  // account so the purchase (and its webhook) is attributed to this email. Also
  // build a QR that opens a phone checkout for the same account (TV browsers).
  useEffect(() => {
    // Safari sells Pro through the container app, so there is no checkout to
    // prepare here (and no QR, which would also be a link out of the app).
    if (IS_SAFARI_EXT) {
      setPhase("ready");
      return;
    }
    let cancelled = false;
    (async () => {
      setPhase("loading");
      setError("");
      const token = useAuth.getState().token;
      if (!token) {
        setError(t("pairAuthRequired"));
        setPhase("error");
        return;
      }
      try {
        const data = await backend.cleengCheckout(token);
        if (cancelled) return;
        // The extension can't mount Cleeng's remote widget (MV3 CSP blocks the
        // external script); instead we open the hosted checkout in a tab below.
        if (!IS_EXT && hostRef.current) {
          await mountCleengCheckout(hostRef.current, data, lang, window.location.href);
        }
        if (cancelled) return;
        setPayToken(data.linkToken || "");
        setPhase("ready");

        if (data.linkToken) {
          const payUrl = appHashUrl(Routes.payLink, `t=${encodeURIComponent(data.linkToken)}`);
          void QRCode.toDataURL(payUrl, { width: 240, margin: 1, color: { dark: "#0a0a1a", light: "#ffffff" } })
            .then((u) => !cancelled && setQrDataUrl(u))
            .catch(() => {});
        }
      } catch {
        if (cancelled) return;
        setError(t("pairCheckoutUnavailable"));
        setPhase("error");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [t, lang]);

  // The webhook flips the account to Pro server-side after payment (whether the
  // buyer paid here or on their phone). Poll /me so the app unlocks automatically.
  useEffect(() => {
    let cancelled = false;
    let inFlight = false;
    const poll = async () => {
      if (inFlight) return;
      inFlight = true;
      try {
        const pro = await refresh();
        if (pro && !cancelled) setActivating(true);
      } catch {
        /* transient */
      } finally {
        inFlight = false;
      }
    };
    const id = setInterval(poll, 3000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [refresh]);

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", padding: "24px 40px 60px" }}>
      <h2 style={{ fontSize: 22, fontWeight: 800, marginBottom: 6 }}>{t("paywallMembershipPlanLifetime")} · {price}</h2>
      <p style={{ color: "rgba(255,255,255,0.7)", marginBottom: 6, textAlign: "center", maxWidth: 620 }}>
        {t("paywallOneTimeLifetimeNote")}
      </p>
      {email && (
        <p style={{ color: "rgba(255,255,255,0.5)", marginBottom: 18, fontSize: 14 }}>
          {t("paywallPurchasingFor")} <b style={{ color: "#fff" }}>{email}</b>
        </p>
      )}

      {phase === "error" && (
        <div style={{ color: "#FFB74D", marginBottom: 18, textAlign: "center", maxWidth: 560 }}>{error}</div>
      )}

      {phase === "loading" && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "24px 0", color: "rgba(255,255,255,0.85)", fontSize: 14, fontWeight: 600 }}>
          <Spinner />
          <span>{t("commonProcessing")}</span>
        </div>
      )}

      <div style={{ display: "flex", gap: 40, alignItems: "flex-start", justifyContent: "center", flexWrap: "wrap", width: "100%" }}>
        {/* Option 1 — pay right here (best on desktop/laptop). In the extension
            the checkout opens in a new browser tab instead of an inline widget. */}
        {IS_SAFARI_EXT ? (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, maxWidth: 360 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.85)" }}>{t("payAppleTitle")}</div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", textAlign: "center", lineHeight: 1.5 }}>
              {t("payAppleHint")}
            </div>
          </div>
        ) : IS_EXT ? (
          phase === "ready" && (
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, maxWidth: 320 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.85)" }}>{t("payHereTitle")}</div>
              <Button
                label={t("paywallTrialExpiredCta")}
                onTap={() =>
                  openHostedTab(Routes.payLink, payToken ? `t=${encodeURIComponent(payToken)}` : "")
                }
                focusKey="paywall-payext"
                autoFocus
              />
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", textAlign: "center" }}>
                {t("payHereHint")}
              </div>
            </div>
          )
        ) : (
          <div style={{ display: phase === "ready" ? "flex" : "none", flexDirection: "column", alignItems: "center", gap: 10 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.85)" }}>{t("payHereTitle")}</div>
            <div
              ref={hostRef}
              style={{ width: "100%", maxWidth: 460, minHeight: 320, background: "#fff", borderRadius: 16, overflow: "hidden" }}
            />
          </div>
        )}

        {/* Option 2 — pay on a phone via QR (best in a TV browser). */}
        {qrDataUrl && (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10, maxWidth: 260 }}>
            <div style={{ fontSize: 14, fontWeight: 700, color: "rgba(255,255,255,0.85)" }}>{t("payPhoneTitle")}</div>
            <div style={{ width: 240, height: 240, borderRadius: 16, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
              <img src={qrDataUrl} alt="QR" style={{ width: 232, height: 232 }} />
            </div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", textAlign: "center" }}>{t("payPhoneHint")}</div>
          </div>
        )}
      </div>

      {activating && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 16, color: "#A5D6A7", fontSize: 14, fontWeight: 700 }}>
          <Spinner />
          <span>{t("paywallActivating")}</span>
        </div>
      )}

      <div style={{ display: "flex", gap: 12, marginTop: 30 }}>
        <Button label={t("back")} variant="ghost" onTap={onBack} focusKey="paywall-pairback" autoFocus />
      </div>
    </div>
  );
}

function Spinner() {
  return (
    <div
      style={{
        width: 16,
        height: 16,
        border: "2px solid rgba(255,255,255,0.3)",
        borderTopColor: "#fff",
        borderRadius: "50%",
        animation: "spin 0.8s linear infinite",
      }}
    />
  );
}
