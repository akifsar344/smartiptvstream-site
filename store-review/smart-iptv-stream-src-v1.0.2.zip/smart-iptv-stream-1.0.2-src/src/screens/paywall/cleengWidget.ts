import type { CleengCheckout } from "../../data/api/backend";

// Cleeng's widget ships UI + offer-description translations for a fixed set of
// locales. Map the site language onto the nearest supported Cleeng locale;
// anything unsupported falls back to en-US.
const CLEENG_LANGUAGE_MAP: Record<string, string> = {
  en: "en-US", ar: "ar-AE", nl: "nl-NL", fr: "fr-FR", de: "de-DE",
  it: "it-IT", es: "es-ES", ca: "es-ES", eu: "es-ES", pt: "pt-PT", pt_BR: "pt-BR",
};

export function cleengLanguage(lang: string): string {
  if (CLEENG_LANGUAGE_MAP[lang]) return CLEENG_LANGUAGE_MAP[lang];
  const base = lang.split(/[-_]/)[0];
  return CLEENG_LANGUAGE_MAP[base] || "en-US";
}

declare global {
  interface Window {
    cleeng?: {
      setAuthTokens?: (t: { jwt: string; refreshToken: string }) => Promise<void> | void;
      logout?: () => Promise<void> | void;
    };
  }
}

// Loads Cleeng's widget SDK. Re-adds the script each call so its DOM observer
// re-scans and mounts a freshly-rendered checkout element.
export function loadCleengScript(sandbox: boolean): Promise<void> {
  return new Promise((resolve, reject) => {
    document.getElementById("cleeng-sdk")?.remove();
    const s = document.createElement("script");
    s.type = "module";
    s.id = "cleeng-sdk";
    s.src = sandbox
      ? "https://widgets.sandbox.cleeng.com/cleeng.js"
      : "https://widgets.prod.cleeng.com/cleeng.js";
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("cleeng-script-failed"));
    document.head.appendChild(s);
  });
}

// Loads the SDK, authenticates as our customer, and mounts the hosted checkout
// widget inside `host`. `successUrl` is where the widget redirects after payment.
export async function mountCleengCheckout(
  host: HTMLElement,
  data: CleengCheckout,
  lang: string,
  successUrl: string
): Promise<void> {
  if (!data.publisherId || !data.offerId) throw new Error("unconfigured");

  await loadCleengScript(!!data.sandbox);

  try {
    if (window.cleeng) {
      if (data.jwt && data.refreshToken && typeof window.cleeng.setAuthTokens === "function") {
        await window.cleeng.setAuthTokens({ jwt: data.jwt, refreshToken: data.refreshToken });
      } else if (typeof window.cleeng.logout === "function") {
        await window.cleeng.logout();
      }
    }
  } catch {
    /* non-fatal */
  }

  const props = JSON.stringify({
    checkout: { mode: "standard", paymentSuccessRedirectUrl: successUrl },
  });
  host.innerHTML = `
    <div id="cleengCheckout"
         data-cleeng-widget="checkout"
         data-cleeng-publisher-id="${data.publisherId}"
         data-cleeng-offer-id="${data.offerId}"
         data-cleeng-language="${cleengLanguage(lang)}"
         data-cleeng-props='${props}'></div>`;
}
