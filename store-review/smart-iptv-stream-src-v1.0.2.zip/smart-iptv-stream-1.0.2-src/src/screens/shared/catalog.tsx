// Shared catalog UI primitives used by Movies & Series screens. These mirror
// the Live TV layout one-to-one: a searchable category column (with ALL,
// FAVOURITES, RECENTLY WATCHED pseudo-categories and a per-category gear) plus
// a searchable poster grid where each poster has a context menu button.
import { useEffect } from "react";
import { FocusInput } from "../../components/FocusInput";
import { useFocusable } from "../../navigation/useFocusable";
import { focusManager, Direction } from "../../navigation/focusManager";
import { Icon } from "../../components/Icon";
import { colors } from "../../styles/theme";

export type CatKind = "all" | "fav" | "recent" | "cat";

export function Column({
  flex,
  title,
  children,
}: {
  flex: number;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        flex,
        minWidth: 0,
        display: "flex",
        flexDirection: "column",
        background: "rgba(6,23,86,0.45)",
        borderRadius: 12,
        border: "1px solid rgba(255,255,255,0.08)",
        overflow: "hidden",
      }}
    >
      <div style={{ padding: "10px 14px 4px", fontSize: 12, fontWeight: 800, letterSpacing: 1, color: "rgba(255,255,255,0.55)" }}>
        {title}
      </div>
      {children}
    </div>
  );
}

export function SearchBox({
  value,
  onChange,
  placeholder,
  focusKey,
  onArrow,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  focusKey: string;
  onArrow: (d: Direction) => boolean;
}) {
  return (
    <div style={{ padding: "4px 10px 6px" }}>
      <FocusInput value={value} onChange={onChange} placeholder={placeholder} focusKey={focusKey} />
      <ArrowProxy focusKey={focusKey} onArrow={onArrow} />
    </div>
  );
}

function ArrowProxy({
  focusKey,
  onArrow,
}: {
  focusKey: string;
  onArrow: (d: Direction) => boolean;
}) {
  useEffect(() => {
    focusManager.update(focusKey, { onArrow: (d) => onArrow(d) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusKey, onArrow]);
  return null;
}

export function CatRow({
  id,
  name,
  count,
  kind,
  locked,
  selected,
  autoFocus,
  onFocus,
  onEnter,
  onGear,
  onItems,
  onUp,
  onDown,
  prevId,
  nextId,
}: {
  id: string;
  name: string;
  count: number;
  kind: CatKind;
  locked: boolean;
  selected: boolean;
  autoFocus?: boolean;
  onFocus: () => void;
  onEnter: () => void;
  onGear: () => void;
  onItems: () => void;
  onUp?: () => void;
  onDown?: () => void;
  prevId?: string;
  nextId?: string;
}) {
  const hasGear = kind === "cat" || kind === "fav" || kind === "recent";
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: `cat-name-${id}`,
    autoFocus,
    onEnter,
    onFocus,
    onArrow: (d) => {
      // Up/down stay strictly inside the category column so the cursor never
      // jumps into the poster grid on its own — the user moves right when ready.
      if (d === "up" && onUp) return onUp(), true;
      if (d === "down") return onDown ? (onDown(), true) : true;
      if (d === "right") return hasGear ? focusManager.focus(`cat-gear-${id}`) : (onItems(), true);
      return false;
    },
  });
  return (
    <div style={{ display: "flex", alignItems: "center", marginBottom: 4, gap: 4 }}>
      <div
        ref={ref}
        onClick={onEnter}
        className="focusable"
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "11px 12px",
          borderRadius: 10,
          cursor: "pointer",
          minWidth: 0,
          background: focused ? "#3D58BA" : selected ? "rgba(61,88,186,0.4)" : "transparent",
          border: focused ? "2px solid #fff" : "2px solid transparent",
        }}
      >
        {locked && <Icon name="lock" size={14} color="#FF5252" />}
        <span style={{ flex: 1, fontSize: 13, fontWeight: selected || focused ? 700 : 500, color: "#fff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {name}
        </span>
        <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>{count}</span>
      </div>
      {hasGear && <CatGear id={id} kind={kind} onGear={onGear} onItems={onItems} prevId={prevId} nextId={nextId} />}
    </div>
  );
}

function CatGear({
  id,
  kind,
  onGear,
  onItems,
  prevId,
  nextId,
}: {
  id: string;
  kind: string;
  onGear: () => void;
  onItems: () => void;
  prevId?: string;
  nextId?: string;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: `cat-gear-${id}`,
    onEnter: onGear,
    onArrow: (d) => {
      if (d === "left") return focusManager.focus(`cat-name-${id}`);
      if (d === "right") return onItems(), true;
      // Keep up/down inside the gear column instead of leaking to the grid.
      if (d === "up") return prevId ? focusManager.focus(`cat-gear-${prevId}`) : true;
      if (d === "down") return nextId ? focusManager.focus(`cat-gear-${nextId}`) : true;
      return false;
    },
  });
  const icon = kind === "fav" || kind === "recent" ? "delete" : "settings";
  return (
    <div
      ref={ref}
      onClick={onGear}
      className="focusable"
      style={{
        width: 34,
        height: 34,
        borderRadius: 8,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flex: "0 0 auto",
        cursor: "pointer",
        background: focused ? "#fff" : "rgba(255,255,255,0.08)",
        border: focused ? "2px solid #fff" : "1px solid rgba(255,255,255,0.12)",
      }}
    >
      <Icon name={icon} size={18} color={focused ? colors.primary : "rgba(255,255,255,0.7)"} />
    </div>
  );
}

// Poster + corner context-menu button. Navigation is fully explicit (index
// based) so the grid steps poster -> menu -> next poster, matching Live TV's
// row -> menu pattern. The owning screen supplies the arrow handlers.
export function GridCard({
  fkey,
  title,
  image,
  rating,
  locked,
  fav,
  progress,
  autoFocus,
  onOpen,
  onMenu,
  onArrowPoster,
  onArrowMenu,
}: {
  fkey: string;
  title: string;
  image?: string;
  rating?: string;
  locked?: boolean;
  fav?: boolean;
  /** Watch progress 0..1 for partially-watched items (red bar on poster). */
  progress?: number;
  autoFocus?: boolean;
  onOpen: () => void;
  onMenu: () => void;
  onArrowPoster: (d: Direction) => boolean;
  onArrowMenu: (d: Direction) => boolean;
}) {
  const poster = useFocusable<HTMLDivElement>({
    focusKey: fkey,
    autoFocus,
    onEnter: onOpen,
    onArrow: onArrowPoster,
  });
  const menu = useFocusable<HTMLDivElement>({
    focusKey: `${fkey}-m`,
    onEnter: onMenu,
    onArrow: onArrowMenu,
  });
  return (
    <div style={{ width: "100%", display: "flex", flexDirection: "column", position: "relative" }}>
      {/* 2:3 poster box via padding-bottom (works on older webOS Chromium that
          lacks CSS aspect-ratio support). */}
      <div
        ref={poster.ref}
        onClick={onOpen}
        className="focusable"
        style={{
          width: "100%",
          height: 0,
          paddingBottom: "150%",
          borderRadius: 12,
          overflow: "hidden",
          background: "rgba(255,255,255,0.06)",
          border: poster.focused ? "3px solid #fff" : "1px solid rgba(255,255,255,0.1)",
          boxShadow: poster.focused ? `0 0 22px ${colors.btn}` : "0 6px 14px rgba(0,0,0,0.4)",
          position: "relative",
          transform: poster.focused ? "scale(1.05)" : "scale(1)",
          zIndex: poster.focused ? 5 : 1,
          cursor: "pointer",
        }}
      >
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
          {image ? (
            <img
              src={image}
              alt={title}
              loading="lazy"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
              onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
            />
          ) : (
            <Icon name="movie" size={48} color="rgba(255,255,255,0.3)" />
          )}
        </div>
        {rating && Number(rating) > 0 && (
          <div style={{ position: "absolute", top: 8, left: 8, padding: "2px 8px", borderRadius: 6, background: "rgba(0,0,0,0.7)", fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", gap: 3 }}>
            <Icon name="star" size={12} color="#FFB300" />
            {Number(rating).toFixed(1)}
          </div>
        )}
        {locked && (
          <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.55)", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Icon name="lock" size={40} color="#FF5252" />
          </div>
        )}
        {fav && (
          <div style={{ position: "absolute", bottom: progress != null && progress > 0 ? 14 : 8, left: 8 }}>
            <Icon name="favorite" size={18} color="#FF80AB" />
          </div>
        )}
        {progress != null && progress > 0 && (
          <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 5, background: "rgba(0,0,0,0.55)" }}>
            <div style={{ width: `${Math.min(100, Math.max(3, progress * 100))}%`, height: "100%", background: "#E53935" }} />
          </div>
        )}
      </div>

      {/* context menu button */}
      <div
        ref={menu.ref}
        onClick={onMenu}
        className="focusable"
        style={{
          position: "absolute",
          top: 8,
          right: 8,
          width: 34,
          height: 34,
          borderRadius: 8,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          zIndex: 6,
          background: menu.focused ? "#fff" : "rgba(0,0,0,0.6)",
          border: menu.focused ? "2px solid #fff" : "1px solid rgba(255,255,255,0.25)",
        }}
      >
        <Icon name="more_vert" size={18} color={menu.focused ? colors.primary : "#fff"} />
      </div>

      <span
        style={{
          marginTop: 8,
          fontSize: 13,
          fontWeight: 600,
          color: poster.focused ? "#fff" : "rgba(255,255,255,0.8)",
          textAlign: "center",
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap",
        }}
      >
        {title}
      </span>
    </div>
  );
}
