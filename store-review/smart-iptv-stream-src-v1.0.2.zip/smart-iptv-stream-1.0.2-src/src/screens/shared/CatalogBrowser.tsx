import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { TopBar } from "../../components/TopBar";
import { Icon } from "../../components/Icon";
import {
  OptionMenu,
  RenamePrompt,
  PinDialog,
  ConfirmDialog,
  SortDialog,
  SortOption,
} from "../../components/Overlay";
import { focusManager } from "../../navigation/focusManager";
import { useBack } from "../../navigation/useBack";
import { Category } from "../../data/models";
import { useUserData } from "../../store/userdata";
import { useFavorites, FavKind } from "../../store/favorites";
import { useResume, ResumeKind } from "../../store/resume";
import { Column, SearchBox, CatRow, GridCard, CatKind } from "./catalog";

export interface BrowseItem {
  id: number;
  name: string;
  image: string;
  rating?: string;
  categoryId: string;
  /** Unix-ish timestamp used by the "recently added" sort. */
  added?: number;
  /** Release year used by the "year" sort. */
  year?: number;
}

const COLS = 5;
const MAX_ITEMS = 300;

export type SortKey = "default" | "new" | "az" | "za" | "year";

// Pull a 4-digit release year out of a title ("Movie (2023)" / "Movie 2019").
export function extractYear(title?: string): number {
  if (!title) return 0;
  const paren = title.match(/\((19|20)\d{2}\)/g);
  if (paren) {
    let best = 0;
    for (const m of paren) {
      const y = parseInt(m.slice(1, 5), 10);
      if (y > best) best = y;
    }
    if (best) return best;
  }
  const any = title.match(/(19|20)\d{2}/g);
  if (any) {
    let best = 0;
    for (const m of any) {
      const y = parseInt(m, 10);
      if (y >= 1900 && y <= 2100 && y > best) best = y;
    }
    return best;
  }
  return 0;
}

// Coerce an `added` / `last_modified` / `releaseDate` value to a comparable
// number (unix seconds, or a year promoted to a timestamp).
export function parseTs(value?: string | number): number {
  if (value == null || value === "") return 0;
  const n = typeof value === "number" ? value : parseInt(String(value).trim(), 10);
  if (!Number.isNaN(n)) {
    if (n > 31536000) return n; // unix seconds
    if (n > 1900 && n < 2100) return Date.UTC(n, 0, 1) / 1000; // plain year
    return n;
  }
  const s = String(value);
  if (s.includes("-") || s.includes("/")) {
    const t = Date.parse(s);
    if (!Number.isNaN(t)) return Math.trunc(t / 1000);
  }
  return 0;
}

function sortItems(list: BrowseItem[], key: SortKey): BrowseItem[] {
  if (key === "default") return list;
  const arr = list.slice();
  switch (key) {
    case "az":
      arr.sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
      break;
    case "za":
      arr.sort((a, b) => b.name.toLowerCase().localeCompare(a.name.toLowerCase()));
      break;
    case "new":
      arr.sort((a, b) => (b.added || 0) - (a.added || 0));
      break;
    case "year":
      arr.sort((a, b) => (b.year || 0) - (a.year || 0));
      break;
  }
  return arr;
}

// Sort selection persists per kind across screen remounts.
const sortMemory: Record<string, SortKey> = {};

// Remembers the last selected category + opened item per kind so returning from
// a detail page (which remounts this screen) restores the user's place instead
// of snapping back to ALL at the top.
const browseMemory: Record<string, { cat: string; itemId: number | null }> = {};

export function CatalogBrowser({
  kind,
  title,
  catTitle,
  itemTitle,
  categories,
  items,
  recentItems,
  onOpen,
  onBack,
}: {
  kind: "movie" | "series";
  title: string;
  catTitle: string;
  itemTitle: string;
  categories: Category[];
  items: BrowseItem[];
  recentItems: BrowseItem[];
  onOpen: (item: BrowseItem) => void;
  onBack: () => void;
}) {
  const t = useT();
  const navigate = useNavigate();
  const pin = useUserData((s) => s.pin);
  const lockedCats = useUserData((s) => s.lockedCats);
  const lockedChannels = useUserData((s) => s.lockedChannels);
  const catRenames = useUserData((s) => s.catRenames);
  const channelRenames = useUserData((s) => s.channelRenames);
  const favItemsRaw = useFavorites((s) => s.items);
  const resumeItems = useResume((s) => s.items);

  // Watch-progress ratio (0..1) for a poster. Movies key on streamId; series
  // posters reflect the most recently watched episode of that series.
  const progressFor = (id: number): number | undefined => {
    if (kind === "movie") {
      const r = resumeItems.find((x) => x.kind === "movie" && x.id === id);
      if (r && r.durationSec > 0 && r.positionSec > 10) {
        return Math.min(1, r.positionSec / r.durationSec);
      }
      return undefined;
    }
    const eps = resumeItems.filter(
      (x) => x.kind === "series" && x.seriesId === id && x.durationSec > 0 && x.positionSec > 10
    );
    if (!eps.length) return undefined;
    const latest = eps.reduce((a, b) => (b.updatedAt > a.updatedAt ? b : a));
    return Math.min(1, latest.positionSec / latest.durationSec);
  };

  const [selectedCat, setSelectedCat] = useState(() => browseMemory[kind]?.cat ?? "all");
  const [catQuery, setCatQuery] = useState("");
  const [itemQuery, setItemQuery] = useState("");
  const [modal, setModal] = useState<React.ReactNode>(null);
  const [unlockedCats, setUnlockedCats] = useState<Set<string>>(new Set());
  const [unlockedItems, setUnlockedItems] = useState<Set<number>>(new Set());
  // Bumped every time we want focus to jump into the poster grid; an effect
  // reacts to it so it works even when the visible list is unchanged.
  const [itemsFocusReq, setItemsFocusReq] = useState(0);
  const [sortKey, setSortKey] = useState<SortKey>(() => sortMemory[kind] ?? "default");
  const skipCatRefocus = useRef(false);
  const selectTimer = useRef<number | null>(null);
  const mountedOnce = useRef(false);
  const didRestore = useRef(false);

  useEffect(() => {
    sortMemory[kind] = sortKey;
  }, [kind, sortKey]);

  const favKind = kind as FavKind;
  const catKey = (cid: string) => `${kind}:cat:${cid}`;
  const itemKey = (id: number) => `${kind}:${id}`;

  const isCatLocked = (cid: string) => lockedCats.includes(catKey(cid));
  const isItemLocked = (id: number) => lockedChannels.includes(itemKey(id));
  const catLabel = (cid: string, fallback: string) =>
    catRenames[catKey(cid)] ?? fallback;
  const itemLabel = (id: number, fallback: string) =>
    channelRenames[itemKey(id)] ?? fallback;
  const isFav = (id: number) =>
    favItemsRaw.some((x) => x.kind === favKind && x.id === id);

  const closeModal = () => setModal(null);

  const openSort = () => {
    const opts: SortOption[] = [
      { key: "new", title: t("sortNewReleasesTitle"), subtitle: t("sortNewReleasesSubtitle"), icon: "new_releases" },
      { key: "az", title: t("sortAzTitle"), subtitle: t("sortAzSubtitle"), icon: "sort_by_alpha" },
      { key: "za", title: t("sortZaTitle"), subtitle: t("sortZaSubtitle"), icon: "sort" },
      { key: "year", title: t("sortYearTitle"), subtitle: t("sortYearSubtitle"), icon: "calendar_today" },
    ];
    setModal(
      <SortDialog
        title={t("sortBy")}
        subtitle={title}
        options={opts}
        selected={sortKey}
        onSelect={(k) => setSortKey(k as SortKey)}
        onClose={closeModal}
      />,
    );
  };

  useBack(() => {
    onBack();
    return true;
  });

  // After any modal/menu settles, keep focus in the category column instead of
  // letting it fall to the top-bar back button or a search box. Skipped on the
  // first mount so the place-restore effect below can win.
  useEffect(() => {
    if (!mountedOnce.current) {
      mountedOnce.current = true;
      return;
    }
    if (modal !== null) return;
    const id = window.setTimeout(() => {
      if (focusManager.hasActiveLayer()) return;
      // A category-enter (e.g. after PIN unlock) wants focus in the grid, not
      // back on the category column — honour that.
      if (skipCatRefocus.current) {
        skipCatRefocus.current = false;
        return;
      }
      if (!focusManager.focus(`cat-name-${selectedCat}`)) {
        focusManager.focus("cat-name-all");
      }
    }, 0);
    return () => clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modal]);

  // Move focus into the poster grid whenever requested.
  useEffect(() => {
    if (itemsFocusReq === 0) return;
    const id = window.setTimeout(() => {
      if (!focusManager.focus("it-0")) focusManager.focus("item-search");
    }, 0);
    return () => clearTimeout(id);
  }, [itemsFocusReq]);

  useEffect(() => () => {
    if (selectTimer.current) clearTimeout(selectTimer.current);
  }, []);

  const favItems = useMemo(
    () => items.filter((it) => isFav(it.id)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [items, favItemsRaw]
  );

  // Single-pass category counts; avoids an O(categories × items) scan on every
  // render (catalogs can have 100k+ items).
  const countByCat = useMemo(() => {
    const m = new Map<string, number>();
    for (const it of items) m.set(it.categoryId, (m.get(it.categoryId) || 0) + 1);
    return m;
  }, [items]);

  const rail = useMemo(() => {
    const q = catQuery.trim().toLowerCase();
    const base: { id: string; name: string; kind: CatKind; count: number }[] = [
      { id: "all", name: "ALL", kind: "all", count: items.length },
      { id: "fav", name: "FAVOURITES", kind: "fav", count: favItems.length },
      { id: "recent", name: "RECENTLY WATCHED", kind: "recent", count: recentItems.length },
    ];
    for (const c of categories) {
      const name = catLabel(c.categoryId, c.categoryName);
      const locked = isCatLocked(c.categoryId);
      if (q && (locked || !name.toLowerCase().includes(q))) continue;
      base.push({
        id: c.categoryId,
        name,
        kind: "cat",
        count: countByCat.get(c.categoryId) || 0,
      });
    }
    return base;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categories, items, favItems, recentItems, catQuery, lockedCats, catRenames, countByCat]);

  // Full list for the selected category (unsorted, unfiltered).
  const base = useMemo(() => {
    if (selectedCat === "all") return items;
    if (selectedCat === "fav") return favItems;
    if (selectedCat === "recent") return recentItems;
    return items.filter((it) => it.categoryId === selectedCat);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCat, items, favItems, recentItems]);

  // Sorting happens here (only when base or sortKey changes), so it never runs
  // per keystroke while searching and never blocks routine navigation.
  const sortedBase = useMemo(() => sortItems(base, sortKey), [base, sortKey]);

  const visible = useMemo(() => {
    const locked = selectedCat !== "all" && selectedCat !== "fav" && selectedCat !== "recent" && isCatLocked(selectedCat) && !unlockedCats.has(selectedCat);
    if (locked) return [];

    const q = itemQuery.trim().toLowerCase();
    // No search: just take the first page; locked items stay visible (with a
    // lock badge) and are only hidden while searching.
    if (!q) return sortedBase.slice(0, MAX_ITEMS);

    const out: BrowseItem[] = [];
    for (const it of sortedBase) {
      if (isItemLocked(it.id)) continue;
      if (itemLabel(it.id, it.name).toLowerCase().includes(q)) {
        out.push(it);
        if (out.length >= MAX_ITEMS) break;
      }
    }
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sortedBase, selectedCat, itemQuery, lockedChannels, channelRenames, unlockedCats, lockedCats]);

  // On first mount, restore focus to the previously opened item (or at least
  // its category) when coming back from a detail page.
  useEffect(() => {
    if (didRestore.current) return;
    const target = browseMemory[kind];
    if (!target) {
      didRestore.current = true;
      return;
    }
    // Wait until the expected item list is ready before focusing it.
    if (target.itemId != null && visible.length === 0) return;
    didRestore.current = true;
    const tid = window.setTimeout(() => {
      if (focusManager.hasActiveLayer()) return;
      if (target.itemId != null) {
        const idx = visible.findIndex((x) => x.id === target.itemId);
        if (idx >= 0 && focusManager.focus(`it-${idx}`)) return;
      }
      if (!focusManager.focus(`cat-name-${selectedCat}`)) {
        focusManager.focus("cat-name-all");
      }
    }, 30);
    return () => clearTimeout(tid);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  const goToItems = () => setItemsFocusReq((n) => n + 1);

  const enterCategory = (id: string, ckind: CatKind) => {
    if (selectTimer.current) clearTimeout(selectTimer.current);
    if (ckind === "cat" && isCatLocked(id) && !unlockedCats.has(id)) {
      setModal(
        <PinDialog
          title={t("parentalcontrol")}
          mode="verify"
          expectedPin={pin}
          onSuccess={() => {
            setUnlockedCats((s) => new Set(s).add(id));
            setSelectedCat(id);
            skipCatRefocus.current = true;
            goToItems();
          }}
          onClose={closeModal}
        />
      );
      return;
    }
    setSelectedCat(id);
    goToItems();
  };

  const rememberPlace = (it: BrowseItem) => {
    browseMemory[kind] = { cat: selectedCat, itemId: it.id };
  };

  const openItem = (it: BrowseItem) => {
    if (isItemLocked(it.id) && !unlockedItems.has(it.id)) {
      setModal(
        <PinDialog
          title={t("parentalcontrol")}
          mode="verify"
          expectedPin={pin}
          onSuccess={() => {
            setUnlockedItems((s) => new Set(s).add(it.id));
            rememberPlace(it);
            onOpen(it);
          }}
          onClose={closeModal}
        />
      );
      return;
    }
    rememberPlace(it);
    onOpen(it);
  };

  const lockFlow = (locked: boolean, apply: () => void) => {
    if (locked) {
      setModal(
        <PinDialog title={t("parentalcontrol")} mode="verify" expectedPin={pin} onSuccess={apply} onClose={closeModal} />
      );
    } else if (!pin) {
      setModal(
        <ConfirmDialog
          title={t("parentalcontrol")}
          message={t("createPinInSettings")}
          okLabel={t("settings")}
          cancelLabel={t("cancel")}
          onConfirm={() => {
            closeModal();
            navigate(Routes.settings);
          }}
          onClose={closeModal}
        />
      );
    } else {
      apply();
    }
  };

  const toggleCatLock = (cid: string) =>
    lockFlow(isCatLocked(cid), () => useUserData.getState().toggleCatLock(catKey(cid)));
  const toggleItemLock = (id: number) =>
    lockFlow(isItemLocked(id), () => useUserData.getState().toggleItemLock(itemKey(id)));

  const openCatGear = (id: string, name: string, ckind: CatKind) => {
    if (ckind === "fav" || ckind === "recent") {
      setModal(
        <ConfirmDialog
          title={ckind === "fav" ? "FAVOURITES" : "RECENTLY WATCHED"}
          message={t("clearConfirm") || "Clear all items?"}
          okLabel={t("okString")}
          cancelLabel={t("cancel")}
          danger
          onConfirm={() =>
            ckind === "fav"
              ? useFavorites.getState().clearKind(favKind)
              : useResume.getState().clearKind(kind as ResumeKind)
          }
          onClose={closeModal}
        />
      );
      return;
    }
    setModal(
      <OptionMenu
        title={name}
        options={[
          {
            label: isCatLocked(id) ? t("unlockItem") : t("lockItem"),
            icon: isCatLocked(id) ? "lock_open" : "lock",
            onSelect: () => toggleCatLock(id),
          },
          {
            label: t("rename") || "Rename",
            icon: "edit",
            onSelect: () =>
              setModal(
                <RenamePrompt
                  title={t("rename") || "Rename"}
                  initial={name}
                  okLabel={t("okString")}
                  cancelLabel={t("cancel")}
                  onSubmit={(v) => useUserData.getState().renameCat(catKey(id), v)}
                  onClose={closeModal}
                />
              ),
          },
        ]}
        onClose={closeModal}
      />
    );
  };

  const openItemMenu = (it: BrowseItem) => {
    const fav = isFav(it.id);
    const name = itemLabel(it.id, it.name);
    setModal(
      <OptionMenu
        title={name}
        options={[
          { label: t("play"), icon: "play_arrow", onSelect: () => openItem(it) },
          {
            label: fav ? t("remove") : t("addToFav"),
            icon: fav ? "favorite" : "favorite_border",
            onSelect: () =>
              useFavorites.getState().toggle({ kind: favKind, id: it.id, name: it.name, icon: it.image }),
          },
          {
            label: isItemLocked(it.id) ? t("unlockItem") : t("lockItem"),
            icon: isItemLocked(it.id) ? "lock_open" : "lock",
            onSelect: () => toggleItemLock(it.id),
          },
          {
            label: t("rename") || "Rename",
            icon: "edit",
            onSelect: () =>
              setModal(
                <RenamePrompt
                  title={t("rename") || "Rename"}
                  initial={name}
                  okLabel={t("okString")}
                  cancelLabel={t("cancel")}
                  onSubmit={(v) => useUserData.getState().renameItem(itemKey(it.id), v)}
                  onClose={closeModal}
                />
              ),
          },
        ]}
        onClose={closeModal}
      />
    );
  };

  const lockedActive =
    selectedCat !== "all" &&
    selectedCat !== "fav" &&
    selectedCat !== "recent" &&
    isCatLocked(selectedCat) &&
    !unlockedCats.has(selectedCat);

  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
      <TopBar
        title={title}
        onBack={onBack}
        leadingActions={[{ icon: "tune", fg: "#FFB74D", onTap: openSort, focusKey: "topbar-sort" }]}
      />

      <div style={{ flex: 1, display: "flex", minHeight: 0, padding: "8px 10px", gap: 8 }}>
        {/* CATEGORY COLUMN */}
        <Column flex={1} title={catTitle}>
          <SearchBox
            value={catQuery}
            onChange={setCatQuery}
            placeholder={t("searchHere")}
            focusKey="cat-search"
            onArrow={(d) => {
              if (d === "right") return focusManager.focus("item-search");
              if (d === "down") return focusManager.focus(`cat-name-${rail[0]?.id}`);
              return false;
            }}
          />
          <div className="scrollable" style={{ flex: 1, padding: "4px 8px" }}>
            {rail.map((c, i) => (
              <CatRow
                key={c.id}
                id={c.id}
                name={c.name}
                count={c.count}
                kind={c.kind}
                locked={c.kind === "cat" && isCatLocked(c.id)}
                selected={c.id === selectedCat}
                autoFocus={c.id === selectedCat ? true : i === 0 && selectedCat === "all"}
                onFocus={() => {}}
                onEnter={() => enterCategory(c.id, c.kind)}
                onGear={() => openCatGear(c.id, c.name, c.kind)}
                onItems={() => enterCategory(c.id, c.kind)}
                prevId={i > 0 ? rail[i - 1].id : undefined}
                nextId={i < rail.length - 1 ? rail[i + 1].id : undefined}
                onUp={
                  i === 0
                    ? () => focusManager.focus("cat-search")
                    : () => focusManager.focus(`cat-name-${rail[i - 1].id}`)
                }
                onDown={
                  i < rail.length - 1
                    ? () => focusManager.focus(`cat-name-${rail[i + 1].id}`)
                    : undefined
                }
              />
            ))}
          </div>
        </Column>

        {/* ITEM GRID COLUMN */}
        <div style={{ flex: 3, display: "flex", flexDirection: "column", minWidth: 0 }}>
          <SearchBox
            value={itemQuery}
            onChange={setItemQuery}
            placeholder={t("searchHere")}
            focusKey="item-search"
            onArrow={(d) => {
              if (d === "left") return focusManager.focus("cat-search");
              if (d === "down") return visible.length ? focusManager.focus("it-0") : false;
              return false;
            }}
          />
          <div className="scrollable" style={{ flex: 1, padding: "4px 10px 16px" }}>
            {lockedActive ? (
              <div style={{ padding: 40, textAlign: "center" }}>
                <Icon name="lock" size={48} color="#FF5252" />
              </div>
            ) : visible.length === 0 ? (
              <div style={{ padding: 30, color: "rgba(255,255,255,0.4)", fontSize: 14 }}>—</div>
            ) : (
              <div style={{ display: "grid", gridTemplateColumns: `repeat(${COLS}, minmax(0, 1fr))`, gap: 16, alignContent: "start" }}>
                {visible.map((it, i) => (
                  <GridCard
                    key={it.id}
                    fkey={`it-${i}`}
                    title={itemLabel(it.id, it.name)}
                    image={it.image}
                    rating={it.rating}
                    locked={isItemLocked(it.id)}
                    fav={isFav(it.id)}
                    progress={progressFor(it.id)}
                    autoFocus={i === 0}
                    onOpen={() => openItem(it)}
                    onMenu={() => openItemMenu(it)}
                    onArrowPoster={(d) => {
                      if (d === "left")
                        return i % COLS === 0
                          ? focusManager.focus(`cat-name-${selectedCat}`)
                          : focusManager.focus(`it-${i - 1}-m`);
                      if (d === "right") return focusManager.focus(`it-${i}-m`);
                      if (d === "up")
                        return i < COLS
                          ? focusManager.focus("item-search")
                          : focusManager.focus(`it-${i - COLS}`);
                      if (d === "down")
                        return i + COLS < visible.length
                          ? focusManager.focus(`it-${i + COLS}`)
                          : true;
                      return false;
                    }}
                    onArrowMenu={(d) => {
                      if (d === "left") return focusManager.focus(`it-${i}`);
                      if (d === "right")
                        return i + 1 < visible.length ? focusManager.focus(`it-${i + 1}`) : true;
                      if (d === "up")
                        return i < COLS
                          ? focusManager.focus("item-search")
                          : focusManager.focus(`it-${i - COLS}-m`);
                      if (d === "down")
                        return i + COLS < visible.length
                          ? focusManager.focus(`it-${i + COLS}-m`)
                          : true;
                      return false;
                    }}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {modal}
    </div>
  );
}
