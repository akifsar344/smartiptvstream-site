import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { useCatalog } from "../../store/catalog";
import { useResume } from "../../store/resume";
import { SeriesStream } from "../../data/models";
import { CatalogBrowser, BrowseItem, extractYear, parseTs } from "../shared/CatalogBrowser";

// Cache the mapped list keyed by the source array reference so re-entering the
// screen (component remounts) doesn't re-map 100k+ items every time.
let cache: { src: SeriesStream[]; items: BrowseItem[]; byId: Map<number, BrowseItem> } | null = null;
function mapSeries(streams: SeriesStream[]) {
  if (cache && cache.src === streams) return cache;
  const items = streams.map((s) => ({
    id: s.seriesId,
    name: s.name,
    image: s.cover,
    rating: s.rating,
    categoryId: s.categoryId,
    added: parseTs(s.lastModified) || parseTs(s.releaseDate),
    year: parseTs(s.releaseDate) ? new Date(parseTs(s.releaseDate) * 1000).getUTCFullYear() : extractYear(s.name),
  }));
  const byId = new Map(items.map((it) => [it.id, it]));
  cache = { src: streams, items, byId };
  return cache;
}

export function SeriesScreen() {
  const t = useT();
  const navigate = useNavigate();
  const categories = useCatalog((s) => s.seriesCategories);
  const streams = useCatalog((s) => s.seriesStreams);
  const resumeItems = useResume((s) => s.items);

  const { items, byId } = useMemo(() => mapSeries(streams), [streams]);

  const recentItems: BrowseItem[] = useMemo(() => {
    const seen = new Set<number>();
    const out: BrowseItem[] = [];
    for (const r of resumeItems
      .filter((r) => r.kind === "series")
      .sort((a, b) => b.updatedAt - a.updatedAt)) {
      const sid = r.seriesId ?? -1;
      if (seen.has(sid)) continue;
      const it = byId.get(sid);
      if (it) {
        seen.add(sid);
        out.push(it);
      }
    }
    return out;
  }, [resumeItems, byId]);

  return (
    <CatalogBrowser
      kind="series"
      title={t("series")}
      catTitle={t("seriesCate")}
      itemTitle={t("series")}
      categories={categories}
      items={items}
      recentItems={recentItems}
      onOpen={(it) => {
        const series = streams.find((s) => s.seriesId === it.id);
        if (series) navigate(Routes.seriesDetail, { state: { series } });
      }}
      onBack={() => navigate(Routes.home)}
    />
  );
}
