import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { useCatalog } from "../../store/catalog";
import { useSession } from "../../store/session";
import { useSettings } from "../../store/settings";
import { useUserData } from "../../store/userdata";
import { useResume } from "../../store/resume";
import { formatClock } from "../../utils/datetime";
import { TopBar } from "../../components/TopBar";
import { Icon } from "../../components/Icon";
import { FocusInput } from "../../components/FocusInput";
import {
  OptionMenu,
  RenamePrompt,
  PinDialog,
  ConfirmDialog,
} from "../../components/Overlay";
import { useFocusable } from "../../navigation/useFocusable";
import { focusManager, Direction } from "../../navigation/focusManager";
import { useBack } from "../../navigation/useBack";
import { colors } from "../../styles/theme";
import { LiveStream, ShortEpgItem } from "../../data/models";
import { createPlayer } from "../../platform/player/createPlayer";
import { IPlayerAdapter, PlayerState } from "../../platform/player/types";

const ALL = "ALL";
const FAV = "FAVOURITES";
const RECENT = "RECENTLY WATCHED";

// Remembers the last selected category so leaving and re-entering Live TV
// restores the user's place instead of snapping back to ALL.
let liveSelectedCat = ALL;

export function LiveTvScreen() {
  const t = useT();
  const navigate = useNavigate();
  const categories = useCatalog((s) => s.liveCategories);
  const streams = useCatalog((s) => s.liveStreams);
  const streamFormat = useSettings((s) => s.streamFormat);

  // Per-user data
  const liveFav = useUserData((s) => s.liveFav);
  const liveRecent = useUserData((s) => s.liveRecent);
  const lockedCats = useUserData((s) => s.lockedCats);
  const lockedChannels = useUserData((s) => s.lockedChannels);
  const catRenames = useUserData((s) => s.catRenames);
  const channelRenames = useUserData((s) => s.channelRenames);
  const pin = useUserData((s) => s.pin);

  const [selectedCat, setSelectedCat] = useState(() => liveSelectedCat);
  const [catQuery, setCatQuery] = useState("");
  const [chQuery, setChQuery] = useState("");
  const [focusedChannel, setFocusedChannel] = useState<LiveStream | null>(null);
  const [epg, setEpg] = useState<ShortEpgItem[]>([]);
  const [modal, setModal] = useState<React.ReactNode>(null);
  const [unlockedCats, setUnlockedCats] = useState<Set<string>>(new Set());
  const [unlockedChs, setUnlockedChs] = useState<Set<number>>(new Set());
  const [playingChannel, setPlayingChannel] = useState<LiveStream | null>(null);
  const [fullscreen, setFullscreen] = useState(false);
  const [playerState, setPlayerState] = useState<PlayerState>("idle");

  const closeModal = () => setModal(null);

  // Persist the selected category across screen remounts.
  useEffect(() => {
    liveSelectedCat = selectedCat;
  }, [selectedCat]);

  // Whenever a Live TV modal/menu finishes (state settles to null), pull focus
  // back to the category column (selected category, ALL by default) so it never
  // lands on the top-bar back button or a search box after an operation.
  useEffect(() => {
    if (modal !== null) return;
    const id = window.setTimeout(() => {
      if (focusManager.hasActiveLayer()) return; // another overlay took over
      if (!focusManager.focus(`cat-name-${selectedCat}`)) {
        focusManager.focus(`cat-name-${ALL}`);
      }
    }, 0);
    return () => clearTimeout(id);
    // selectedCat intentionally read fresh on each settle.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modal]);

  const selectTimer = useRef<number | null>(null);
  const focusFirstChannel = useRef(false);
  const playerContainerRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<IPlayerAdapter | null>(null);

  // Create the embedded mini player once.
  useEffect(() => {
    if (!playerContainerRef.current) return;
    const player = createPlayer();
    playerRef.current = player;
    player.attach(playerContainerRef.current, {
      onStateChange: setPlayerState,
      onError: () => setPlayerState("error"),
    });
    return () => {
      player.destroy();
      playerRef.current = null;
    };
  }, []);

  useBack(() => {
    if (fullscreen) {
      setFullscreen(false);
      return true;
    }
    navigate(Routes.home);
    return true;
  });

  // Debounced category preview while scrolling the category column, so the
  // channel list isn't re-rendered on every step (keeps navigation smooth).
  const previewCategory = (id: string) => {
    if (selectTimer.current) clearTimeout(selectTimer.current);
    selectTimer.current = window.setTimeout(() => setSelectedCat(id), 140);
  };
  useEffect(() => () => {
    if (selectTimer.current) clearTimeout(selectTimer.current);
  }, []);

  const catName = (id: string, fallback: string) => catRenames[id] ?? fallback;
  const chName = (id: number, fallback: string) =>
    channelRenames[String(id)] ?? fallback;
  const isCatLocked = (id: string) => lockedCats.includes(id);
  const isChLocked = (id: number) => lockedChannels.includes(String(id));

  // Single-pass per-category channel counts; avoids an O(categories × streams)
  // scan on every render (live catalogs can have tens of thousands of channels).
  const countByCat = useMemo(() => {
    const m = new Map<string, number>();
    for (const s of streams) m.set(s.categoryId, (m.get(s.categoryId) || 0) + 1);
    return m;
  }, [streams]);

  // ---- Build category rail ----
  const rail = useMemo(() => {
    const lockedSet = new Set(lockedCats);
    let allCount = 0;
    for (const s of streams) if (!lockedSet.has(s.categoryId)) allCount++;
    const list: {
      id: string;
      name: string;
      count: number;
      kind: "all" | "fav" | "recent" | "cat";
    }[] = [
      { id: ALL, name: ALL, count: allCount, kind: "all" },
      { id: FAV, name: FAV, count: liveFav.length, kind: "fav" },
      { id: RECENT, name: RECENT, count: liveRecent.length, kind: "recent" },
    ];
    for (const c of categories) {
      list.push({
        id: c.categoryId,
        name: catName(c.categoryId, c.categoryName),
        count: countByCat.get(c.categoryId) || 0,
        kind: "cat",
      });
    }
    const q = catQuery.trim().toLowerCase();
    if (!q) return list;
    return list.filter((c) => c.name.toLowerCase().includes(q));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categories, streams, liveFav, liveRecent, lockedCats, catRenames, catQuery, countByCat]);

  // ---- Build channel list for the selected category ----
  const channels = useMemo(() => {
    const lockedCatSet = new Set(lockedCats);
    let base: LiveStream[];
    if (selectedCat === ALL) {
      base = streams.filter((s) => !lockedCatSet.has(s.categoryId));
    } else if (selectedCat === FAV) {
      const favSet = new Set(liveFav);
      base = streams.filter((s) => favSet.has(s.streamId));
    } else if (selectedCat === RECENT) {
      const byId = new Map(streams.map((s) => [s.streamId, s]));
      base = liveRecent.map((id) => byId.get(id)).filter(Boolean) as LiveStream[];
    } else if (isCatLocked(selectedCat) && !unlockedCats.has(selectedCat)) {
      base = [];
    } else {
      base = streams.filter((s) => s.categoryId === selectedCat);
    }
    const q = chQuery.trim().toLowerCase();
    const filtered = q
      ? base.filter((s) => chName(s.streamId, s.name).toLowerCase().includes(q))
      : base;
    return filtered.slice(0, 600);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    selectedCat,
    streams,
    liveFav,
    liveRecent,
    lockedCats,
    chQuery,
    channelRenames,
    unlockedCats,
  ]);

  // EPG for the focused channel preview
  useEffect(() => {
    if (!focusedChannel) {
      setEpg([]);
      return;
    }
    let active = true;
    const client = useSession.getState().client;
    client
      ?.getShortEpg(focusedChannel.streamId, 50)
      .then((e) => active && setEpg(e))
      .catch(() => active && setEpg([]));
    return () => {
      active = false;
    };
  }, [focusedChannel]);

  // ---- Actions ----
  // Plays a channel in the embedded mini player (stays small by default).
  const doPlay = (ch: LiveStream, goFullscreen = false) => {
    const client = useSession.getState().client;
    // M3U channels carry a direct URL and have no Xtream client.
    const direct = ch.directSource;
    if (!client && !direct) return;
    useUserData.getState().pushRecent(ch.streamId);
    // Seed Continue Watching (Live TV tab) so the channel can be re-opened.
    useResume.getState().save({
      kind: "live",
      id: ch.streamId,
      name: chName(ch.streamId, ch.name),
      icon: ch.streamIcon || "",
      positionSec: 0,
      durationSec: 0,
      updatedAt: Date.now(),
      url: direct || undefined,
    });
    let url: string;
    let fallbackUrl: string | undefined;
    if (direct) {
      url = direct;
      fallbackUrl = undefined;
    } else {
      const ext = streamFormat === "ts" ? "ts" : "m3u8";
      url = ext === "ts" ? client!.liveTsUrl(ch.streamId) : client!.liveUrl(ch.streamId, "m3u8");
      // Provide the alternate container as a fallback for codecs (HEVC/AC3) that
      // hls.js/MSE can't decode; the raw .ts URL uses the TV's hardware decoder.
      fallbackUrl = ext === "ts" ? client!.liveUrl(ch.streamId, "m3u8") : client!.liveTsUrl(ch.streamId);
    }
    setPlayingChannel(ch);
    setPlayerState("loading");
    playerRef.current?.load({ url, fallbackUrl, kind: "live", title: chName(ch.streamId, ch.name) });
    if (goFullscreen) {
      setFullscreen(true);
      focusManager.focus("live-player");
    }
  };

  const playChannel = (ch: LiveStream, goFullscreen = false) => {
    if (isChLocked(ch.streamId) && !unlockedChs.has(ch.streamId)) {
      setModal(
        <PinDialog
          title={t("parentalcontrol")}
          mode="verify"
          expectedPin={pin}
          onSuccess={() => {
            setUnlockedChs((s) => new Set(s).add(ch.streamId));
            doPlay(ch, goFullscreen);
          }}
          onClose={closeModal}
        />
      );
      return;
    }
    doPlay(ch, goFullscreen);
  };

  // Channel row OK: first press opens the mini player; pressing OK again on the
  // currently playing channel goes fullscreen.
  const onChannelEnter = (ch: LiveStream) => {
    if (playingChannel?.streamId === ch.streamId) {
      setFullscreen(true);
      focusManager.focus("live-player");
    } else {
      playChannel(ch, false);
    }
  };

  // Switch to the previous/next channel in the current list (used in fullscreen).
  const stepChannel = (delta: number) => {
    if (!playingChannel) return;
    const idx = channels.findIndex((c) => c.streamId === playingChannel.streamId);
    if (idx < 0) return;
    const next = channels[idx + delta];
    if (next) playChannel(next, false);
  };

  const goToChannels = () => {
    if (channels.length) focusManager.focus(`ch-name-${channels[0].streamId}`);
    else focusManager.focus("ch-search");
  };

  const enterCategory = (id: string, kind: string) => {
    if (selectTimer.current) clearTimeout(selectTimer.current);
    if (kind === "cat" && isCatLocked(id) && !unlockedCats.has(id)) {
      setModal(
        <PinDialog
          title={t("parentalcontrol")}
          mode="verify"
          expectedPin={pin}
          onSuccess={() => {
            setUnlockedCats((s) => new Set(s).add(id));
            focusFirstChannel.current = true;
            setSelectedCat(id);
          }}
          onClose={closeModal}
        />
      );
      return;
    }
    if (id === selectedCat) {
      // List already shows this category – jump straight into the channels.
      goToChannels();
    } else {
      focusFirstChannel.current = true;
      setSelectedCat(id);
    }
  };

  // After the channel list updates for a newly entered category, move focus to
  // the first channel (not the search box).
  useEffect(() => {
    if (!focusFirstChannel.current) return;
    focusFirstChannel.current = false;
    goToChannels();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channels]);

  // Category parental lock toggle
  const toggleCatLock = (id: string) => {
    if (isCatLocked(id)) {
      setModal(
        <PinDialog
          title={t("parentalcontrol")}
          mode="verify"
          expectedPin={pin}
          onSuccess={() => useUserData.getState().toggleCatLock(id)}
          onClose={closeModal}
        />
      );
    } else if (!pin) {
      setModal(
        <ConfirmDialog
          title={t("parentalcontrol")}
          message={t("createPinInSettings")}
          okLabel={t("settings")}
          cancelLabel={t("cancel")}
          onConfirm={() => {
            closeModal();
            navigate(Routes.settings);
          }}
          onClose={closeModal}
        />
      );
    } else {
      useUserData.getState().toggleCatLock(id);
    }
  };

  const toggleChLock = (id: number) => {
    if (isChLocked(id)) {
      setModal(
        <PinDialog
          title={t("parentalcontrol")}
          mode="verify"
          expectedPin={pin}
          onSuccess={() => useUserData.getState().toggleChannelLock(id)}
          onClose={closeModal}
        />
      );
    } else if (!pin) {
      setModal(
        <ConfirmDialog
          title={t("parentalcontrol")}
          message={t("createPinInSettings")}
          okLabel={t("settings")}
          cancelLabel={t("cancel")}
          onConfirm={() => {
            closeModal();
            navigate(Routes.settings);
          }}
          onClose={closeModal}
        />
      );
    } else {
      useUserData.getState().toggleChannelLock(id);
    }
  };

  const openCatGear = (id: string, name: string, kind: string) => {
    if (kind === "fav" || kind === "recent") {
      setModal(
        <ConfirmDialog
          title={kind === "fav" ? FAV : RECENT}
          message={t("clearConfirm") || "Clear all items?"}
          okLabel={t("okString")}
          cancelLabel={t("cancel")}
          danger
          onConfirm={() =>
            kind === "fav"
              ? useUserData.getState().clearLiveFav()
              : useUserData.getState().clearRecent()
          }
          onClose={closeModal}
        />
      );
      return;
    }
    setModal(
      <OptionMenu
        title={`${name}`}
        options={[
          {
            label: isCatLocked(id) ? t("unlockItem") : t("lockItem"),
            icon: isCatLocked(id) ? "lock_open" : "lock",
            onSelect: () => toggleCatLock(id),
          },
          {
            label: t("rename") || "Rename",
            icon: "edit",
            onSelect: () =>
              setModal(
                <RenamePrompt
                  title={t("rename") || "Rename"}
                  initial={name}
                  okLabel={t("okString")}
                  cancelLabel={t("cancel")}
                  onSubmit={(v) => useUserData.getState().renameCat(id, v)}
                  onClose={closeModal}
                />
              ),
          },
        ]}
        onClose={closeModal}
      />
    );
  };

  const openChMenu = (ch: LiveStream) => {
    const fav = liveFav.includes(ch.streamId);
    setModal(
      <OptionMenu
        title={chName(ch.streamId, ch.name)}
        options={[
          { label: t("play"), icon: "play_arrow", onSelect: () => playChannel(ch) },
          {
            label: fav ? t("remove") : t("addToFav"),
            icon: fav ? "favorite" : "favorite_border",
            onSelect: () => useUserData.getState().toggleLiveFav(ch.streamId),
          },
          {
            label: isChLocked(ch.streamId) ? t("unlockItem") : t("lockItem"),
            icon: isChLocked(ch.streamId) ? "lock_open" : "lock",
            onSelect: () => toggleChLock(ch.streamId),
          },
          {
            label: t("rename") || "Rename",
            icon: "edit",
            onSelect: () =>
              setModal(
                <RenamePrompt
                  title={t("rename") || "Rename"}
                  initial={chName(ch.streamId, ch.name)}
                  okLabel={t("okString")}
                  cancelLabel={t("cancel")}
                  onSubmit={(v) => useUserData.getState().renameChannel(ch.streamId, v)}
                  onClose={closeModal}
                />
              ),
          },
        ]}
        onClose={closeModal}
      />
    );
  };

  const firstChannelKey = channels.length ? `ch-name-${channels[0].streamId}` : "ch-search";

  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
      <TopBar
        title={t("livetv")}
        onBack={() => navigate(Routes.home)}
        leadingActions={[
          { icon: "swap_vert", fg: "#B39DDB", onTap: () => {}, focusKey: "lt-sort" },
        ]}
      />

      <div style={{ flex: 1, display: "flex", minHeight: 0, padding: "8px 10px", gap: 8 }}>
        {/* CATEGORY COLUMN */}
        <Column flex={1} title={t("liveCategories")}>
          <SearchBox
            value={catQuery}
            onChange={setCatQuery}
            placeholder={t("searchHere")}
            focusKey="cat-search"
            onArrow={(d) => {
              if (d === "right") return focusManager.focus("ch-search");
              if (d === "down") return focusManager.focus(`cat-name-${rail[0]?.id}`);
              return false;
            }}
          />
          <div className="scrollable" style={{ flex: 1, padding: "4px 8px" }}>
            {rail.map((c, i) => (
              <CatRow
                key={c.id}
                id={c.id}
                name={c.name}
                count={c.count}
                kind={c.kind}
                locked={c.kind === "cat" && isCatLocked(c.id)}
                selected={c.id === selectedCat}
                autoFocus={i === 0}
                onFocus={() => previewCategory(c.id)}
                onEnter={() => enterCategory(c.id, c.kind)}
                onGear={() => openCatGear(c.id, c.name, c.kind)}
                onChannels={() => enterCategory(c.id, c.kind)}
                onUp={i === 0 ? () => focusManager.focus("cat-search") : undefined}
              />
            ))}
          </div>
        </Column>

        {/* CHANNEL COLUMN */}
        <Column flex={1} title={t("channels")}>
          <SearchBox
            value={chQuery}
            onChange={setChQuery}
            placeholder={t("searchHere")}
            focusKey="ch-search"
            onArrow={(d) => {
              if (d === "left") return focusManager.focus("cat-search");
              if (d === "down") return focusManager.focus(firstChannelKey);
              return false;
            }}
          />
          <div className="scrollable" style={{ flex: 1, padding: "4px 8px" }}>
            {channels.length === 0 ? (
              <div style={{ padding: 20, color: "rgba(255,255,255,0.4)", fontSize: 14 }}>
                {selectedCat !== ALL && isCatLocked(selectedCat) && !unlockedCats.has(selectedCat)
                  ? "🔒"
                  : "—"}
              </div>
            ) : (
              channels.map((ch, i) => (
                <ChanRow
                  key={ch.streamId}
                  channel={ch}
                  displayName={chName(ch.streamId, ch.name)}
                  locked={isChLocked(ch.streamId)}
                  fav={liveFav.includes(ch.streamId)}
                  onFocus={() => setFocusedChannel(ch)}
                  onEnter={() => onChannelEnter(ch)}
                  onMenu={() => openChMenu(ch)}
                  onLeft={() => focusManager.focus(`cat-name-${selectedCat}`)}
                  onUp={i === 0 ? () => focusManager.focus("ch-search") : undefined}
                />
              ))
            )}
          </div>
        </Column>

        {/* PREVIEW (mini player) + EPG */}
        <div style={{ flex: 2, display: "flex", flexDirection: "column", gap: 10, minWidth: 0 }}>
          <PlayerPanel
            containerRef={playerContainerRef}
            playing={!!playingChannel}
            previewChannel={focusedChannel}
            playingName={playingChannel ? chName(playingChannel.streamId, playingChannel.name) : ""}
            previewName={focusedChannel ? chName(focusedChannel.streamId, focusedChannel.name) : ""}
            state={playerState}
            fullscreen={fullscreen}
            onToggleFullscreen={() => setFullscreen((f) => !f)}
            onPlayPreview={() => focusedChannel && playChannel(focusedChannel)}
            onLeft={() =>
              focusedChannel && focusManager.focus(`ch-name-${focusedChannel.streamId}`)
            }
            onDown={() => focusManager.focus("epg-card")}
            onStep={stepChannel}
          />

          <EpgCard epg={epg} onLeft={() => focusedChannel && focusManager.focus(`ch-name-${focusedChannel.streamId}`)} />
        </div>
      </div>

      {modal}
    </div>
  );
}

function Column({
  flex,
  title,
  children,
}: {
  flex: number;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        flex,
        minWidth: 0,
        display: "flex",
        flexDirection: "column",
        background: "rgba(6,23,86,0.45)",
        borderRadius: 12,
        border: "1px solid rgba(255,255,255,0.08)",
        overflow: "hidden",
      }}
    >
      <div style={{ padding: "10px 14px 4px", fontSize: 12, fontWeight: 800, letterSpacing: 1, color: "rgba(255,255,255,0.55)" }}>
        {title}
      </div>
      {children}
    </div>
  );
}

function SearchBox({
  value,
  onChange,
  placeholder,
  focusKey,
  onArrow,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  focusKey: string;
  onArrow: (d: Direction) => boolean;
}) {
  return (
    <div style={{ padding: "4px 10px 6px" }}>
      <FocusInput
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        focusKey={focusKey}
      />
      <ArrowProxy focusKey={focusKey} onArrow={onArrow} />
    </div>
  );
}

// Registers arrow handling for an existing focusable id (search box) without
// rendering anything; keeps cross-column navigation declarative.
function ArrowProxy({
  focusKey,
  onArrow,
}: {
  focusKey: string;
  onArrow: (d: Direction) => boolean;
}) {
  useEffect(() => {
    focusManager.update(focusKey, { onArrow: (d) => onArrow(d) });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusKey, onArrow]);
  return null;
}

function CatRow({
  id,
  name,
  count,
  kind,
  locked,
  selected,
  autoFocus,
  onFocus,
  onEnter,
  onGear,
  onChannels,
  onUp,
}: {
  id: string;
  name: string;
  count: number;
  kind: "all" | "fav" | "recent" | "cat";
  locked: boolean;
  selected: boolean;
  autoFocus?: boolean;
  onFocus: () => void;
  onEnter: () => void;
  onGear: () => void;
  onChannels: () => void;
  onUp?: () => void;
}) {
  const hasGear = kind === "cat" || kind === "fav" || kind === "recent";
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: `cat-name-${id}`,
    autoFocus,
    onEnter,
    onFocus,
    onArrow: (d) => {
      if (d === "up" && onUp) return onUp(), true;
      if (d === "right") return hasGear ? focusManager.focus(`cat-gear-${id}`) : (onChannels(), true);
      return false;
    },
  });
  return (
    <div style={{ display: "flex", alignItems: "center", marginBottom: 4, gap: 4 }}>
      <div
        ref={ref}
        onClick={onEnter}
        className="focusable"
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "11px 12px",
          borderRadius: 10,
          cursor: "pointer",
          minWidth: 0,
          background: focused
            ? "#3D58BA"
            : selected
            ? "rgba(61,88,186,0.4)"
            : "transparent",
          border: focused ? "2px solid #fff" : "2px solid transparent",
        }}
      >
        {locked && <Icon name="lock" size={14} color="#FF5252" />}
        <span style={{ flex: 1, fontSize: 13, fontWeight: selected || focused ? 700 : 500, color: "#fff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {name}
        </span>
        <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>{count}</span>
      </div>
      {hasGear && <CatGear id={id} kind={kind} onGear={onGear} onChannels={onChannels} />}
    </div>
  );
}

function CatGear({
  id,
  kind,
  onGear,
  onChannels,
}: {
  id: string;
  kind: string;
  onGear: () => void;
  onChannels: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: `cat-gear-${id}`,
    onEnter: onGear,
    onArrow: (d) => {
      if (d === "left") return focusManager.focus(`cat-name-${id}`);
      if (d === "right") return onChannels(), true;
      return false;
    },
  });
  const icon = kind === "fav" || kind === "recent" ? "delete" : "settings";
  return (
    <div
      ref={ref}
      onClick={onGear}
      className="focusable"
      style={{
        width: 34,
        height: 34,
        borderRadius: 8,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flex: "0 0 auto",
        cursor: "pointer",
        background: focused ? "#fff" : "rgba(255,255,255,0.08)",
        border: focused ? "2px solid #fff" : "1px solid rgba(255,255,255,0.12)",
      }}
    >
      <Icon name={icon} size={18} color={focused ? colors.primary : "rgba(255,255,255,0.7)"} />
    </div>
  );
}

function ChanRow({
  channel,
  displayName,
  locked,
  fav,
  onFocus,
  onEnter,
  onMenu,
  onLeft,
  onUp,
}: {
  channel: LiveStream;
  displayName: string;
  locked: boolean;
  fav: boolean;
  onFocus: () => void;
  onEnter: () => void;
  onMenu: () => void;
  onLeft: () => void;
  onUp?: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: `ch-name-${channel.streamId}`,
    onEnter,
    onFocus,
    onArrow: (d) => {
      if (d === "up" && onUp) return onUp(), true;
      if (d === "left") return onLeft(), true;
      if (d === "right") return focusManager.focus(`ch-menu-${channel.streamId}`);
      return false;
    },
  });
  return (
    <div style={{ display: "flex", alignItems: "center", marginBottom: 4, gap: 4 }}>
      <div
        ref={ref}
        onClick={onEnter}
        className="focusable"
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          gap: 10,
          padding: "9px 10px",
          borderRadius: 10,
          cursor: "pointer",
          minWidth: 0,
          background: focused ? "#3D58BA" : "transparent",
          border: focused ? "2px solid #fff" : "2px solid transparent",
        }}
      >
        <span style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", minWidth: 30, textAlign: "right" }}>{channel.num}</span>
        <div style={{ width: 36, height: 36, borderRadius: 7, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", flex: "0 0 auto", overflow: "hidden" }}>
          {channel.streamIcon ? (
            <img src={channel.streamIcon} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "contain" }} onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />
          ) : (
            <Icon name="live_tv" size={18} color="rgba(255,255,255,0.4)" />
          )}
        </div>
        {locked && <Icon name="lock" size={13} color="#FF5252" />}
        {fav && <Icon name="favorite" size={13} color="#FF80AB" />}
        <span style={{ flex: 1, fontSize: 13, fontWeight: focused ? 700 : 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
          {displayName}
        </span>
      </div>
      <ChanMenuBtn id={channel.streamId} onMenu={onMenu} />
    </div>
  );
}

function ChanMenuBtn({ id, onMenu }: { id: number; onMenu: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: `ch-menu-${id}`,
    onEnter: onMenu,
    onArrow: (d) => {
      if (d === "left") return focusManager.focus(`ch-name-${id}`);
      if (d === "right") return focusManager.focus("live-player");
      return false;
    },
  });
  return (
    <div
      ref={ref}
      onClick={onMenu}
      className="focusable"
      style={{
        width: 32,
        height: 32,
        borderRadius: 8,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flex: "0 0 auto",
        cursor: "pointer",
        background: focused ? "#fff" : "rgba(255,255,255,0.08)",
        border: focused ? "2px solid #fff" : "1px solid rgba(255,255,255,0.12)",
      }}
    >
      <Icon name="more_vert" size={18} color={focused ? colors.primary : "rgba(255,255,255,0.7)"} />
    </div>
  );
}

function PlayerPanel({
  containerRef,
  playing,
  previewChannel,
  playingName,
  previewName,
  state,
  fullscreen,
  onToggleFullscreen,
  onPlayPreview,
  onLeft,
  onDown,
  onStep,
}: {
  containerRef: React.RefObject<HTMLDivElement>;
  playing: boolean;
  previewChannel: LiveStream | null;
  playingName: string;
  previewName: string;
  state: PlayerState;
  fullscreen: boolean;
  onToggleFullscreen: () => void;
  onPlayPreview: () => void;
  onLeft: () => void;
  onDown: () => void;
  onStep: (delta: number) => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: "live-player",
    onEnter: () => {
      if (!playing) onPlayPreview();
      else onToggleFullscreen();
    },
    onArrow: (d) => {
      if (fullscreen) {
        if (d === "up") return onStep(-1), true;
        if (d === "down") return onStep(1), true;
        return true; // consume left/right while fullscreen
      }
      if (d === "left") return onLeft(), true;
      if (d === "down") return onDown(), true;
      return false;
    },
  });

  const fsStyle: React.CSSProperties = {
    position: "fixed",
    left: 0,
    top: 0,
    width: 1280,
    height: 720,
    zIndex: 3000,
    background: "#000",
    borderRadius: 0,
    border: "none",
  };
  const miniStyle: React.CSSProperties = {
    flex: 2,
    minHeight: 0,
    position: "relative",
    borderRadius: 14,
    overflow: "hidden",
    background: "#000",
    border: focused ? "3px solid #fff" : "1px solid rgba(255,255,255,0.1)",
  };

  return (
    <div ref={ref} onClick={onToggleFullscreen} className="focusable" style={fullscreen ? fsStyle : miniStyle}>
      <div ref={containerRef} style={{ position: "absolute", inset: 0 }} />

      {!playing && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 12,
          }}
        >
          {previewChannel?.streamIcon ? (
            <img
              src={previewChannel.streamIcon}
              alt=""
              style={{ maxWidth: 200, maxHeight: 130, objectFit: "contain" }}
              onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
            />
          ) : (
            <Icon name="live_tv" size={72} color="rgba(255,255,255,0.3)" />
          )}
          <div style={{ fontSize: 22, fontWeight: 700, textAlign: "center", padding: "0 16px" }}>
            {previewName}
          </div>
        </div>
      )}

      {playing && (state === "loading" || state === "buffering") && (
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: "50%",
              border: "4px solid #00E5A8",
              borderRightColor: "transparent",
              borderTopColor: "transparent",
              animation: "spin 1s linear infinite",
            }}
          />
        </div>
      )}

      {playing && !fullscreen && (
        <div
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            bottom: 0,
            padding: "20px 14px 10px",
            background: "linear-gradient(transparent, rgba(0,0,0,0.75))",
            display: "flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          <span style={{ padding: "2px 8px", borderRadius: 5, background: "#E53935", fontSize: 11, fontWeight: 800 }}>LIVE</span>
          <span style={{ fontSize: 14, fontWeight: 700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{playingName}</span>
        </div>
      )}
    </div>
  );
}

function EpgCard({ epg, onLeft }: { epg: ShortEpgItem[]; onLeft: () => void }) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: "epg-card",
    onArrow: (d) => {
      if (d === "left") return onLeft(), true;
      if (d === "down") {
        scrollRef.current?.scrollBy({ top: 60 });
        return true;
      }
      if (d === "up") {
        scrollRef.current?.scrollBy({ top: -60 });
        return true;
      }
      return false;
    },
  });
  const t = useT();
  return (
    <div
      ref={ref}
      className="focusable"
      style={{
        flex: 1,
        minHeight: 0,
        borderRadius: 12,
        background: "rgba(255,255,255,0.06)",
        border: focused ? "2px solid #fff" : "2px solid rgba(255,255,255,0.08)",
        padding: 14,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div ref={scrollRef} className="scrollable" style={{ flex: 1 }}>
        {epg.length === 0 ? (
          <div style={{ color: "rgba(255,255,255,0.4)", fontSize: 14, textAlign: "center", paddingTop: 20 }}>
            {t("noEpgData")}
          </div>
        ) : (
          epg.map((p, i) => (
            <div key={i} style={{ display: "flex", gap: 12, padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
              <span style={{ fontSize: 12, color: i === 0 ? "#FFA726" : colors.btn, fontWeight: 700, minWidth: 104, flex: "0 0 auto" }}>
                {fmtEpgTime(p.start)} - {fmtEpgTime(p.end)}
              </span>
              <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 3 }}>
                <span style={{ fontSize: 13, fontWeight: 600, color: i === 0 ? "#FFA726" : "rgba(255,255,255,0.9)" }}>
                  {p.title}
                </span>
                {p.description && (
                  <span style={{ fontSize: 12, lineHeight: 1.4, color: "rgba(255,255,255,0.6)" }}>
                    {p.description}
                  </span>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function fmtEpgTime(s: string): string {
  const d = new Date(s.replace(" ", "T"));
  if (isNaN(d.getTime())) return s;
  return formatClock(d, useSettings.getState().hour24);
}
