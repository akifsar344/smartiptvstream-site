import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { ScreenHeader } from "../../components/ScreenHeader";
import { useSession } from "../../store/session";
import { useBack } from "../../navigation/useBack";
import { formatExpiry } from "../../utils/datetime";

export function AccountScreen() {
  const t = useT();
  const navigate = useNavigate();
  const userData = useSession((s) => s.userData);
  useBack(() => {
    navigate(Routes.home);
    return true;
  });
  const ui = userData?.userInfo;
  const rows: [string, string][] = [
    [t("userName"), ui?.username || "-"],
    [t("isTrail"), ui?.isTrial === "1" ? t("yes") : t("no")],
    ["Status", ui?.status || "-"],
    [t("expiaryDate"), ui?.expDate ? formatExpiry(ui.expDate) : "Unlimited"],
    [t("activeConnections"), ui?.activeCons || "0"],
    [t("maxConnections"), ui?.maxConnections || "-"],
    [t("createdAt"), ui?.createdAt || "-"],
  ];
  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
      <ScreenHeader title={t("accountInfo")} onBack={() => navigate(Routes.home)} />
      <div style={{ flex: 1, display: "flex", justifyContent: "center", paddingTop: 40 }}>
        <div style={{ width: 560 }}>
          {rows.map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "16px 0", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
              <span style={{ color: "rgba(255,255,255,0.6)", fontSize: 15 }}>{k}</span>
              <span style={{ fontWeight: 700, fontSize: 15 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
