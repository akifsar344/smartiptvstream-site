import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { colors, gradient } from "../../styles/theme";
import { Routes } from "../../routes";
import { FocusInput } from "../../components/FocusInput";
import { Button } from "../../components/Button";
import { useFocusable } from "../../navigation/useFocusable";
import { useSession, LoginType } from "../../store/session";
import { useAuth } from "../../store/auth";
import { useCatalog } from "../../store/catalog";
import { parseXtreamInput, xtreamBaseUrlFrom } from "../../data/xtream/urls";
import { XtreamClient } from "../../data/xtream/client";
import { useBack } from "../../navigation/useBack";
import { asset } from "../../platform/asset";

const TABS: { id: LoginType; key: string }[] = [
  { id: "xtream", key: "login" },
  { id: "m3u", key: "m3uPlaylist" },
];

// Swap http <-> https so we can retry auth on the other scheme.
function swapScheme(base: string): string {
  if (base.startsWith("https://")) return "http://" + base.slice("https://".length);
  if (base.startsWith("http://")) return "https://" + base.slice("http://".length);
  return base;
}

export function LoginScreen() {
  const t = useT();
  const navigate = useNavigate();
  const [tab, setTab] = useState<LoginType>("xtream");
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const profiles = useSession((s) => s.profiles);
  const accountEmail = useAuth((s) => s.email);
  useBack(() => {
    if (profiles.length) navigate(Routes.userList, { state: { from: "login" } });
    return true;
  });

  const signOut = () => {
    if (typeof window !== "undefined" && !window.confirm(t("logout"))) return;
    useAuth.getState().logout();
  };

  const submit = async () => {
    setError("");
    if (!name.trim()) return setError(t("enterplaylistNameError"));
    if (tab === "xtream") {
      const parsed = parseXtreamInput(url);
      const base = parsed.baseUrl || xtreamBaseUrlFrom(url);
      const u = username.trim() || parsed.username;
      const p = password.trim() || parsed.password;
      if (!base) return setError(t("enterValidUrlError"));
      if (!u) return setError(t("insertUsernameError"));
      if (!p) return setError(t("insertPasswordError"));
      setBusy(true);
      try {
        // Try the given scheme; if it fails, automatically try the other one
        // (http <-> https) since many panels only answer on one of them.
        let workingBase = base;
        let user = await new XtreamClient({ baseUrl: base, username: u, password: p })
          .authenticate()
          .catch(() => null);
        if (!user) {
          const alt = swapScheme(base);
          if (alt !== base) {
            user = await new XtreamClient({ baseUrl: alt, username: u, password: p })
              .authenticate()
              .catch(() => null);
            if (user) workingBase = alt;
          }
        }
        if (!user) {
          setBusy(false);
          return setError(t("loginFailed"));
        }
        const profile = useSession.getState().addProfile({
          playlistName: name.trim(),
          type: "xtream",
          baseUrl: workingBase,
          username: u,
          password: p,
        });
        useSession.getState().setActive(profile.id);
        useSession.getState().setUserData(user);
        // Catalog fetch is best-effort; never block reaching the dashboard.
        // First login for this user has no cache, so this fetches and persists
        // it to disk; later logins load instantly from that cache.
        try {
          await useCatalog.getState().loadForScope();
        } catch {
          /* soft-fail: open the app anyway */
        }
        navigate(Routes.home, { replace: true });
      } catch {
        setBusy(false);
        setError(t("loginFailed"));
      }
    } else {
      // M3U playlist: validate the URL is reachable + parseable, then build the
      // catalog (Live / Movies / Series) from it just like Xtream.
      if (!url.trim()) return setError(t("enterUrlerror"));
      setBusy(true);
      try {
        const res = await fetch(url.trim());
        const text = await res.text();
        if (!/#EXTM3U|#EXTINF/i.test(text)) {
          setBusy(false);
          return setError(t("enterValidUrlError"));
        }
        const profile = useSession.getState().addProfile({
          playlistName: name.trim(),
          type: "m3u",
          m3uUrl: url.trim(),
        });
        useSession.getState().setActive(profile.id);
        try {
          await useCatalog.getState().loadForScope();
        } catch {
          /* soft-fail: open the app anyway */
        }
        navigate(Routes.home, { replace: true });
      } catch {
        setBusy(false);
        setError(t("enterValidUrlError"));
      }
    }
  };

  return (
    <div className="authbg" style={{ position: "relative" }}>
      {/* Account bar: switch account by signing out (returns to the auth screen). */}
      {accountEmail && (
        <div style={{ position: "absolute", top: 16, right: 20, display: "flex", alignItems: "center", gap: 10, zIndex: 20 }}>
          <span style={{ fontSize: 13, color: "rgba(255,255,255,0.55)", maxWidth: 220, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {accountEmail}
          </span>
          <AccountSignOut label={t("accountSignOut")} onTap={signOut} />
        </div>
      )}

      <img src={asset("assets/Logo_inn.png")} alt="logo" style={{ width: 90, height: 90, objectFit: "contain" }} />
      <h1 style={{ marginTop: 10, fontSize: 26, fontWeight: 800, letterSpacing: 0.5 }}>Smart IPTV Stream</h1>

      <div style={{ display: "flex", gap: 12, marginTop: 24 }}>
        {TABS.map((tb) => (
          <TabButton
            key={tb.id}
            active={tab === tb.id}
            label={tb.id === "xtream" ? "Xtream API Connect" : t(tb.key)}
            onTap={() => setTab(tb.id)}
          />
        ))}
      </div>

      <div
        style={{
          marginTop: 24,
          width: "min(620px, 100%)",
          boxSizing: "border-box",
          padding: 24,
          borderRadius: 18,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.12)",
          display: "flex",
          flexDirection: "column",
          gap: 16,
        }}
      >
        <Field label={t("playlistName")}>
          <FocusInput value={name} onChange={setName} placeholder={t("playlistName")} focusKey="login-name" fieldNav />
        </Field>
        <Field label={tab === "xtream" ? "URL" : "M3U URL"}>
          <FocusInput
            value={url}
            onChange={setUrl}
            placeholder={tab === "m3u" ? "http://...m3u" : "http://..."}
            focusKey="login-url"
            fieldNav
            scrollOnFocus
            onSubmit={tab === "m3u" ? submit : undefined}
          />
        </Field>
        {tab === "xtream" && (
          <>
            <Field label={t("userName")}>
              <FocusInput value={username} onChange={setUsername} placeholder={t("insertUsername")} focusKey="login-user" fieldNav scrollOnFocus />
            </Field>
            <Field label={t("password")}>
              <FocusInput
                value={password}
                onChange={setPassword}
                placeholder={t("insertPassword")}
                type="password"
                focusKey="login-pass"
                fieldNav
                scrollOnFocus
                onSubmit={submit}
              />
            </Field>
          </>
        )}

        {error && <div style={{ color: "#FF7043", fontSize: 14, fontWeight: 600 }}>{error}</div>}

        <div style={{ display: "flex", gap: 12, marginTop: 6, flexWrap: "wrap" }}>
          <Button label={busy ? t("checkingUpdates") : t("login")} onTap={submit} focusKey="login-submit" width={200} />
          {profiles.length > 0 && (
            <Button label={t("usersList")} variant="ghost" onTap={() => navigate(Routes.userList, { state: { from: "login" } })} width={180} />
          )}
        </div>
      </div>
    </div>
  );
}

function AccountSignOut({ label, onTap }: { label: string; onTap: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 6,
        padding: "8px 16px",
        borderRadius: 999,
        fontSize: 13,
        fontWeight: 700,
        cursor: "pointer",
        color: focused ? colors.primary : "#fff",
        background: focused ? "#fff" : "rgba(255,255,255,0.08)",
        border: "1.5px solid rgba(255,255,255,0.18)",
      }}
    >
      {label}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", fontWeight: 600 }}>{label}</span>
      {children}
    </div>
  );
}

function TabButton({ active, label, onTap }: { active: boolean; label: string; onTap: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        padding: "12px 22px",
        borderRadius: 10,
        fontSize: 14,
        fontWeight: 700,
        cursor: "pointer",
        color: "#fff",
        background: focused ? "#fff" : active ? gradient(colors.tiles.live) : "rgba(255,255,255,0.06)",
        ...(focused ? { color: colors.primary } : {}),
        border: active ? "2px solid rgba(255,255,255,0.5)" : "1.5px solid rgba(255,255,255,0.15)",
      }}
    >
      {label}
    </div>
  );
}
