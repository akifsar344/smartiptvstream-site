import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { ScreenHeader } from "../../components/ScreenHeader";
import { Icon } from "../../components/Icon";
import { useFocusable } from "../../navigation/useFocusable";
import { focusManager } from "../../navigation/focusManager";
import { useBack } from "../../navigation/useBack";
import { useCatalog } from "../../store/catalog";
import { useSession } from "../../store/session";
import { LiveStream, ShortEpgItem } from "../../data/models";
import { colors } from "../../styles/theme";
import { fmtEpgTime } from "../installepg/InstallEpgScreen";

const ALL = "ALL";

export function CatchUpScreen() {
  const t = useT();
  const navigate = useNavigate();
  const categories = useCatalog((s) => s.liveCategories);
  const streams = useCatalog((s) => s.liveStreams);

  const [selectedCat, setSelectedCat] = useState(ALL);
  const [channel, setChannel] = useState<LiveStream | null>(null);
  const [programs, setPrograms] = useState<ShortEpgItem[]>([]);
  const [loading, setLoading] = useState(false);

  useBack(() => {
    navigate(Routes.home);
    return true;
  });

  const cats = useMemo(() => {
    const list: { id: string; name: string }[] = [{ id: ALL, name: ALL }];
    for (const c of categories) list.push({ id: c.categoryId, name: c.categoryName });
    return list;
  }, [categories]);

  const channels = useMemo(() => {
    const base = selectedCat === ALL ? streams : streams.filter((s) => s.categoryId === selectedCat);
    return base.slice(0, 600);
  }, [selectedCat, streams]);

  // Catch-up EPG window mirrors the source: now-7d … now+1d, keep has_archive.
  const loadPrograms = async (ch: LiveStream) => {
    setChannel(ch);
    setLoading(true);
    setPrograms([]);
    const client = useSession.getState().client;
    try {
      const nowSec = Math.floor(Date.now() / 1000);
      const list =
        (await client?.getSimpleDataTable(ch.streamId, {
          start: nowSec - 7 * 86400,
          end: nowSec + 86400,
          limit: 10000,
        })) ?? [];
      setPrograms(list.filter((p) => p.hasArchive === 1));
    } catch {
      setPrograms([]);
    } finally {
      setLoading(false);
    }
  };

  const playProgram = (p: ShortEpgItem) => {
    const client = useSession.getState().client;
    if (!client || !channel) return;
    const startTs = parseInt(p.startTimestamp, 10);
    const stopTs = parseInt(p.stopTimestamp, 10);
    if (!startTs || !stopTs) return;
    const durMin = Math.floor((stopTs - startTs) / 60);
    if (durMin <= 0) return;
    const startFmt = catchupStartFmt(p.start);
    if (!startFmt) return;
    // Prefer the HLS (m3u8) timeshift variant so hls.js handles buffering and
    // stall recovery; fall back to the raw .ts on the TV's hardware decoder if
    // the panel doesn't serve m3u8 timeshift.
    const url = client.timeshiftUrl(channel.streamId, durMin, startFmt, "m3u8");
    const fallbackUrl = client.timeshiftUrl(channel.streamId, durMin, startFmt, "ts");
    navigate(Routes.player, {
      state: { url, fallbackUrl, title: p.title || channel.name, kind: "vod", format: "hls" },
    });
  };

  const firstChannelKey = channels.length ? `cu-ch-${channels[0].streamId}` : "";

  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
      <ScreenHeader title={t("catchUp")} onBack={() => navigate(Routes.home)} />

      <div className="scrollable" style={{ display: "flex", gap: 8, padding: "6px 12px", overflowX: "auto", flex: "0 0 auto" }}>
        {cats.map((c, i) => (
          <CatChip
            key={c.id}
            label={c.name}
            selected={c.id === selectedCat}
            autoFocus={i === 0}
            onFocus={() => setSelectedCat(c.id)}
            onEnter={() => firstChannelKey && focusManager.focus(firstChannelKey)}
          />
        ))}
      </div>

      <div style={{ flex: 1, display: "flex", minHeight: 0, padding: "4px 12px 12px", gap: 10 }}>
        {/* Channel list */}
        <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", background: "rgba(6,23,86,0.45)", borderRadius: 12, border: "1px solid rgba(255,255,255,0.08)", overflow: "hidden" }}>
          <div style={{ padding: "10px 14px 4px", fontSize: 12, fontWeight: 800, letterSpacing: 1, color: "rgba(255,255,255,0.55)" }}>
            {t("channels")}
          </div>
          <div className="scrollable" style={{ flex: 1, padding: "4px 8px" }}>
            {channels.map((ch) => (
              <CuChannelRow
                key={ch.streamId}
                channel={ch}
                selected={channel?.streamId === ch.streamId}
                onEnter={() => loadPrograms(ch)}
                onRight={() => focusManager.focus("cu-panel")}
              />
            ))}
          </div>
        </div>

        {/* Program list */}
        <ProgramPanel
          channel={channel}
          programs={programs}
          loading={loading}
          onPlay={playProgram}
          onLeft={() => channel && focusManager.focus(`cu-ch-${channel.streamId}`)}
        />
      </div>
    </div>
  );
}

function CatChip({
  label,
  selected,
  autoFocus,
  onFocus,
  onEnter,
}: {
  label: string;
  selected: boolean;
  autoFocus?: boolean;
  onFocus: () => void;
  onEnter: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ autoFocus, onFocus, onEnter });
  return (
    <div
      ref={ref}
      onClick={onEnter}
      className="focusable"
      style={{
        flex: "0 0 auto",
        padding: "8px 16px",
        borderRadius: 10,
        cursor: "pointer",
        fontSize: 13,
        fontWeight: selected || focused ? 700 : 500,
        whiteSpace: "nowrap",
        background: focused ? "#FF8F00" : selected ? "rgba(255,143,0,0.35)" : "rgba(255,255,255,0.06)",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      {label}
    </div>
  );
}

function CuChannelRow({
  channel,
  selected,
  onEnter,
  onRight,
}: {
  channel: LiveStream;
  selected: boolean;
  onEnter: () => void;
  onRight: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: `cu-ch-${channel.streamId}`,
    onEnter,
    onArrow: (d) => (d === "right" ? (onRight(), true) : false),
  });
  return (
    <div
      ref={ref}
      onClick={onEnter}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "9px 10px",
        marginBottom: 4,
        borderRadius: 10,
        cursor: "pointer",
        minWidth: 0,
        background: focused ? "#FF8F00" : selected ? "rgba(255,143,0,0.3)" : "transparent",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      <div style={{ width: 34, height: 34, borderRadius: 7, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", flex: "0 0 auto", overflow: "hidden" }}>
        {channel.streamIcon ? (
          <img src={channel.streamIcon} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "contain" }} onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />
        ) : (
          <Icon name="schedule" size={16} color="rgba(255,255,255,0.4)" />
        )}
      </div>
      <span style={{ flex: 1, fontSize: 13, fontWeight: focused ? 700 : 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {channel.name}
      </span>
    </div>
  );
}

function ProgramPanel({
  channel,
  programs,
  loading,
  onPlay,
  onLeft,
}: {
  channel: LiveStream | null;
  programs: ShortEpgItem[];
  loading: boolean;
  onPlay: (p: ShortEpgItem) => void;
  onLeft: () => void;
}) {
  const t = useT();
  return (
    <div style={{ flex: 3, minWidth: 0, borderRadius: 12, background: "rgba(255,255,255,0.06)", border: "2px solid rgba(255,255,255,0.08)", padding: 14, display: "flex", flexDirection: "column", minHeight: 0 }}>
      {channel && <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 10, color: "#fff" }}>{channel.name}</div>}
      <div className="scrollable" style={{ flex: 1, minHeight: 0 }}>
        {loading ? (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", paddingTop: 40 }}>
            <Spinner />
          </div>
        ) : !channel ? (
          <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 15, textAlign: "center", paddingTop: 40 }}>
            {t("selectChannelForCatchup")}
          </div>
        ) : programs.length === 0 ? (
          <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 15, textAlign: "center", paddingTop: 40 }}>
            {t("noCatchUpData")}
          </div>
        ) : (
          programs.map((p, i) => (
            <ProgramRow key={i} program={p} first={i === 0} onPlay={() => onPlay(p)} onLeft={onLeft} />
          ))
        )}
      </div>
    </div>
  );
}

function ProgramRow({
  program,
  first,
  onPlay,
  onLeft,
}: {
  program: ShortEpgItem;
  first: boolean;
  onPlay: () => void;
  onLeft: () => void;
}) {
  const t = useT();
  const stopTs = parseInt(program.stopTimestamp, 10) * 1000;
  const playable = !!stopTs && stopTs < Date.now() && program.hasArchive === 1;

  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: first ? "cu-panel" : undefined,
    onEnter: () => playable && onPlay(),
    onArrow: (d) => (d === "left" ? (onLeft(), true) : false),
  });

  return (
    <div
      ref={ref}
      onClick={() => playable && onPlay()}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "10px 12px",
        marginBottom: 4,
        borderRadius: 10,
        cursor: playable ? "pointer" : "default",
        background: focused ? "rgba(255,143,0,0.3)" : first ? "rgba(255,143,0,0.15)" : "transparent",
        border: focused ? "2px solid #fff" : "2px solid transparent",
        opacity: playable ? 1 : 0.55,
      }}
    >
      {playable && <Icon name="play_arrow" size={18} color="#FFB74D" />}
      <span style={{ fontSize: 12, fontWeight: 700, color: colors.btn, minWidth: 116 }}>
        {fmtEpgTime(program.start)} - {fmtEpgTime(program.end)}
      </span>
      <span style={{ flex: 1, fontSize: 14, fontWeight: 600, color: "#fff", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {program.title}
      </span>
      {!playable && (
        <span style={{ fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 6, background: "rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.7)" }}>
          {stopTs && stopTs >= Date.now() ? t("upcoming") : t("noArchive")}
        </span>
      )}
    </div>
  );
}

function Spinner() {
  return (
    <div
      style={{
        width: 48,
        height: 48,
        borderRadius: "50%",
        border: "4px solid #FFB74D",
        borderRightColor: "transparent",
        borderTopColor: "transparent",
        animation: "spin 1s linear infinite",
      }}
    />
  );
}

// start string ("yyyy-MM-dd HH:mm:ss") parsed as UTC → "yyyy-MM-dd:HH-mm",
// matching the Android TV source's catch-up URL date formatting.
function catchupStartFmt(startStr: string): string {
  if (!startStr) return "";
  const d = new Date(startStr.replace(" ", "T") + "Z");
  if (isNaN(d.getTime())) return "";
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}-${p(d.getUTCMonth() + 1)}-${p(d.getUTCDate())}:${p(d.getUTCHours())}-${p(d.getUTCMinutes())}`;
}
