import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { ScreenHeader } from "../../components/ScreenHeader";
import { Button } from "../../components/Button";
import { useBack } from "../../navigation/useBack";
import { colors } from "../../styles/theme";

const TEST_FILE = "https://speed.cloudflare.com/__down?bytes=10000000"; // 10MB

export function SpeedTestScreen() {
  const t = useT();
  const navigate = useNavigate();
  const [speed, setSpeed] = useState<number | null>(null);
  const [testing, setTesting] = useState(false);

  useBack(() => {
    navigate(Routes.home);
    return true;
  });

  const run = async () => {
    setTesting(true);
    setSpeed(null);
    try {
      const start = performance.now();
      const res = await fetch(`${TEST_FILE}&t=${Date.now()}`, { cache: "no-store" });
      const blob = await res.blob();
      const seconds = (performance.now() - start) / 1000;
      const mbps = (blob.size * 8) / seconds / 1_000_000;
      setSpeed(mbps);
    } catch {
      setSpeed(0);
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
      <ScreenHeader title={t("speedTest")} onBack={() => navigate(Routes.home)} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 30 }}>
        <div style={{ fontSize: 64, fontWeight: 800, color: colors.accentRing }}>
          {testing ? "..." : speed != null ? `${speed.toFixed(1)}` : "--"}
          <span style={{ fontSize: 22, marginLeft: 8, color: "rgba(255,255,255,0.6)" }}>Mbps</span>
        </div>
        <Button label={testing ? t("testing") : t("restartTest")} onTap={run} autoFocus width={220} />
      </div>
    </div>
  );
}
