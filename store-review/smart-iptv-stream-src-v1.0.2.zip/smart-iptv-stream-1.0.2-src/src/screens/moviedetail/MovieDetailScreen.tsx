import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { useSession } from "../../store/session";
import { useResume } from "../../store/resume";
import { useFavorites } from "../../store/favorites";
import { MovieStream, asStr } from "../../data/models";
import { normalizeVodInfo } from "../../data/xtream/info";
import { Button } from "../../components/Button";
import { BackButton } from "../../components/ScreenHeader";
import { Icon } from "../../components/Icon";
import { useBack } from "../../navigation/useBack";
import { colors } from "../../styles/theme";
import { formatDuration } from "../../utils/datetime";
import { diskCache } from "../../platform/diskCache";
import { userScope } from "../../store/userdata";

// In-memory cache of vod_info responses for instant re-open within a session.
const memCache = new Map<string, any>();
const infoKey = (streamId: number) => `vod_info:${userScope()}:${streamId}`;

export function MovieDetailScreen() {
  const t = useT();
  const navigate = useNavigate();
  const location = useLocation();
  const movie = (location.state as any)?.movie as MovieStream | undefined;
  const [info, setInfo] = useState<any>(null);
  const resume = useResume((s) => (movie ? s.get("movie", movie.streamId) : undefined));
  const favHas = useFavorites((s) => (movie ? s.has("movie", movie.streamId) : false));
  const toggleFav = useFavorites((s) => s.toggle);

  useBack(() => {
    navigate(Routes.movies);
    return true;
  });

  useEffect(() => {
    if (!movie) {
      navigate(Routes.movies);
      return;
    }
    let cancelled = false;
    const key = infoKey(movie.streamId);

    // 1) Instant: in-memory cache.
    if (memCache.has(key)) setInfo((prev: any) => prev ?? memCache.get(key));
    // 2) Fast: disk cache (shown until the network refresh lands).
    else
      void diskCache.get(key).then((d) => {
        if (d && !cancelled) setInfo((prev: any) => prev ?? d);
      });

    // 3) Always refresh from the network in the background and overwrite.
    const client = useSession.getState().client;
    client?.getVodInfo(movie.streamId).then((d) => {
      if (!d || cancelled) return;
      memCache.set(key, d);
      void diskCache.set(key, d);
      setInfo(d);
    }).catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [movie, navigate]);

  const norm = useMemo(() => normalizeVodInfo(info), [info]);

  if (!movie) return null;

  const ext = asStr(norm.ext || movie.containerExtension || "mp4");
  const cover = asStr(norm.cover || movie.streamIcon);
  const plot = norm.plot;
  const genre = norm.genre;
  const cast = norm.cast;
  const releaseDate = norm.releaseDate;
  const durationSecs = norm.durationSecs;

  const playFrom = (pos: number) => {
    const client = useSession.getState().client;
    // M3U movies carry a direct URL; Xtream builds it from the client.
    const url = movie.directSource || (client ? client.movieUrl(movie.streamId, ext) : "");
    if (!url) return;
    navigate(Routes.player, {
      state: {
        url,
        title: movie.name,
        kind: "vod",
        osTitle: movie.name,
        startPositionSec: pos,
        resumeMeta: {
          kind: "movie",
          id: movie.streamId,
          name: movie.name,
          icon: cover,
          containerExtension: ext,
          url: movie.directSource || undefined,
        },
      },
    });
  };

  return (
    <div
      className="fullbg"
      style={{ position: "relative", display: "flex", flexDirection: "column" }}
    >
      {cover && (
        <img
          src={cover}
          alt=""
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            objectFit: "cover",
            opacity: 0.25,
            filter: "blur(2px)",
          }}
        />
      )}
      <div style={{ position: "absolute", inset: 0, background: "linear-gradient(90deg, rgba(22,33,62,0.95) 40%, rgba(22,33,62,0.5))" }} />

      <div style={{ position: "relative", padding: "20px 24px" }}>
        <BackButton onTap={() => navigate(Routes.movies)} />
      </div>

      <div style={{ position: "relative", flex: 1, display: "flex", gap: 36, padding: "10px 60px 40px" }}>
        <img
          src={cover}
          alt={movie.name}
          style={{ width: 280, height: 420, objectFit: "cover", borderRadius: 16, boxShadow: "0 12px 40px rgba(0,0,0,0.6)" }}
          onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")}
        />
        <div style={{ flex: 1, maxWidth: 720, display: "flex", flexDirection: "column" }}>
          <h1 style={{ fontSize: 38, fontWeight: 800, marginBottom: 14 }}>{movie.name}</h1>
          <div style={{ display: "flex", gap: 18, marginBottom: 18, color: "rgba(255,255,255,0.8)", fontSize: 14, flexWrap: "wrap" }}>
            {Number(movie.rating) > 0 && (
              <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
                <Icon name="star" size={16} color="#FFB300" /> {Number(movie.rating).toFixed(1)}
              </span>
            )}
            {releaseDate && <span>{releaseDate}</span>}
            {durationSecs > 0 && <span>{formatDuration(durationSecs)}</span>}
            {genre && <span>{genre}</span>}
          </div>
          {plot && (
            <p style={{ fontSize: 15, lineHeight: 1.6, color: "rgba(255,255,255,0.85)", marginBottom: 16, maxHeight: 150, overflow: "hidden" }}>
              {plot}
            </p>
          )}
          {resume && resume.positionSec > 10 && resume.durationSec > 0 && (
            <div style={{ marginBottom: 18, maxWidth: 460 }}>
              <div style={{ height: 6, borderRadius: 3, background: "rgba(255,255,255,0.18)", overflow: "hidden" }}>
                <div style={{ width: `${Math.min(100, (resume.positionSec / resume.durationSec) * 100)}%`, height: "100%", background: "#E53935" }} />
              </div>
              <div style={{ marginTop: 6, fontSize: 12, color: "rgba(255,255,255,0.7)" }}>
                {formatDuration(resume.positionSec)} / {formatDuration(resume.durationSec)}
              </div>
            </div>
          )}
          {cast && (
            <p style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", marginBottom: 24 }}>
              <b>{t("cast")}:</b> {cast}
            </p>
          )}
          <div style={{ display: "flex", gap: 14, marginTop: "auto" }}>
            {resume && resume.positionSec > 10 && (
              <Button
                label={`${t("resumeButton")} (${formatDuration(resume.positionSec)})`}
                onTap={() => playFrom(resume.positionSec)}
                autoFocus
                width={240}
                icon={<Icon name="play_arrow" size={20} color="currentColor" />}
              />
            )}
            <Button
              label={t("play")}
              onTap={() => playFrom(0)}
              autoFocus={!resume}
              width={160}
              variant={resume ? "ghost" : "primary"}
              icon={<Icon name="play_arrow" size={20} color="currentColor" />}
            />
            <Button
              label={favHas ? t("remove") : t("addToFav")}
              variant="ghost"
              onTap={() =>
                toggleFav({ kind: "movie", id: movie.streamId, name: movie.name, icon: cover })
              }
              width={200}
              icon={<Icon name={favHas ? "favorite" : "favorite_border"} size={18} color={favHas ? "#E91E63" : "currentColor"} />}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
