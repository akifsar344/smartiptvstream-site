import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { useSession } from "../../store/session";
import { useCatalog } from "../../store/catalog";
import { SeriesStream, asStr } from "../../data/models";
import { normalizeSeriesInfo, NormEpisode } from "../../data/xtream/info";
import { BackButton } from "../../components/ScreenHeader";
import { useFocusable } from "../../navigation/useFocusable";
import { Icon } from "../../components/Icon";
import { useBack } from "../../navigation/useBack";
import { colors, gradient } from "../../styles/theme";
import { diskCache } from "../../platform/diskCache";
import { userScope } from "../../store/userdata";
import { useResume } from "../../store/resume";
import { formatDuration } from "../../utils/datetime";

// In-memory cache of series_info responses for instant re-open within a session.
const memCache = new Map<string, any>();
const infoKey = (seriesId: number) => `series_info:${userScope()}:${seriesId}`;

type Episode = NormEpisode;

export function SeriesDetailScreen() {
  const t = useT();
  const navigate = useNavigate();
  const location = useLocation();
  const series = (location.state as any)?.series as SeriesStream | undefined;
  const [info, setInfo] = useState<any>(null);
  const [season, setSeason] = useState<string>("");

  useBack(() => {
    navigate(Routes.series);
    return true;
  });

  useEffect(() => {
    if (!series) {
      navigate(Routes.series);
      return;
    }
    let cancelled = false;
    const key = infoKey(series.seriesId);

    // 1) Instant: in-memory cache.
    if (memCache.has(key)) setInfo((prev: any) => prev ?? memCache.get(key));
    // 2) Fast: disk cache (shown until the network refresh lands).
    else
      void diskCache.get(key).then((d) => {
        if (d && !cancelled) setInfo((prev: any) => prev ?? d);
      });

    // 3) Always refresh from the network in the background and overwrite.
    const client = useSession.getState().client;
    if (client) {
      client.getSeriesInfo(series.seriesId).then((d) => {
        if (!d || cancelled) return;
        memCache.set(key, d);
        void diskCache.set(key, d);
        setInfo(d);
      }).catch(() => {});
    } else {
      // M3U: there is no series_info API; use the locally-built payload.
      const local = useCatalog.getState().m3uSeriesInfo[series.seriesId];
      if (local && !cancelled) setInfo(local);
    }

    return () => {
      cancelled = true;
    };
  }, [series, navigate]);

  // All provider-shape handling lives in the shared normalizer so Movies and
  // Series stay consistent across every panel.
  const norm = useMemo(() => normalizeSeriesInfo(info), [info]);
  const seasons = norm.seasons;
  const episodes: Episode[] = useMemo(
    () => norm.bySeason[season] ?? [],
    [norm, season]
  );

  // Keep the selected season valid as data arrives (default to the first one).
  useEffect(() => {
    if (seasons.length && !seasons.includes(season)) setSeason(seasons[0]);
  }, [seasons, season]);

  if (!series) return null;
  const cover = asStr(norm.cover || series.cover);
  const plot = asStr(norm.plot || series.plot);

  const playEpisode = (ep: Episode) => {
    const client = useSession.getState().client;
    // M3U episodes carry a direct URL; Xtream builds it from the client.
    const url = ep.url || (client ? client.seriesUrl(Number(ep.id), ep.ext) : "");
    if (!url) return;
    const saved = useResume.getState().get("series", Number(ep.id));
    const startPositionSec = saved && saved.positionSec > 10 ? saved.positionSec : undefined;
    navigate(Routes.player, {
      state: {
        url,
        title: `${series.name} - ${ep.title}`,
        kind: "vod",
        osTitle: series.name,
        season: Number(ep.season) || undefined,
        episode: ep.episodeNum || undefined,
        startPositionSec,
        resumeMeta: {
          kind: "series",
          id: Number(ep.id),
          seriesId: series.seriesId,
          name: `${series.name} - ${ep.title}`,
          icon: ep.image || cover,
          containerExtension: ep.ext,
          url: ep.url || undefined,
        },
      },
    });
  };

  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
      <div style={{ padding: "16px 24px", display: "flex", alignItems: "center", gap: 16 }}>
        <BackButton onTap={() => navigate(Routes.series)} />
        <span style={{ fontSize: 22, fontWeight: 800 }}>{series.name}</span>
      </div>

      <div style={{ flex: 1, display: "flex", gap: 24, padding: "0 24px 24px", minHeight: 0 }}>
        <div style={{ width: 260, flex: "0 0 auto" }}>
          <img src={cover} alt={series.name} style={{ width: 260, height: 380, objectFit: "cover", borderRadius: 14 }} onError={(e) => ((e.target as HTMLImageElement).style.opacity = "0")} />
          {plot && <p style={{ marginTop: 14, fontSize: 13, lineHeight: 1.5, color: "rgba(255,255,255,0.75)", maxHeight: 200, overflow: "hidden" }}>{plot}</p>}
        </div>

        <div style={{ flex: 1, display: "flex", flexDirection: "column", minHeight: 0 }}>
          <div style={{ display: "flex", gap: 10, marginBottom: 14, flexWrap: "wrap" }}>
            {seasons.map((s, i) => (
              <SeasonTab key={s} label={`S${s}`} active={s === season} autoFocus={i === 0} onTap={() => setSeason(s)} />
            ))}
          </div>
          <div className="scrollable" style={{ flex: 1 }}>
            {episodes.map((ep) => (
              <EpisodeRow key={ep.id} ep={ep} onTap={() => playEpisode(ep)} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function SeasonTab({ label, active, onTap, autoFocus }: { label: string; active: boolean; onTap: () => void; autoFocus?: boolean }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap, onFocus: onTap, autoFocus });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        padding: "8px 18px",
        borderRadius: 8,
        fontSize: 14,
        fontWeight: 700,
        cursor: "pointer",
        background: focused ? gradient(colors.tiles.series) : active ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.05)",
        border: focused ? "2px solid #fff" : "1px solid rgba(255,255,255,0.12)",
      }}
    >
      {label}
    </div>
  );
}

function EpisodeRow({ ep, onTap }: { ep: Episode; onTap: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap });
  const resume = useResume((s) => s.get("series", Number(ep.id)));
  const ratio =
    resume && resume.durationSec > 0 && resume.positionSec > 10
      ? Math.min(1, resume.positionSec / resume.durationSec)
      : 0;
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 16,
        padding: 12,
        marginBottom: 8,
        borderRadius: 12,
        cursor: "pointer",
        background: focused ? "rgba(35,209,42,0.18)" : "rgba(255,255,255,0.04)",
        border: focused ? "2px solid #fff" : "1px solid rgba(255,255,255,0.08)",
      }}
    >
      <div style={{ width: 120, height: 68, borderRadius: 8, overflow: "hidden", background: "rgba(0,0,0,0.3)", flex: "0 0 auto", display: "flex", alignItems: "center", justifyContent: "center" }}>
        {ep.image ? <img src={ep.image} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <Icon name="play_arrow" size={28} color="rgba(255,255,255,0.4)" />}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 15, fontWeight: 700 }}>{ep.episodeNum}. {ep.title}</div>
        {ep.plot && <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{ep.plot}</div>}
        {ratio > 0 && resume && (
          <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ flex: 1, maxWidth: 320, height: 4, borderRadius: 2, background: "rgba(255,255,255,0.18)", overflow: "hidden" }}>
              <div style={{ width: `${Math.max(3, ratio * 100)}%`, height: "100%", background: "#E53935" }} />
            </div>
            <span style={{ fontSize: 11, color: "rgba(255,255,255,0.6)" }}>
              {formatDuration(resume.positionSec)} / {formatDuration(resume.durationSec)}
            </span>
          </div>
        )}
      </div>
      <Icon name="play_circle_outline" size={28} color={focused ? "#fff" : "rgba(255,255,255,0.6)"} />
    </div>
  );
}
