import { useEffect, useId, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { createPlayer } from "../../platform/player/createPlayer";
import { IPlayerAdapter, PlayerState, PlayerTrack } from "../../platform/player/types";
import { focusManager } from "../../navigation/focusManager";
import { useFocusable } from "../../navigation/useFocusable";
import { useBack } from "../../navigation/useBack";
import { Icon } from "../../components/Icon";
import { colors } from "../../styles/theme";
import { CloseButton, backdropClose } from "../../components/Overlay";
import { formatDuration } from "../../utils/datetime";
import { useResume } from "../../store/resume";
import { useT } from "../../i18n/I18nProvider";
import {
  readyProviders,
  searchAllProviders,
  providerFor,
  ProviderGroup,
} from "../../data/subtitles/registry";
import { SubHit } from "../../data/subtitles/types";

interface PlayerNavState {
  url: string;
  fallbackUrl?: string;
  title: string;
  kind: "live" | "vod";
  format?: string;
  startPositionSec?: number;
  // Forces a mounted PlayerScreen to reload when a new website bridge request
  // targets the same /player route.
  bridgeNonce?: number;
  // Clean title used for OpenSubtitles search (without "Series - Episode" noise).
  osTitle?: string;
  season?: number;
  episode?: number;
  resumeMeta?: {
    kind: "movie" | "series";
    id: number;
    seriesId?: number;
    name: string;
    icon: string;
    containerExtension?: string;
    // Direct playback URL (M3U only) so Continue Watching can re-open it.
    url?: string;
  };
}

const SUB_SCALES = [0.75, 1, 1.25, 1.5, 2];

export function PlayerScreen() {
  const navigate = useNavigate();
  const location = useLocation();
  const t = useT();
  const state = (location.state || {}) as PlayerNavState;

  const containerRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<IPlayerAdapter | null>(null);
  const [showControls, setShowControls] = useState(true);
  const [playerState, setPlayerState] = useState<PlayerState>("loading");
  const [time, setTime] = useState({ cur: 0, dur: 0 });
  const [scaleIdx, setScaleIdx] = useState(1);
  const [modal, setModal] = useState<React.ReactNode>(null);
  const hideTimer = useRef<number | null>(null);
  const lastSaveRef = useRef(0);
  const lastTimeRef = useRef({ cur: 0, dur: 0 });

  // Refs mirror state so the single global key listener (registered once) can
  // read the latest values without re-subscribing.
  const showControlsRef = useRef(true);
  const modalOpenRef = useRef(false);
  const playerStateRef = useRef<PlayerState>("loading");
  showControlsRef.current = showControls;
  modalOpenRef.current = modal != null;
  playerStateRef.current = playerState;

  const isLive = state.kind === "live";

  useEffect(() => {
    if (!containerRef.current || !state.url) {
      if (!state.url) navigate(-1);
      return;
    }
    setPlayerState("loading");
    setTime({ cur: 0, dur: 0 });
    lastTimeRef.current = { cur: 0, dur: 0 };
    const player = createPlayer();
    playerRef.current = player;
    player.attach(containerRef.current, {
      onStateChange: setPlayerState,
      onTimeUpdate: (cur, dur) => {
        setTime({ cur, dur });
        lastTimeRef.current = { cur, dur };
        // Save progress periodically. Duration may be unknown (0) for some
        // streams, so we gate on watched seconds (not duration) and still pass
        // dur through for the progress bar when it's available.
        if (state.resumeMeta && cur > 5 && Date.now() - lastSaveRef.current > 5000) {
          lastSaveRef.current = Date.now();
          useResume.getState().save({
            ...state.resumeMeta,
            positionSec: cur,
            durationSec: dur,
            updatedAt: Date.now(),
          });
        }
      },
      onError: () => setPlayerState("error"),
    });
    player.load({
      url: state.url,
      fallbackUrl: state.fallbackUrl,
      kind: state.kind === "live" ? "live" : "vod",
      format: state.format,
      title: state.title,
      startPositionSec: state.startPositionSec,
    });

    return () => {
      // Final flush: persist the exact exit position so Continue Watching
      // resumes precisely (the 5s throttle may have skipped the last seconds).
      const { cur, dur } = lastTimeRef.current;
      if (state.resumeMeta && cur > 5) {
        useResume.getState().save({
          ...state.resumeMeta,
          positionSec: cur,
          durationSec: dur,
          updatedAt: Date.now(),
        });
      }
      player.destroy();
      playerRef.current = null;
    };
    // A normal in-app navigation mounts this screen once (undefined nonce). A
    // later website bridge request changes the nonce and replaces the source.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.bridgeNonce]);

  // Apply subtitle font scale whenever it changes.
  useEffect(() => {
    playerRef.current?.setTextScale?.(SUB_SCALES[scaleIdx]);
  }, [scaleIdx]);

  const armHideTimer = () => {
    if (hideTimer.current) clearTimeout(hideTimer.current);
    hideTimer.current = window.setTimeout(() => {
      if (modalOpenRef.current) return;
      if (playerStateRef.current === "playing") setShowControls(false);
    }, 4500);
  };

  const revealControls = () => {
    setShowControls(true);
    armHideTimer();
    // Move focus onto the play/pause button so OK toggles playback.
    window.setTimeout(() => {
      if (!focusManager.hasActiveLayer()) focusManager.focus("player-playpause");
    }, 30);
  };

  const hideControls = () => {
    setShowControls(false);
    if (hideTimer.current) clearTimeout(hideTimer.current);
  };

  // Tapping/clicking the video area toggles the on-screen controls.
  const toggleControls = () => {
    if (modalOpenRef.current) return;
    if (showControlsRef.current) hideControls();
    else revealControls();
  };

  const closeModal = () => setModal(null);

  const openSubtitles = () => {
    const player = playerRef.current;
    if (!player) return;
    setModal(
      <SubtitleDialog
        t={t}
        embedded={player.getTextTracks()}
        active={player.getActiveTextTrack?.() ?? null}
        scaleIdx={scaleIdx}
        onScale={(idx) => setScaleIdx(idx)}
        onPickEmbedded={(id) => player.setTextTrack(id)}
        onSetExternal={(vtt, label) => player.setExternalSubtitle?.(vtt, label)}
        onClearExternal={() => player.clearExternalSubtitle?.()}
        searchTitle={state.osTitle || state.title}
        season={state.season}
        episode={state.episode}
        onClose={closeModal}
      />,
    );
  };

  const openAudio = () => {
    const player = playerRef.current;
    if (!player) return;
    setModal(
      <TrackDialog
        title={t("audioTrack")}
        tracks={player.getAudioTracks()}
        active={player.getActiveAudioTrack?.() ?? null}
        defaultLabel={t("audioDefault")}
        emptyLabel={t("noSubtitles")}
        onPick={(id) => {
          if (id != null) player.setAudioTrack(id);
        }}
        onClose={closeModal}
      />,
    );
  };

  useEffect(() => {
    revealControls();
    const player = () => playerRef.current;
    const unsub = focusManager.addKeyListener((key) => {
      // While a modal is open let its own back-handler and the focusable
      // system (modal layer) take over.
      if (modalOpenRef.current) return false;

      switch (key) {
        case "back":
          // First Back reveals the controls (never closes the video). A
          // second Back while the controls are visible exits the player.
          if (showControlsRef.current) {
            navigate(-1);
          } else {
            revealControls();
          }
          return true;
        case "rewind":
          if (!isLive) player()?.seekBy(-10);
          revealControls();
          return true;
        case "forward":
          if (!isLive) player()?.seekBy(10);
          revealControls();
          return true;
        case "play":
          player()?.play();
          revealControls();
          return true;
        case "pause":
          player()?.pause();
          revealControls();
          return true;
        case "playpause":
          player()?.togglePlay();
          revealControls();
          return true;
      }

      if (!showControlsRef.current) {
        // Controls hidden: any nav reveals them; left/right also seek.
        if (key === "left") {
          if (!isLive) player()?.seekBy(-10);
          revealControls();
          return true;
        }
        if (key === "right") {
          if (!isLive) player()?.seekBy(10);
          revealControls();
          return true;
        }
        if (key === "up" || key === "down" || key === "enter") {
          revealControls();
          return true;
        }
        return false;
      }

      // Controls visible: keep them up and let the focusable system move
      // between buttons / fire onEnter.
      armHideTimer();
      return false;
    });
    return () => {
      unsub();
      if (hideTimer.current) clearTimeout(hideTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const progress = time.dur > 0 ? (time.cur / time.dur) * 100 : 0;

  return (
    <div
      onClick={toggleControls}
      style={{ width: 1280, height: 720, background: "#000", position: "relative", cursor: "pointer" }}
    >
      <div ref={containerRef} style={{ width: "100%", height: "100%" }} />

      {(playerState === "loading" || playerState === "buffering") && (
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: "50%",
              border: "4px solid #00E5A8",
              borderRightColor: "transparent",
              borderTopColor: "transparent",
              animation: "spin 1s linear infinite",
            }}
          />
        </div>
      )}

      {playerState === "error" && (
        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "#FF7043", fontSize: 20, fontWeight: 700 }}>
          Playback error
        </div>
      )}

      {showControls && (
        <div
          onClick={(e) => e.stopPropagation()}
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            bottom: 0,
            padding: "60px 40px 26px",
            background: "linear-gradient(transparent, rgba(0,0,0,0.85))",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 14 }}>
            <span style={{ fontSize: 20, fontWeight: 700 }}>{state.title}</span>
            {isLive && (
              <span style={{ marginLeft: 8, padding: "3px 10px", borderRadius: 6, background: "#E53935", fontSize: 12, fontWeight: 800 }}>
                LIVE
              </span>
            )}
          </div>
          {!isLive && (
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.8)" }}>{formatDuration(time.cur)}</span>
              <div style={{ flex: 1, height: 6, borderRadius: 3, background: "rgba(255,255,255,0.2)" }}>
                <div style={{ width: `${progress}%`, height: "100%", borderRadius: 3, background: "#3660F5" }} />
              </div>
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.8)" }}>{formatDuration(time.dur)}</span>
            </div>
          )}
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            {!isLive && (
              <CtrlButton icon="replay_10" onTap={() => { playerRef.current?.seekBy(-10); armHideTimer(); }} />
            )}
            <CtrlButton
              icon={playerState === "playing" ? "pause" : "play_arrow"}
              focusKey="player-playpause"
              autoFocus
              big
              onTap={() => { playerRef.current?.togglePlay(); armHideTimer(); }}
            />
            {!isLive && (
              <CtrlButton icon="forward_10" onTap={() => { playerRef.current?.seekBy(10); armHideTimer(); }} />
            )}
            <div style={{ width: 24 }} />
            <CtrlButton icon="subtitles" onTap={openSubtitles} />
            <CtrlButton icon="audiotrack" onTap={openAudio} />
          </div>
        </div>
      )}

      {modal}
    </div>
  );
}

function CtrlButton({
  icon,
  onTap,
  focusKey,
  autoFocus,
  big,
}: {
  icon: string;
  onTap: () => void;
  focusKey?: string;
  autoFocus?: boolean;
  big?: boolean;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ focusKey, autoFocus, onEnter: onTap });
  const size = big ? 56 : 48;
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        width: size,
        height: size,
        borderRadius: 12,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        background: focused ? "#fff" : "rgba(255,255,255,0.12)",
        border: focused ? "2.5px solid #fff" : "2px solid transparent",
      }}
    >
      <Icon name={icon} size={big ? 30 : 24} color={focused ? colors.primary : "#fff"} />
    </div>
  );
}

function trackLabel(track: PlayerTrack, index: number): string {
  const lang = (track.language || "").trim();
  const label = (track.label || "").trim();
  const main = lang ? lang.toUpperCase() : label ? label : `Track ${index + 1}`;
  const codec = (track.codec || "").trim().toUpperCase();
  return codec ? `${main}  (${codec})` : main;
}

function TrackDialog({
  title,
  tracks,
  active,
  allowOff,
  offLabel,
  defaultLabel,
  emptyLabel,
  sizeLabel,
  scaleIdx,
  onScale,
  onPick,
  onClose,
}: {
  title: string;
  tracks: PlayerTrack[];
  active: number | null;
  allowOff?: boolean;
  offLabel?: string;
  defaultLabel?: string;
  emptyLabel: string;
  sizeLabel?: string;
  scaleIdx?: number;
  onScale?: (idx: number) => void;
  onPick: (id: number | null) => void;
  onClose: () => void;
}) {
  const layer = useId();
  const [localScale, setLocalScale] = useState(scaleIdx ?? 1);
  useEffect(() => {
    focusManager.pushLayer(layer);
    return () => focusManager.popLayer(layer);
  }, [layer]);
  useBack(() => {
    onClose();
    return true;
  });

  const hasSizeRow = sizeLabel != null && onScale != null;
  const rows: { id: number | null; label: string }[] = [];
  if (allowOff) rows.push({ id: null, label: offLabel || "Off" });
  tracks.forEach((tr, i) => rows.push({ id: tr.id, label: trackLabel(tr, i) }));
  // Empty audio list → expose a single "Default" entry so the user sees state.
  if (!allowOff && tracks.length === 0 && defaultLabel) {
    rows.push({ id: null, label: defaultLabel });
  }

  const empty = tracks.length === 0 && !allowOff && !defaultLabel;

  const changeScale = (delta: number) => {
    const next = Math.max(0, Math.min(SUB_SCALES.length - 1, localScale + delta));
    setLocalScale(next);
    onScale?.(next);
  };

  return (
    <div
      onClick={backdropClose(onClose)}
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 1000,
        background: "rgba(0,0,0,0.55)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          position: "relative",
          width: 420,
          maxHeight: 520,
          padding: 18,
          borderRadius: 16,
          background: "linear-gradient(135deg, #16203f, #121430)",
          border: "1px solid rgba(255,255,255,0.16)",
          boxShadow: "0 20px 60px rgba(0,0,0,0.6)",
          display: "flex",
          flexDirection: "column",
          gap: 12,
        }}
      >
        <CloseButton onClose={onClose} />
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Icon name={title.toLowerCase().includes("audio") ? "audiotrack" : "subtitles"} size={22} color={colors.btn} />
          <span style={{ fontSize: 18, fontWeight: 800 }}>{title}</span>
        </div>

        {hasSizeRow && (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              padding: "8px 12px",
              borderRadius: 10,
              background: "rgba(255,255,255,0.05)",
            }}
          >
            <Icon name="text_fields" size={18} color="rgba(255,255,255,0.6)" />
            <span style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>{sizeLabel}</span>
            <div style={{ flex: 1 }} />
            <CtrlButton icon="remove" onTap={() => changeScale(-1)} />
            <span style={{ minWidth: 48, textAlign: "center", fontSize: 14, fontWeight: 700 }}>
              {Math.round(SUB_SCALES[localScale] * 100)}%
            </span>
            <CtrlButton icon="add" onTap={() => changeScale(1)} />
          </div>
        )}

        {empty ? (
          <div style={{ padding: 24, textAlign: "center", color: "rgba(255,255,255,0.45)" }}>
            {emptyLabel}
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 6, overflow: "auto" }}>
            {rows.map((r, i) => (
              <TrackRow
                key={`${r.id}-${i}`}
                label={r.label}
                selected={r.id === active}
                layer={layer}
                autoFocus={i === 0}
                onTap={() => {
                  onPick(r.id);
                  onClose();
                }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// Subtitle picker = embedded tracks + OpenSubtitles online search in one modal.
function SubtitleDialog({
  t,
  embedded,
  active,
  scaleIdx,
  onScale,
  onPickEmbedded,
  onSetExternal,
  onClearExternal,
  searchTitle,
  season,
  episode,
  onClose,
}: {
  t: (k: string) => string;
  embedded: PlayerTrack[];
  active: number | null;
  scaleIdx: number;
  onScale: (idx: number) => void;
  onPickEmbedded: (id: number | null) => void;
  onSetExternal: (vtt: string, label: string) => void;
  onClearExternal: () => void;
  searchTitle: string;
  season?: number;
  episode?: number;
  onClose: () => void;
}) {
  const layer = useId();
  const providers = readyProviders();
  const hasProvider = providers.length > 0;
  const [view, setView] = useState<"main" | "files">("main");
  const [localScale, setLocalScale] = useState(scaleIdx);
  const [searching, setSearching] = useState(false);
  const [groups, setGroups] = useState<ProviderGroup[]>([]);
  const [tab, setTab] = useState(0);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    focusManager.pushLayer(layer);
    return () => focusManager.popLayer(layer);
  }, [layer]);

  useBack(() => {
    if (busy) return true;
    if (view === "files") {
      setView("main");
      return true;
    }
    onClose();
    return true;
  });

  const changeScale = (delta: number) => {
    const next = Math.max(0, Math.min(SUB_SCALES.length - 1, localScale + delta));
    setLocalScale(next);
    onScale(next);
  };

  // Query every configured provider (OpenSubtitles, SubDL, …) in parallel and
  // merge the hits. Each provider internally resolves the right title/IMDb
  // match so noisy on-screen titles still land on the correct movie/episode.
  const runSearch = async () => {
    setView("files");
    setSearching(true);
    setError("");
    setGroups([]);
    setTab(0);
    try {
      const g = await searchAllProviders({ title: searchTitle, season, episode });
      setGroups(g);
      // Default to the first tab that actually has results, if any.
      const firstWithHits = g.findIndex((x) => x.hits.length > 0);
      setTab(firstWithHits >= 0 ? firstWithHits : 0);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setSearching(false);
    }
  };

  const pickOnline = async (hit: SubHit) => {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const prov = providerFor(hit);
      if (!prov) {
        setError(t("noSubtitles"));
        setBusy(false);
        return;
      }
      const res = await prov.download(hit);
      if (res.cues > 0) {
        onSetExternal(res.vtt, hit.language || hit.fileName);
        onClose();
      } else {
        // Daily quota → friendly message; otherwise generic "no subtitle".
        setError(res.limited ? t("osLimitReached") : t("noSubtitles"));
        setBusy(false);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
      setBusy(false);
    }
  };

  return (
    <div
      onClick={backdropClose(onClose)}
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 1000,
        background: "rgba(0,0,0,0.55)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          position: "relative",
          width: 440,
          maxHeight: 560,
          padding: 18,
          borderRadius: 16,
          background: "linear-gradient(135deg, #16203f, #121430)",
          border: "1px solid rgba(255,255,255,0.16)",
          boxShadow: "0 20px 60px rgba(0,0,0,0.6)",
          display: "flex",
          flexDirection: "column",
          gap: 12,
        }}
      >
        <CloseButton onClose={onClose} />
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Icon name="subtitles" size={22} color={colors.btn} />
          <span style={{ fontSize: 18, fontWeight: 800 }}>
            {view === "main" ? t("subtitles") : t("searchSubtitles")}
          </span>
        </div>

        {view === "main" && (
          <>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                padding: "8px 12px",
                borderRadius: 10,
                background: "rgba(255,255,255,0.05)",
              }}
            >
              <Icon name="text_fields" size={18} color="rgba(255,255,255,0.6)" />
              <span style={{ fontSize: 13, color: "rgba(255,255,255,0.7)" }}>{t("subtitleSize")}</span>
              <div style={{ flex: 1 }} />
              <CtrlButton icon="remove" onTap={() => changeScale(-1)} />
              <span style={{ minWidth: 48, textAlign: "center", fontSize: 14, fontWeight: 700 }}>
                {Math.round(SUB_SCALES[localScale] * 100)}%
              </span>
              <CtrlButton icon="add" onTap={() => changeScale(1)} />
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 6, overflow: "auto" }}>
              <TrackRow
                label={t("subtitleOff")}
                selected={active == null}
                layer={layer}
                autoFocus
                onTap={() => {
                  onClearExternal();
                  onPickEmbedded(null);
                  onClose();
                }}
              />
              {embedded.map((tr, i) => (
                <TrackRow
                  key={`emb-${tr.id}`}
                  label={`${trackLabel(tr, i)}  ·  ${t("embedded")}`}
                  selected={tr.id === active}
                  layer={layer}
                  onTap={() => {
                    onPickEmbedded(tr.id);
                    onClose();
                  }}
                />
              ))}

              {hasProvider ? (
                <ActionRow
                  icon="search"
                  label={t("searchSubtitles")}
                  layer={layer}
                  onTap={runSearch}
                />
              ) : (
                <div
                  style={{
                    padding: "12px 14px",
                    borderRadius: 10,
                    background: "rgba(255,255,255,0.04)",
                    color: "rgba(255,255,255,0.55)",
                    fontSize: 13,
                  }}
                >
                  {t("osLoginRequired")}
                </div>
              )}
            </div>
          </>
        )}

        {view === "files" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10, overflow: "hidden", minHeight: 0 }}>
            {(searching || busy) && <Spinner />}
            {!searching && !busy && error && (
              <div style={{ padding: 18, textAlign: "center", color: "#FF7043", fontSize: 13 }}>{error}</div>
            )}

            {!searching && !busy && !error && groups.length > 1 && (
              <div style={{ display: "flex", gap: 8 }}>
                {groups.map((g, i) => (
                  <SubTab
                    key={g.id}
                    label={g.name}
                    count={g.hits.length}
                    active={i === tab}
                    layer={layer}
                    autoFocus={i === tab}
                    onTap={() => setTab(i)}
                  />
                ))}
              </div>
            )}

            {!searching && !busy && !error && groups[tab] && (
              <div style={{ display: "flex", flexDirection: "column", gap: 6, overflow: "auto", minHeight: 0 }}>
                {groups[tab].error ? (
                  <div style={{ padding: 18, textAlign: "center", color: "#FFB199", fontSize: 13, lineHeight: 1.5 }}>
                    {groups[tab].error}
                  </div>
                ) : groups[tab].hits.length === 0 ? (
                  <div style={{ padding: 24, textAlign: "center", color: "rgba(255,255,255,0.45)" }}>
                    {t("noResults")}
                  </div>
                ) : (
                  groups[tab].hits.map((hit, i) => (
                    <SubFileRow
                      key={hit.id}
                      hit={hit}
                      layer={layer}
                      autoFocus={groups.length <= 1 && i === 0}
                      onTap={() => void pickOnline(hit)}
                    />
                  ))
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Provider tab in the subtitle search results (OpenSubtitles | SubDL | …).
function SubTab({
  label,
  count,
  active,
  layer,
  autoFocus,
  onTap,
}: {
  label: string;
  count: number;
  active: boolean;
  layer: string;
  autoFocus?: boolean;
  onTap: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    layer,
    autoFocus,
    onEnter: onTap,
    onFocus: onTap,
  });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        flex: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 6,
        padding: "8px 10px",
        borderRadius: 10,
        cursor: "pointer",
        fontSize: 13,
        fontWeight: 700,
        background: focused
          ? "#fff"
          : active
            ? "rgba(54,96,245,0.45)"
            : "rgba(255,255,255,0.06)",
        color: focused ? colors.primary : "#fff",
        border: active ? "2px solid rgba(255,255,255,0.6)" : "2px solid transparent",
      }}
    >
      <span>{label}</span>
      <span style={{ fontSize: 11, opacity: 0.8 }}>({count})</span>
    </div>
  );
}

function Spinner() {
  return (
    <div style={{ padding: 28, display: "flex", justifyContent: "center" }}>
      <div
        style={{
          width: 40,
          height: 40,
          borderRadius: "50%",
          border: "3px solid #3660F5",
          borderRightColor: "transparent",
          borderTopColor: "transparent",
          animation: "spin 1s linear infinite",
        }}
      />
    </div>
  );
}

// One subtitle result file (Mac-app style): filename + language/format/
// downloads/rating meta line, with a per-source provider badge.
function SubFileRow({
  hit,
  layer,
  autoFocus,
  onTap,
}: {
  hit: SubHit;
  layer: string;
  autoFocus?: boolean;
  onTap: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap });
  const meta = [
    hit.language,
    (hit.format || "srt").toLowerCase(),
    hit.downloadCount > 0 ? `${hit.downloadCount}↓` : null,
    hit.rating > 0 ? `★${hit.rating.toFixed(1)}` : null,
    hit.hearingImpaired ? "HI" : null,
  ]
    .filter(Boolean)
    .join("  ·  ");
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "10px 14px",
        borderRadius: 10,
        cursor: "pointer",
        background: focused ? "rgba(54,96,245,0.35)" : "rgba(255,255,255,0.04)",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      <Icon name="subtitles" size={20} color={focused ? "#fff" : colors.btn} />
      <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", gap: 3 }}>
        <span
          style={{
            fontSize: 14,
            fontWeight: 700,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
          }}
        >
          {hit.fileName || hit.language}
        </span>
        <span style={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }}>{meta}</span>
      </div>
      <span
        style={{
          flexShrink: 0,
          padding: "3px 8px",
          borderRadius: 6,
          fontSize: 11,
          fontWeight: 700,
          color: "#cfe0ff",
          background: "rgba(54,96,245,0.25)",
        }}
      >
        {hit.providerName}
      </span>
    </div>
  );
}

function ActionRow({
  icon,
  label,
  hint,
  layer,
  autoFocus,
  onTap,
}: {
  icon: string;
  label: string;
  hint?: string;
  layer: string;
  autoFocus?: boolean;
  onTap: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "12px 14px",
        borderRadius: 10,
        cursor: "pointer",
        background: focused ? "rgba(54,96,245,0.35)" : "rgba(255,255,255,0.05)",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      <Icon name={icon} size={20} color={focused ? "#fff" : colors.btn} />
      <span style={{ flex: 1, fontSize: 15, fontWeight: 600 }}>{label}</span>
      {hint && <span style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", fontFamily: "monospace" }}>{hint}</span>}
    </div>
  );
}

function TrackRow({
  label,
  selected,
  layer,
  autoFocus,
  onTap,
}: {
  label: string;
  selected: boolean;
  layer: string;
  autoFocus?: boolean;
  onTap: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "12px 14px",
        borderRadius: 10,
        cursor: "pointer",
        background: focused ? "rgba(54,96,245,0.35)" : selected ? "rgba(54,96,245,0.16)" : "rgba(255,255,255,0.05)",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      <span style={{ flex: 1, fontSize: 15, fontWeight: 600 }}>{label}</span>
      {selected && <Icon name="check_circle" size={20} color={colors.btn} />}
    </div>
  );
}
