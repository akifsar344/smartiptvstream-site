import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { colors, gradient } from "../../styles/theme";
import { Routes } from "../../routes";
import { useSession } from "../../store/session";
import { useCatalog } from "../../store/catalog";
import { useFocusable } from "../../navigation/useFocusable";
import { Icon } from "../../components/Icon";
import { Button } from "../../components/Button";
import { useBack } from "../../navigation/useBack";

export function UserListScreen() {
  const t = useT();
  const navigate = useNavigate();
  const location = useLocation();
  const profiles = useSession((s) => s.profiles);
  const removeProfile = useSession((s) => s.removeProfile);
  // Name of the profile we're switching to; non-null shows the spinner overlay.
  const [switching, setSwitching] = useState<string | null>(null);

  // Where this screen was opened from decides where X / Back returns to:
  // opened from the home page → back to home; from login → back to login.
  const from = (location.state as { from?: string } | null)?.from;
  const exitTo = from === "home" ? Routes.home : Routes.login;

  useBack(() => {
    if (switching) return true; // block back while a switch is in flight
    navigate(exitTo);
    return true;
  });

  const select = async (id: string) => {
    if (switching) return; // ignore taps while a switch is already running
    const { setActive, buildClient, profiles, setUserData } = useSession.getState();
    const p = profiles.find((x) => x.id === id)!;
    setSwitching(p.playlistName);
    setActive(id);
    try {
      if (p.type === "xtream") {
        const client = buildClient(p);
        if (client) {
          const user = await client.authenticate();
          setUserData(user);
          await useCatalog.getState().loadForScope();
        }
      } else if (p.type === "m3u") {
        // M3U has no auth; (re)build the catalog from the playlist.
        await useCatalog.getState().loadForScope();
      }
      navigate(Routes.home, { replace: true });
    } catch {
      // Authentication / catalog load failed → drop the spinner so the user
      // can pick again instead of being stuck.
      setSwitching(null);
    }
  };

  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column", padding: 40 }}>
      <div style={{ display: "flex", alignItems: "center", marginBottom: 24, gap: 16 }}>
        <h1 style={{ fontSize: 28, fontWeight: 800, flex: 1, margin: 0 }}>{t("usersList")}</h1>
        <CloseButton onTap={() => navigate(exitTo)} />
      </div>
      <div
        className="scrollable"
        style={{
          flex: 1,
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 18,
          alignContent: "start",
        }}
      >
        {profiles.map((p, i) => (
          <UserCard
            key={p.id}
            name={p.playlistName}
            type={p.type}
            autoFocus={i === 0}
            onTap={() => select(p.id)}
            onRemove={() => removeProfile(p.id)}
          />
        ))}
        <AddCard onTap={() => navigate(Routes.login)} autoFocus={profiles.length === 0} />
      </div>
      <div style={{ marginTop: 20 }}>
        <Button label={t("addPlayer")} onTap={() => navigate(Routes.login)} width={220} />
      </div>

      {switching && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 2000,
            background: "rgba(0,0,0,0.78)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 26,
          }}
        >
          <div style={{ position: "relative", width: 96, height: 96 }}>
            <div
              style={{
                position: "absolute",
                inset: 0,
                borderRadius: "50%",
                border: `4px solid ${colors.accentRing}`,
                borderRightColor: "transparent",
                borderTopColor: "transparent",
                animation: "spin 1.1s linear infinite",
                filter: `drop-shadow(0 0 10px ${colors.accentRing})`,
              }}
            />
          </div>
          <div style={{ fontSize: 18, fontWeight: 700, color: "#fff" }}>{switching}</div>
          <div style={{ fontSize: 14, color: "rgba(255,255,255,0.7)" }}>{t("loading")}</div>
        </div>
      )}
    </div>
  );
}

function CloseButton({ onTap }: { onTap: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        width: 48,
        height: 48,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        flex: "0 0 auto",
        background: focused ? "#fff" : "rgba(255,255,255,0.08)",
        border: focused ? "3px solid #fff" : "1px solid rgba(255,255,255,0.2)",
        transform: focused ? "scale(1.08)" : "scale(1)",
      }}
    >
      <Icon name="close" size={24} color={focused ? colors.primary : "#fff"} />
    </div>
  );
}

function UserCard({
  name,
  type,
  onTap,
  onRemove,
  autoFocus,
}: {
  name: string;
  type: string;
  onTap: () => void;
  onRemove: () => void;
  autoFocus?: boolean;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap, autoFocus });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        height: 150,
        borderRadius: 16,
        background: focused ? gradient(colors.tiles.live) : "rgba(255,255,255,0.05)",
        border: focused ? "3px solid #fff" : "1px solid rgba(255,255,255,0.12)",
        transform: focused ? "scale(1.05)" : "scale(1)",
        boxShadow: focused ? "0 0 28px rgba(11,44,255,0.5)" : "none",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 12,
        cursor: "pointer",
        position: "relative",
      }}
    >
      <Icon name="manage_accounts" size={44} color="#fff" />
      <span style={{ fontSize: 16, fontWeight: 700, textAlign: "center", padding: "0 10px" }}>{name}</span>
      <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)", textTransform: "uppercase" }}>{type}</span>
      {focused && (
        <div
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          style={{ position: "absolute", top: 8, right: 8, width: 28, height: 28, borderRadius: "50%", background: "rgba(229,57,53,0.85)", display: "flex", alignItems: "center", justifyContent: "center" }}
        >
          <Icon name="close" size={16} color="#fff" />
        </div>
      )}
    </div>
  );
}

function AddCard({ onTap, autoFocus }: { onTap: () => void; autoFocus?: boolean }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap, autoFocus });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        height: 150,
        borderRadius: 16,
        background: focused ? "#fff" : "rgba(255,255,255,0.05)",
        border: focused ? "3px solid #fff" : "1px dashed rgba(255,255,255,0.3)",
        transform: focused ? "scale(1.05)" : "scale(1)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 10,
        cursor: "pointer",
        color: focused ? colors.primary : "#fff",
      }}
    >
      <Icon name="download" size={40} color={focused ? colors.primary : "#fff"} style={{ transform: "rotate(180deg)" }} />
      <span style={{ fontSize: 15, fontWeight: 700 }}>+ {""}</span>
    </div>
  );
}
