import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useSession } from "../../store/session";
import { useCatalog } from "../../store/catalog";
import { useAccess } from "../../store/access";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { colors } from "../../styles/theme";
import { asset } from "../../platform/asset";

export function SplashScreen() {
  const navigate = useNavigate();
  const t = useT();
  const hydrate = useSession((s) => s.hydrate);
  const [status, setStatus] = useState("");

  useEffect(() => {
    let cancelled = false;
    (async () => {
      hydrate();
      // allow hydrate to settle
      await new Promise((r) => setTimeout(r, 50));
      const { activeProfile, profiles, setUserData, client } =
        useSession.getState();
      const active = activeProfile();

      if (!active) {
        await delay(900);
        if (cancelled) return;
        navigate(profiles.length ? Routes.userList : Routes.login, {
          replace: true,
        });
        return;
      }

      if (active.type === "xtream" && client) {
        setStatus(t("checkingUpdates"));
        try {
          const user = await client.authenticate();
          if (cancelled) return;
          if (!user) {
            navigate(Routes.userList, { replace: true });
            return;
          }
          setUserData(user);
          setStatus(t("loading"));
          await useCatalog.getState().loadForScope();
        } catch {
          /* network errors handled inside */
        }
      } else if (active.type === "m3u") {
        // Rebuild the M3U catalog from the playlist (instant from cache, then
        // refreshed in the background by loadForScope).
        setStatus(t("loading"));
        try {
          await useCatalog.getState().loadForScope();
        } catch {
          /* soft-fail: open the app anyway */
        }
      }
      if (cancelled) return;
      // Resolve entitlement (24h trial / Pro license) before entering the app so
      // a locked device lands on the paywall instead of flashing the dashboard.
      try {
        await useAccess.getState().init();
      } catch {
        /* offline: fall back to cached entitlement */
      }
      if (cancelled) return;
      navigate(useAccess.getState().blocked ? Routes.paywall : Routes.home, {
        replace: true,
      });
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="authbg">
      <div style={{ position: "relative", width: 240, height: 240 }}>
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: "50%",
            border: `4px solid ${colors.accentRing}`,
            borderRightColor: "transparent",
            borderTopColor: "transparent",
            animation: "spin 1.2s linear infinite",
            filter: `drop-shadow(0 0 12px ${colors.accentRing})`,
          }}
        />
        <img
          src={asset("assets/Logo_inn.png")}
          alt="logo"
          style={{
            position: "absolute",
            inset: 30,
            width: 180,
            height: 180,
            objectFit: "contain",
            animation: "pulseGlow 2s ease-in-out infinite",
          }}
        />
      </div>
      <div
        style={{
          marginTop: 36,
          fontSize: 17,
          letterSpacing: 2,
          color: "rgba(255,255,255,0.85)",
          fontWeight: 600,
        }}
      >
        {status || "Smart IPTV Stream"}
      </div>
    </div>
  );
}

function delay(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}
