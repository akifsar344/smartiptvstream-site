import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { useCatalog } from "../../store/catalog";
import { useResume } from "../../store/resume";
import { MovieStream } from "../../data/models";
import { CatalogBrowser, BrowseItem, extractYear, parseTs } from "../shared/CatalogBrowser";

// Cache the mapped list keyed by the source array reference so re-entering the
// screen (component remounts) doesn't re-map 100k+ items every time.
let cache: { src: MovieStream[]; items: BrowseItem[]; byId: Map<number, BrowseItem> } | null = null;
function mapMovies(streams: MovieStream[]) {
  if (cache && cache.src === streams) return cache;
  const items = streams.map((m) => ({
    id: m.streamId,
    name: m.name,
    image: m.streamIcon,
    rating: m.rating,
    categoryId: m.categoryId,
    added: parseTs(m.added),
    year: extractYear(m.name),
  }));
  const byId = new Map(items.map((it) => [it.id, it]));
  cache = { src: streams, items, byId };
  return cache;
}

export function MoviesScreen() {
  const t = useT();
  const navigate = useNavigate();
  const categories = useCatalog((s) => s.movieCategories);
  const streams = useCatalog((s) => s.movieStreams);
  const resumeItems = useResume((s) => s.items);

  const { items, byId } = useMemo(() => mapMovies(streams), [streams]);

  const recentItems: BrowseItem[] = useMemo(() => {
    return resumeItems
      .filter((r) => r.kind === "movie")
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .map((r) => byId.get(r.id))
      .filter((x): x is BrowseItem => !!x);
  }, [resumeItems, byId]);

  return (
    <CatalogBrowser
      kind="movie"
      title={t("movies")}
      catTitle={t("movieCate")}
      itemTitle={t("movies")}
      categories={categories}
      items={items}
      recentItems={recentItems}
      onOpen={(it) => {
        const movie = streams.find((m) => m.streamId === it.id);
        if (movie) navigate(Routes.movieDetail, { state: { movie } });
      }}
      onBack={() => navigate(Routes.home)}
    />
  );
}
