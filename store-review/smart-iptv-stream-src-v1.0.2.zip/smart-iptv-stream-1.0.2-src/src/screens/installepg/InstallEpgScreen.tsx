import { useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { ScreenHeader } from "../../components/ScreenHeader";
import { Icon } from "../../components/Icon";
import { useFocusable } from "../../navigation/useFocusable";
import { focusManager } from "../../navigation/focusManager";
import { useBack } from "../../navigation/useBack";
import { useCatalog } from "../../store/catalog";
import { useSession } from "../../store/session";
import { LiveStream, ShortEpgItem } from "../../data/models";
import { colors } from "../../styles/theme";

const ALL = "ALL";

export function InstallEpgScreen() {
  const t = useT();
  const navigate = useNavigate();
  const categories = useCatalog((s) => s.liveCategories);
  const streams = useCatalog((s) => s.liveStreams);

  const [selectedCat, setSelectedCat] = useState(ALL);
  const [channel, setChannel] = useState<LiveStream | null>(null);
  const [epg, setEpg] = useState<ShortEpgItem[]>([]);
  const [loading, setLoading] = useState(false);

  useBack(() => {
    navigate(Routes.home);
    return true;
  });

  const cats = useMemo(() => {
    const list: { id: string; name: string }[] = [{ id: ALL, name: ALL }];
    for (const c of categories) list.push({ id: c.categoryId, name: c.categoryName });
    return list;
  }, [categories]);

  const channels = useMemo(() => {
    const base = selectedCat === ALL ? streams : streams.filter((s) => s.categoryId === selectedCat);
    return base.slice(0, 600);
  }, [selectedCat, streams]);

  const loadEpg = async (ch: LiveStream) => {
    setChannel(ch);
    setLoading(true);
    setEpg([]);
    const client = useSession.getState().client;
    try {
      const list = (await client?.getGuide(ch.streamId)) ?? [];
      setEpg(list);
    } catch {
      setEpg([]);
    } finally {
      setLoading(false);
    }
  };

  const firstChannelKey = channels.length ? `epg-ch-${channels[0].streamId}` : "";

  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
      <ScreenHeader title={t("epgCategories")} onBack={() => navigate(Routes.home)} />

      {/* Horizontal category strip */}
      <div className="scrollable" style={{ display: "flex", gap: 8, padding: "6px 12px", overflowX: "auto", flex: "0 0 auto" }}>
        {cats.map((c, i) => (
          <CatChip
            key={c.id}
            label={c.name}
            selected={c.id === selectedCat}
            autoFocus={i === 0}
            onFocus={() => setSelectedCat(c.id)}
            onEnter={() => firstChannelKey && focusManager.focus(firstChannelKey)}
          />
        ))}
      </div>

      <div style={{ flex: 1, display: "flex", minHeight: 0, padding: "4px 12px 12px", gap: 10 }}>
        {/* Channel list */}
        <div style={{ flex: 1, minWidth: 0, display: "flex", flexDirection: "column", background: "rgba(6,23,86,0.45)", borderRadius: 12, border: "1px solid rgba(255,255,255,0.08)", overflow: "hidden" }}>
          <div style={{ padding: "10px 14px 4px", fontSize: 12, fontWeight: 800, letterSpacing: 1, color: "rgba(255,255,255,0.55)" }}>
            {t("channels")}
          </div>
          <div className="scrollable" style={{ flex: 1, padding: "4px 8px" }}>
            {channels.map((ch) => (
              <EpgChannelRow
                key={ch.streamId}
                channel={ch}
                selected={channel?.streamId === ch.streamId}
                onEnter={() => loadEpg(ch)}
                onRight={() => focusManager.focus("epg-panel")}
              />
            ))}
          </div>
        </div>

        {/* EPG detail panel */}
        <EpgPanel
          channel={channel}
          epg={epg}
          loading={loading}
          onLeft={() => channel && focusManager.focus(`epg-ch-${channel.streamId}`)}
        />
      </div>
    </div>
  );
}

function CatChip({
  label,
  selected,
  autoFocus,
  onFocus,
  onEnter,
}: {
  label: string;
  selected: boolean;
  autoFocus?: boolean;
  onFocus: () => void;
  onEnter: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ autoFocus, onFocus, onEnter });
  return (
    <div
      ref={ref}
      onClick={onEnter}
      className="focusable"
      style={{
        flex: "0 0 auto",
        padding: "8px 16px",
        borderRadius: 10,
        cursor: "pointer",
        fontSize: 13,
        fontWeight: selected || focused ? 700 : 500,
        whiteSpace: "nowrap",
        background: focused ? "#3D58BA" : selected ? "rgba(61,88,186,0.4)" : "rgba(255,255,255,0.06)",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      {label}
    </div>
  );
}

function EpgChannelRow({
  channel,
  selected,
  onEnter,
  onRight,
}: {
  channel: LiveStream;
  selected: boolean;
  onEnter: () => void;
  onRight: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: `epg-ch-${channel.streamId}`,
    onEnter,
    onArrow: (d) => (d === "right" ? (onRight(), true) : false),
  });
  return (
    <div
      ref={ref}
      onClick={onEnter}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "9px 10px",
        marginBottom: 4,
        borderRadius: 10,
        cursor: "pointer",
        minWidth: 0,
        background: focused ? "#3D58BA" : selected ? "rgba(61,88,186,0.4)" : "transparent",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      <div style={{ width: 34, height: 34, borderRadius: 7, background: "rgba(255,255,255,0.06)", display: "flex", alignItems: "center", justifyContent: "center", flex: "0 0 auto", overflow: "hidden" }}>
        {channel.streamIcon ? (
          <img src={channel.streamIcon} alt="" loading="lazy" style={{ width: "100%", height: "100%", objectFit: "contain" }} onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />
        ) : (
          <Icon name="live_tv" size={16} color="rgba(255,255,255,0.4)" />
        )}
      </div>
      <span style={{ flex: 1, fontSize: 13, fontWeight: focused ? 700 : 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {channel.name}
      </span>
    </div>
  );
}

function EpgPanel({
  channel,
  epg,
  loading,
  onLeft,
}: {
  channel: LiveStream | null;
  epg: ShortEpgItem[];
  loading: boolean;
  onLeft: () => void;
}) {
  const t = useT();
  const scrollRef = useRef<HTMLDivElement>(null);
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey: "epg-panel",
    onArrow: (d) => {
      if (d === "left") return onLeft(), true;
      if (d === "down") return scrollRef.current?.scrollBy({ top: 90 }), true;
      if (d === "up") return scrollRef.current?.scrollBy({ top: -90 }), true;
      return false;
    },
  });
  return (
    <div
      ref={ref}
      className="focusable"
      style={{
        flex: 3,
        minWidth: 0,
        borderRadius: 12,
        background: "rgba(255,255,255,0.06)",
        border: focused ? "2px solid #fff" : "2px solid rgba(255,255,255,0.08)",
        padding: 16,
        display: "flex",
        flexDirection: "column",
        minHeight: 0,
      }}
    >
      {channel && (
        <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 10, color: "#fff" }}>{channel.name}</div>
      )}
      <div ref={scrollRef} className="scrollable" style={{ flex: 1, minHeight: 0 }}>
        {loading ? (
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", paddingTop: 40 }}>
            <Spinner />
          </div>
        ) : !channel ? (
          <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 15, textAlign: "center", paddingTop: 40 }}>
            {t("selectChannelForGuide")}
          </div>
        ) : epg.length === 0 ? (
          <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 15, textAlign: "center", paddingTop: 40 }}>
            {t("noEpgData")}
          </div>
        ) : (
          epg.map((p, i) => (
            <div key={i} style={{ padding: "10px 0", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
              <div style={{ display: "flex", gap: 12, alignItems: "baseline" }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: i === 0 ? "#FFA726" : colors.btn, minWidth: 120 }}>
                  {fmtEpgTime(p.start)} - {fmtEpgTime(p.end)}
                </span>
                <span style={{ fontSize: 14, fontWeight: 600, color: i === 0 ? "#FFA726" : "#fff" }}>{p.title}</span>
              </div>
              {p.description && (
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", marginTop: 4, lineHeight: 1.4 }}>{p.description}</div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

function Spinner() {
  return (
    <div
      style={{
        width: 48,
        height: 48,
        borderRadius: "50%",
        border: "4px solid #00E5A8",
        borderRightColor: "transparent",
        borderTopColor: "transparent",
        animation: "spin 1s linear infinite",
      }}
    />
  );
}

export function fmtEpgTime(s: string): string {
  if (!s) return "";
  const d = new Date(s.replace(" ", "T"));
  if (isNaN(d.getTime())) return s;
  return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
}
