import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { colors, gradient } from "../../styles/theme";
import { Routes } from "../../routes";
import { IconCircle, Tile, hexA } from "./HomeWidgets";
import { useClock, formatHeaderDate, formatExpiry, expiryDaysLeft } from "../../utils/datetime";
import { useSession } from "../../store/session";
import { useSettings } from "../../store/settings";
import { useCatalog } from "../../store/catalog";
import { useResume } from "../../store/resume";
import { useFocusable } from "../../navigation/useFocusable";
import { Icon } from "../../components/Icon";
import { exitApp } from "../../platform/device";
import { useAccess } from "../../store/access";
import { useAuth } from "../../store/auth";
import { ContinueWatchingModal } from "./ContinueWatchingModal";
import { RateAppModal } from "./RateAppModal";
import { asset } from "../../platform/asset";

export function HomeScreen() {
  const navigate = useNavigate();
  const t = useT();
  const now = useClock();
  const hour24 = useSettings((s) => s.hour24);

  const userData = useSession((s) => s.userData);
  const logout = useSession((s) => s.logout);
  const liveStreams = useCatalog((s) => s.liveStreams);
  const movieStreams = useCatalog((s) => s.movieStreams);
  const seriesStreams = useCatalog((s) => s.seriesStreams);

  const [refreshing, setRefreshing] = useState(false);
  const [showContinue, setShowContinue] = useState(false);
  const ratePending = useAccess((s) => s.ratePending);
  const isPro = useAccess((s) => s.isPro);
  const catalogLoaded = useCatalog((s) => s.loaded);

  // Ensure the dashboard always has its catalog. When the app opens straight to
  // Home (returning user, or right after Pro) the splash catalog load may have
  // been skipped, leaving the counters at zero. Load cache-first (instant) and
  // refresh in the background — no manual "refresh" tap needed.
  useEffect(() => {
    if (catalogLoaded) return;
    if (!useSession.getState().activeProfile()) return;
    void useCatalog.getState().loadForScope();
  }, [catalogLoaded]);

  const handleLogout = () => {
    logout();
    navigate(Routes.userList, { replace: true });
  };
  // On the web build the "power" button can't close a browser tab, so it signs
  // the user out of their account instead. Native TV builds keep exitApp().
  const handleAppExit = () => {
    if (useAuth.getState().status === "authed") {
      useAuth.getState().logout();
    } else {
      exitApp();
    }
  };
  const handleRefresh = async () => {
    if (refreshing) return;
    setRefreshing(true);
    try {
      await useCatalog.getState().loadForScope(true);
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <div
      className="fullbg"
      style={{ display: "flex", flexDirection: "column", padding: "10px 0 0" }}
    >
      {/* Header */}
      <div style={{ padding: "0 10px" }}>
        <div
          style={{
            height: 68,
            padding: "0 16px",
            borderRadius: 12,
            background: colors.headerBg,
            border: `1px solid ${colors.headerBorder}`,
            boxShadow: "0 6px 20px rgba(0,0,0,0.25)",
            display: "flex",
            flexDirection: "column",
          }}
        >
          <div style={{ flex: 1, display: "flex", alignItems: "center" }}>
            <img
              src={asset("assets/Logo_inn.png")}
              alt="logo"
              style={{ width: 46, height: 46, objectFit: "contain" }}
            />
            <span
              style={{
                marginLeft: 10,
                color: "rgba(255,255,255,0.70)",
                fontSize: 13,
              }}
            >
              {formatHeaderDate(now, hour24)}
            </span>
            <div style={{ flex: 1 }} />
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <IconCircle icon="workspace_premium" fg={colors.iconFg.premium} onTap={() => navigate(Routes.paywall)} badge={isPro ? "PRO" : undefined} />
              <IconCircle icon="manage_accounts" fg={colors.iconFg.account} onTap={() => navigate(Routes.userList, { state: { from: "home" } })} />
              <IconCircle icon="restart_alt" fg={colors.iconFg.refresh} onTap={handleRefresh} />
              <IconCircle icon="settings" fg={colors.iconFg.settings} onTap={() => navigate(Routes.settings)} />
              <IconCircle icon="info_outline" fg={colors.iconFg.info} onTap={() => navigate(Routes.aboutApp)} />
              <IconCircle icon="exit_to_app" fg={colors.iconFg.logout} onTap={handleLogout} />
              <IconCircle icon="power_settings_new" fg={colors.iconFg.power} onTap={handleAppExit} />
            </div>
          </div>
          <div
            style={{
              height: 2,
              background: gradient(colors.dividerGradient, "90deg"),
              boxShadow: "0 0 10px rgba(138,43,226,0.35)",
            }}
          />
        </div>
      </div>

      {/* Dashboard */}
      <div style={{ flex: 1, padding: "8px 20px", display: "flex", gap: 10 }}>
        <div style={{ flex: 3, display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ flex: 1, display: "flex", gap: 10 }}>
            <Tile gradientColors={colors.tiles.live} icon="live_tv" label={t("livetv")} autoFocus onTap={() => navigate(Routes.liveTv)} />
            <Tile gradientColors={colors.tiles.movies} icon="play_circle_fill" label={t("movies")} onTap={() => navigate(Routes.movies)} />
            <Tile gradientColors={colors.tiles.series} icon="movie" label={t("series")} onTap={() => navigate(Routes.series)} />
          </div>
          <div style={{ flex: 1, display: "flex", gap: 10 }}>
            <Tile gradientColors={colors.tiles.multiscreen} imagePath={asset("assets/multiscreen.png")} label={t("multiscreen")} onTap={() => navigate(Routes.multiScreen)} />
            <Tile gradientColors={colors.tiles.epg} imagePath={asset("assets/icx_epg.png")} label={t("installEpg")} onTap={() => navigate(Routes.installEpg)} />
            <Tile gradientColors={colors.tiles.catchup} imagePath={asset("assets/Catch_up_icon.png")} label={t("catchUp")} onTap={() => navigate(Routes.catchUp)} />
          </div>
        </div>
        <ContinueTile onOpen={() => setShowContinue(true)} />
      </div>

      {/* Bottom status bar */}
      <div style={{ padding: "0 10px 8px" }}>
        <BottomStatusBar
          liveCount={liveStreams.length}
          moviesCount={movieStreams.length}
          seriesCount={seriesStreams.length}
          expiry={userData?.userInfo.expDate || ""}
          username={userData?.userInfo.username || useSession.getState().activeProfile()?.playlistName || ""}
        />
      </div>

      {refreshing && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 2000,
            background: "rgba(0,0,0,0.78)",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 26,
          }}
        >
          <div style={{ position: "relative", width: 96, height: 96 }}>
            <div
              style={{
                position: "absolute",
                inset: 0,
                borderRadius: "50%",
                border: `4px solid ${colors.accentRing}`,
                borderRightColor: "transparent",
                borderTopColor: "transparent",
                animation: "spin 1.1s linear infinite",
                filter: `drop-shadow(0 0 10px ${colors.accentRing})`,
              }}
            />
          </div>
          <div style={{ fontSize: 16, color: "rgba(255,255,255,0.85)", fontWeight: 700 }}>{t("loading")}</div>
        </div>
      )}

      {showContinue && <ContinueWatchingModal onClose={() => setShowContinue(false)} />}
      {ratePending && !showContinue && <RateAppModal />}
    </div>
  );
}

function ContinueTile({ onOpen }: { onOpen: () => void }) {
  const t = useT();
  const items = useResume((s) => s.items);
  const hasData = items.length > 0;
  const { ref, focused } = useFocusable<HTMLDivElement>({
    onEnter: onOpen,
  });
  return (
    <div
      ref={ref}
      onClick={onOpen}
      className="focusable"
      style={{
        flex: 1,
        borderRadius: 16,
        background: gradient(colors.tiles.continue),
        border: focused ? "3px solid #fff" : "1px solid rgba(255,255,255,0.08)",
        transform: focused ? "scale(1.04)" : "scale(1)",
        boxShadow: focused
          ? `0 0 32px 8px ${hexA("#E91E63", 0.55)}`
          : hasData
          ? `0 0 16px 1px ${hexA("#FF80AB", 0.2)}`
          : "0 10px 18px rgba(0,0,0,0.35)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
      }}
    >
      <div
        style={{
          width: focused ? 70 : 60,
          height: focused ? 70 : 60,
          borderRadius: "50%",
          background: `rgba(255,255,255,${focused ? 0.2 : 0.12})`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Icon name="play_circle_outline" size={focused ? 34 : 28} color={focused ? "#fff" : hasData ? "#FF80AB" : "rgba(255,255,255,0.7)"} />
      </div>
      <div style={{ marginTop: 10, color: "#fff", fontSize: 19, fontWeight: 700, textAlign: "center", padding: "0 8px" }}>
        {t("continueWatchingHeader")}
      </div>
    </div>
  );
}

function BottomStatusBar({
  liveCount,
  moviesCount,
  seriesCount,
  expiry,
  username,
}: {
  liveCount: number;
  moviesCount: number;
  seriesCount: number;
  expiry: string;
  username: string;
}) {
  const t = useT();
  const total = liveCount + moviesCount + seriesCount;
  const days = expiryDaysLeft(expiry);
  let expiryDot = colors.statusDot.expiryOk;
  if (days != null) {
    if (days <= 0) expiryDot = colors.statusDot.expiryExpired;
    else if (days <= 3) expiryDot = colors.statusDot.expirySoon;
    else if (days <= 7) expiryDot = colors.statusDot.expiryWarn;
  }
  return (
    <div
      style={{
        height: 76,
        padding: "10px 16px",
        borderRadius: 16,
        background: gradient(colors.bottomBarGradient),
        border: "1.5px solid rgba(255,255,255,0.18)",
        boxShadow: "0 -4px 20px rgba(0,0,0,0.4)",
        display: "flex",
        gap: 10,
      }}
    >
      <Chip dot={expiryDot} title={t("expiaryDate")} subtitle={expiry ? formatExpiry(expiry) : "Unlimited"} />
      <Chip dot={colors.statusDot.live} title={t("livetv")} subtitle={String(liveCount)} />
      <Chip dot={colors.statusDot.movies} title={t("movies")} subtitle={String(moviesCount)} />
      <Chip dot={colors.statusDot.series} title={t("series")} subtitle={String(seriesCount)} />
      <Chip dot={colors.statusDot.total} title="Total" subtitle={String(total)} />
      <Chip dot={colors.statusDot.loggedIn} title={t("loggedIn")} subtitle={username} />
    </div>
  );
}

function Chip({ dot, title, subtitle }: { dot: string; title: string; subtitle: string }) {
  return (
    <div
      style={{
        flex: 1,
        padding: "10px 12px",
        borderRadius: 14,
        background: "linear-gradient(135deg, rgba(255,255,255,0.12), rgba(255,255,255,0.06))",
        border: "1.2px solid rgba(255,255,255,0.20)",
        display: "flex",
        alignItems: "center",
        gap: 8,
        minWidth: 0,
      }}
    >
      <span
        style={{
          width: 8,
          height: 8,
          borderRadius: "50%",
          background: dot,
          boxShadow: `0 0 8px 1px ${dot}`,
          flex: "0 0 auto",
        }}
      />
      <div style={{ minWidth: 0, display: "flex", flexDirection: "column", justifyContent: "center" }}>
        <span style={{ fontSize: 10, fontWeight: 700, color: "rgba(255,255,255,0.7)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {title}
        </span>
        <span style={{ fontSize: 12, fontWeight: 800, color: "rgba(255,255,255,0.95)", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {subtitle}
        </span>
      </div>
    </div>
  );
}
