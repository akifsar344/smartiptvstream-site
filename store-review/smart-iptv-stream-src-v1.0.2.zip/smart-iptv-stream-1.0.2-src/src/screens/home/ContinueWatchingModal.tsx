import { useEffect, useId, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { Icon } from "../../components/Icon";
import { colors } from "../../styles/theme";
import { useFocusable } from "../../navigation/useFocusable";
import { focusManager } from "../../navigation/focusManager";
import { useBack } from "../../navigation/useBack";
import { useSession } from "../../store/session";
import { useSettings } from "../../store/settings";
import { useResume, ResumeItem, ResumeKind } from "../../store/resume";
import { CloseButton, backdropClose } from "../../components/Overlay";
import { formatDuration } from "../../utils/datetime";

const TABS: { kind: ResumeKind; labelKey: string; icon: string }[] = [
  { kind: "live", labelKey: "livetv", icon: "live_tv" },
  { kind: "movie", labelKey: "movies", icon: "play_circle_fill" },
  { kind: "series", labelKey: "series", icon: "movie" },
];

// Continue Watching overlay, ported 1:1 from the Android TV source
// (continue_watching_modal.dart): three tabs (Live TV / Movies / Series),
// each row resumes playback or can be removed from history.
export function ContinueWatchingModal({ onClose }: { onClose: () => void }) {
  const t = useT();
  const navigate = useNavigate();
  const layer = useId();
  const items = useResume((s) => s.items);
  const remove = useResume((s) => s.remove);
  const [tab, setTab] = useState(0);

  useEffect(() => {
    focusManager.pushLayer(layer);
    return () => focusManager.popLayer(layer);
  }, [layer]);

  useBack(() => {
    onClose();
    return true;
  });

  const kind = TABS[tab].kind;
  const rows = useMemo(
    () =>
      [...items]
        .filter((x) => x.kind === kind)
        .sort((a, b) => b.updatedAt - a.updatedAt),
    [items, kind]
  );

  const open = (item: ResumeItem) => {
    const client = useSession.getState().client;
    // M3U items carry a direct URL; Xtream rebuilds it from the client.
    if (!client && !item.url) return;
    if (item.kind === "live") {
      // Mirror LiveTvScreen.doPlay: honour the user's stream-format preference
      // (defaults to raw .ts, which the web player decodes via mpegts.js) and
      // keep the alternate container as a fallback for codecs MSE can't handle.
      const ext = useSettings.getState().streamFormat === "ts" ? "ts" : "m3u8";
      navigate(Routes.player, {
        state: item.url
          ? { url: item.url, title: item.name, kind: "live" }
          : {
              url: ext === "ts" ? client!.liveTsUrl(item.id) : client!.liveUrl(item.id, "m3u8"),
              fallbackUrl: ext === "ts" ? client!.liveUrl(item.id, "m3u8") : client!.liveTsUrl(item.id),
              title: item.name,
              kind: "live",
            },
      });
      return;
    }
    const ext = item.containerExtension || "mp4";
    const url =
      item.url ||
      (item.kind === "movie"
        ? client!.movieUrl(item.id, ext)
        : client!.seriesUrl(item.id, ext));
    navigate(Routes.player, {
      state: {
        url,
        title: item.name,
        kind: "vod",
        osTitle: item.name,
        startPositionSec: item.positionSec > 10 ? item.positionSec : undefined,
        resumeMeta: {
          kind: item.kind,
          id: item.id,
          seriesId: item.seriesId,
          name: item.name,
          icon: item.icon,
          containerExtension: ext,
          url: item.url,
        },
      },
    });
  };

  return (
    <div onClick={backdropClose(onClose)} style={{ position: "fixed", inset: 0, zIndex: 1500, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div
        style={{
          position: "relative",
          width: 760,
          maxHeight: 620,
          padding: 20,
          borderRadius: 18,
          background: "linear-gradient(135deg, #16203f, #121430)",
          border: "1px solid rgba(255,255,255,0.16)",
          boxShadow: "0 20px 60px rgba(0,0,0,0.6)",
          display: "flex",
          flexDirection: "column",
          gap: 14,
        }}
      >
        <CloseButton onClose={onClose} />
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Icon name="play_circle_outline" size={22} color={colors.btn} />
          <span style={{ fontSize: 18, fontWeight: 800 }}>{t("continueWatchingHeader")}</span>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 10 }}>
          {TABS.map((tb, i) => (
            <TabButton
              key={tb.kind}
              layer={layer}
              icon={tb.icon}
              label={t(tb.labelKey)}
              active={i === tab}
              autoFocus={i === 0}
              onTap={() => setTab(i)}
            />
          ))}
        </div>

        {/* List */}
        <div className="scrollable" style={{ flex: 1, display: "flex", flexDirection: "column", gap: 8, overflow: "auto", minHeight: 0 }}>
          {rows.length === 0 ? (
            <div style={{ padding: 40, textAlign: "center", color: "rgba(255,255,255,0.45)", fontSize: 14 }}>
              {t("noContinueData")}
            </div>
          ) : (
            rows.map((item) => (
              <ContinueRow
                key={`${item.kind}-${item.id}`}
                layer={layer}
                item={item}
                openLabel={t("open")}
                removeLabel={t("remove")}
                onOpen={() => open(item)}
                onRemove={() => remove(item.kind, item.id)}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function TabButton({
  layer,
  icon,
  label,
  active,
  autoFocus,
  onTap,
}: {
  layer: string;
  icon: string;
  label: string;
  active: boolean;
  autoFocus?: boolean;
  onTap: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap, onFocus: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        flex: 1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 8,
        padding: "10px 12px",
        borderRadius: 10,
        cursor: "pointer",
        fontSize: 14,
        fontWeight: 700,
        background: focused ? "#fff" : active ? "rgba(54,96,245,0.45)" : "rgba(255,255,255,0.06)",
        color: focused ? colors.primary : "#fff",
        border: active ? "2px solid rgba(255,255,255,0.6)" : "2px solid transparent",
      }}
    >
      <Icon name={icon} size={18} color={focused ? colors.primary : "#fff"} />
      <span>{label}</span>
    </div>
  );
}

function ContinueRow({
  layer,
  item,
  openLabel,
  removeLabel,
  onOpen,
  onRemove,
}: {
  layer: string;
  item: ResumeItem;
  openLabel: string;
  removeLabel: string;
  onOpen: () => void;
  onRemove: () => void;
}) {
  const row = useFocusable<HTMLDivElement>({ layer, onEnter: onOpen });
  const del = useFocusable<HTMLDivElement>({ layer, onEnter: onRemove });
  const ratio =
    item.kind !== "live" && item.durationSec > 0 && item.positionSec > 10
      ? Math.min(1, item.positionSec / item.durationSec)
      : 0;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
      <div
        ref={row.ref}
        onClick={onOpen}
        className="focusable"
        title={openLabel}
        style={{
          flex: 1,
          display: "flex",
          alignItems: "center",
          gap: 12,
          padding: 10,
          borderRadius: 12,
          cursor: "pointer",
          minWidth: 0,
          background: row.focused ? "rgba(54,96,245,0.35)" : "rgba(255,255,255,0.04)",
          border: row.focused ? "2px solid #fff" : "2px solid transparent",
        }}
      >
        <div style={{ width: 92, height: 54, borderRadius: 8, overflow: "hidden", background: "rgba(0,0,0,0.35)", flex: "0 0 auto", display: "flex", alignItems: "center", justifyContent: "center" }}>
          {item.icon ? (
            <img src={item.icon} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />
          ) : (
            <Icon name={item.kind === "live" ? "live_tv" : "movie"} size={24} color="rgba(255,255,255,0.4)" />
          )}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {item.name}
          </div>
          {ratio > 0 && (
            <div style={{ marginTop: 6, display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ flex: 1, maxWidth: 360, height: 4, borderRadius: 2, background: "rgba(255,255,255,0.18)", overflow: "hidden" }}>
                <div style={{ width: `${Math.max(3, ratio * 100)}%`, height: "100%", background: "#E53935" }} />
              </div>
              <span style={{ fontSize: 11, color: "rgba(255,255,255,0.6)" }}>
                {formatDuration(item.positionSec)} / {formatDuration(item.durationSec)}
              </span>
            </div>
          )}
        </div>
      </div>
      <div
        ref={del.ref}
        onClick={onRemove}
        className="focusable"
        title={removeLabel}
        style={{
          width: 42,
          height: 42,
          borderRadius: "50%",
          flex: "0 0 auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          background: del.focused ? "#E53935" : "rgba(229,57,53,0.2)",
          border: del.focused ? "2px solid #fff" : "1px solid rgba(229,57,53,0.5)",
        }}
      >
        <Icon name="delete" size={20} color="#fff" />
      </div>
    </div>
  );
}
