import React from "react";
import { useFocusable } from "../../navigation/useFocusable";
import { Icon } from "../../components/Icon";
import { gradient } from "../../styles/theme";

// Circular focus-aware icon button used in the header bar.
export function IconCircle({
  icon,
  fg,
  onTap,
  focusKey,
  badge,
}: {
  icon: string;
  fg: string;
  onTap: () => void;
  focusKey?: string;
  // Small corner label (e.g. "PRO") overlaid on the button.
  badge?: string;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey,
    onEnter: onTap,
  });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        width: 42,
        height: 42,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: focused ? hexA(fg, 0.3) : "rgba(255,255,255,0.20)",
        border: focused
          ? "2.5px solid #fff"
          : "1px solid rgba(255,255,255,0.15)",
        boxShadow: focused
          ? `0 0 14px 2px ${hexA(fg, 0.5)}`
          : "0 2px 8px rgba(0,0,0,0.25)",
        cursor: "pointer",
        flex: "0 0 auto",
        position: "relative",
      }}
    >
      <Icon name={icon} size={20} color={focused ? "#fff" : fg} />
      {badge && (
        <span
          style={{
            position: "absolute",
            top: -6,
            right: -8,
            padding: "1px 5px",
            borderRadius: 999,
            background: "#FFD700",
            color: "#3A1010",
            fontSize: 9,
            fontWeight: 900,
            letterSpacing: 0.5,
            lineHeight: 1.4,
            boxShadow: "0 1px 4px rgba(0,0,0,0.4)",
          }}
        >
          {badge}
        </span>
      )}
    </div>
  );
}

// Large gradient dashboard tile (Live TV, Movies, etc.).
export function Tile({
  gradientColors,
  icon,
  imagePath,
  label,
  onTap,
  autoFocus,
  focusKey,
}: {
  gradientColors: string[];
  icon?: string;
  imagePath?: string;
  label: string;
  onTap: () => void;
  autoFocus?: boolean;
  focusKey?: string;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({
    focusKey,
    onEnter: onTap,
    autoFocus,
  });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        flex: 1,
        height: "100%",
        borderRadius: 16,
        background: gradient(gradientColors),
        border: focused ? "3px solid #fff" : "1px solid rgba(255,255,255,0.08)",
        transform: focused ? "scale(1.04)" : "scale(1)",
        boxShadow: focused
          ? `0 0 18px 2px ${hexA(gradientColors[0], 0.5)}`
          : "0 8px 14px rgba(0,0,0,0.35)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        position: "relative",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          width: 64,
          height: 64,
          borderRadius: "50%",
          background: `rgba(255,255,255,${focused ? 0.2 : 0.12})`,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {imagePath ? (
          <img
            src={imagePath}
            alt=""
            style={{
              width: 36,
              height: 36,
              objectFit: "contain",
              filter: "brightness(0) invert(1)",
            }}
          />
        ) : (
          <Icon name={icon || "info_outline"} size={30} color="#fff" />
        )}
      </div>
      <div
        style={{
          marginTop: 10,
          color: "#fff",
          fontSize: 22,
          fontWeight: 700,
          letterSpacing: 0.5,
          textAlign: "center",
          padding: "0 10px",
        }}
      >
        {label}
      </div>
    </div>
  );
}

export function hexA(hex: string, alpha: number): string {
  const h = hex.replace("#", "");
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}
