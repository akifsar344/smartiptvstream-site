import { useEffect, useId, useState } from "react";
import { useT } from "../../i18n/I18nProvider";
import { focusManager } from "../../navigation/focusManager";
import { useFocusable } from "../../navigation/useFocusable";
import { useBack } from "../../navigation/useBack";
import { Icon } from "../../components/Icon";
import { colors } from "../../styles/theme";
import { launchAppStore } from "../../platform/device";
import { useAccess } from "../../store/access";
import { CloseButton, backdropClose } from "../../components/Overlay";

// In-app rating prompt shown right after the user goes Pro. 4–5 stars launches
// the LG Content Store (deep-linking to our app page isn't supported, so it
// opens the store home); 1–3 stars just thanks the user privately.
export function RateAppModal() {
  const t = useT();
  const layer = useId();
  const consumeRate = useAccess((s) => s.consumeRate);
  const markRated = useAccess((s) => s.markRated);
  const [hover, setHover] = useState(0);
  const [thanks, setThanks] = useState(false);

  useEffect(() => {
    focusManager.pushLayer(layer);
    return () => focusManager.popLayer(layer);
  }, [layer]);

  const close = () => consumeRate();
  useBack(() => {
    close();
    return true;
  });

  const submit = (rating: number) => {
    markRated();
    if (rating >= 4) {
      launchAppStore();
      close();
    } else {
      setThanks(true);
    }
  };

  return (
    <div
      onClick={backdropClose(close)}
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 1200,
        background: "rgba(0,0,0,0.7)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          position: "relative",
          width: 460,
          padding: 28,
          borderRadius: 18,
          background: "linear-gradient(135deg, #18203f, #141632)",
          border: "1px solid rgba(255,255,255,0.16)",
          boxShadow: "0 20px 60px rgba(0,0,0,0.6)",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 16,
        }}
      >
        <CloseButton onClose={close} />
        <Icon name="workspace_premium" size={44} color={colors.iconFg.premium} />
        {thanks ? (
          <>
            <div style={{ fontSize: 20, fontWeight: 800, textAlign: "center" }}>{t("paywallProUnlockedThanks")}</div>
            <Btn label={t("paywallProUnlockedCta")} layer={layer} autoFocus primary onTap={close} />
          </>
        ) : (
          <>
            <div style={{ fontSize: 20, fontWeight: 800, textAlign: "center" }}>{t("rateAppTitle")}</div>
            <div style={{ fontSize: 14, color: "rgba(255,255,255,0.7)", textAlign: "center" }}>{t("rateAppBody")}</div>
            <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
              {[1, 2, 3, 4, 5].map((n) => (
                <Star
                  key={n}
                  index={n}
                  active={n <= hover}
                  layer={layer}
                  autoFocus={n === 5}
                  onFocus={() => setHover(n)}
                  onTap={() => submit(n)}
                />
              ))}
            </div>
            <Btn label={t("rateAppLater")} layer={layer} onTap={close} />
          </>
        )}
      </div>
    </div>
  );
}

function Star({
  index,
  active,
  layer,
  autoFocus,
  onFocus,
  onTap,
}: {
  index: number;
  active: boolean;
  layer: string;
  autoFocus?: boolean;
  onFocus: () => void;
  onTap: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap, onFocus });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      aria-label={`rate-${index}`}
      style={{
        width: 52,
        height: 52,
        borderRadius: 12,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        background: focused ? "rgba(255,255,255,0.15)" : "transparent",
        border: focused ? "2.5px solid #fff" : "2px solid transparent",
        transform: focused ? "scale(1.08)" : "scale(1)",
      }}
    >
      <Icon name="star" size={36} color={active ? colors.iconFg.premium : "rgba(255,255,255,0.25)"} />
    </div>
  );
}

function Btn({
  label,
  layer,
  onTap,
  primary,
  autoFocus,
}: {
  label: string;
  layer: string;
  onTap: () => void;
  primary?: boolean;
  autoFocus?: boolean;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap });
  const base = primary ? colors.btn : "rgba(255,255,255,0.08)";
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        minWidth: 120,
        height: 44,
        padding: "0 20px",
        borderRadius: 10,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 14,
        fontWeight: 700,
        cursor: "pointer",
        marginTop: 4,
        background: focused ? "#fff" : base,
        color: focused ? colors.primary : "#fff",
        border: focused ? "2.5px solid #fff" : "1.5px solid rgba(255,255,255,0.18)",
      }}
    >
      {label}
    </div>
  );
}
