import { useEffect, useId, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { ScreenHeader } from "../../components/ScreenHeader";
import { Icon } from "../../components/Icon";
import { CloseButton, backdropClose } from "../../components/Overlay";
import { useFocusable } from "../../navigation/useFocusable";
import { focusManager } from "../../navigation/focusManager";
import { useBack } from "../../navigation/useBack";
import { useSession } from "../../store/session";
import { useCatalog } from "../../store/catalog";
import { createPlayer } from "../../platform/player/createPlayer";
import { IPlayerAdapter } from "../../platform/player/types";
import { Category, LiveStream } from "../../data/models";
import { colors, gradient } from "../../styles/theme";

// Six layouts ported 1:1 from the Android TV source (lib/widgets/*layout.dart).
// Each uses CSS grid areas c0..cN; `cells` is how many tiles are visible.
interface LayoutDef {
  id: number;
  cells: number;
  columns: string;
  rows: string;
  areas: string[];
}

const LAYOUTS: LayoutDef[] = [
  { id: 1, cells: 4, columns: "1fr 1fr", rows: "1fr 1fr", areas: ['"c0 c1"', '"c2 c3"'] },
  { id: 2, cells: 4, columns: "1fr 1fr 1fr", rows: "1fr 1fr", areas: ['"c0 c0 c0"', '"c1 c2 c3"'] },
  { id: 3, cells: 3, columns: "1fr 1fr", rows: "1fr 1fr", areas: ['"c0 c0"', '"c1 c2"'] },
  { id: 4, cells: 3, columns: "1fr 1fr", rows: "1fr 1fr", areas: ['"c0 c1"', '"c2 c2"'] },
  { id: 5, cells: 2, columns: "1fr 1fr", rows: "1fr", areas: ['"c0 c1"'] },
  { id: 6, cells: 2, columns: "1fr", rows: "1fr 1fr", areas: ['"c0"', '"c1"'] },
];

export function MultiScreen() {
  const t = useT();
  const navigate = useNavigate();
  const [layout, setLayout] = useState<LayoutDef | null>(null);

  useBack(() => {
    if (layout) {
      setLayout(null);
      return true;
    }
    navigate(Routes.home);
    return true;
  });

  if (!layout) {
    return (
      <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
        <ScreenHeader title={t("multiscreen")} onBack={() => navigate(Routes.home)} />
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 30 }}>
          <h2 style={{ fontSize: 22 }}>{t("chooseMultiScreenLayout")}</h2>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 160px)", gap: 22 }}>
            {LAYOUTS.map((l, i) => (
              <LayoutCard key={l.id} def={l} autoFocus={i === 0} onTap={() => setLayout(l)} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return <MultiGrid layout={layout} onExit={() => setLayout(null)} />;
}

function LayoutCard({ def, onTap, autoFocus }: { def: LayoutDef; onTap: () => void; autoFocus?: boolean }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap, autoFocus });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        height: 120,
        borderRadius: 16,
        padding: 14,
        cursor: "pointer",
        background: focused ? gradient(colors.tiles.multiscreen) : "rgba(255,255,255,0.06)",
        border: focused ? "3px solid #fff" : "1px solid rgba(255,255,255,0.12)",
        transform: focused ? "scale(1.05)" : "scale(1)",
      }}
    >
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "grid",
          gridTemplateColumns: def.columns,
          gridTemplateRows: def.rows,
          gridTemplateAreas: def.areas.join(" "),
          gap: 6,
        }}
      >
        {Array.from({ length: def.cells }).map((_, i) => (
          <div
            key={i}
            style={{
              gridArea: `c${i}`,
              borderRadius: 5,
              border: "2px solid rgba(255,255,255,0.85)",
              background: "rgba(255,255,255,0.06)",
            }}
          />
        ))}
      </div>
    </div>
  );
}

function MultiGrid({ layout, onExit }: { layout: LayoutDef; onExit: () => void }) {
  // Channel assigned to each cell (null = empty).
  const [assignments, setAssignments] = useState<(LiveStream | null)[]>(
    () => Array.from({ length: layout.cells }, () => null)
  );
  const [activeCell, setActiveCell] = useState(0);
  const [pickerFor, setPickerFor] = useState<number | null>(null);

  return (
    <div style={{ position: "fixed", inset: 0, background: "#000" }}>
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "grid",
          gridTemplateColumns: layout.columns,
          gridTemplateRows: layout.rows,
          gridTemplateAreas: layout.areas.join(" "),
          gap: 3,
          padding: 3,
          boxSizing: "border-box",
        }}
      >
        {Array.from({ length: layout.cells }).map((_, i) => (
          <MultiCell
            key={i}
            index={i}
            channel={assignments[i]}
            active={activeCell === i}
            autoFocus={i === 0}
            onFocus={() => setActiveCell(i)}
            onEnter={() => setPickerFor(i)}
          />
        ))}
      </div>

      {/* Cancel / exit (top-left), matching the source's Icons.cancel button. */}
      <ExitButton onTap={onExit} />

      {pickerFor !== null && (
        <ChannelPicker
          onClose={() => setPickerFor(null)}
          onPick={(ch) => {
            setAssignments((prev) => {
              const next = prev.slice();
              next[pickerFor] = ch;
              return next;
            });
            setActiveCell(pickerFor);
            setPickerFor(null);
          }}
        />
      )}
    </div>
  );
}

function ExitButton({ onTap }: { onTap: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        position: "absolute",
        top: 10,
        left: 10,
        width: 40,
        height: 40,
        borderRadius: "50%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        zIndex: 50,
        background: focused ? "#fff" : "rgba(0,0,0,0.5)",
        border: focused ? "2px solid #fff" : "1px solid rgba(255,255,255,0.3)",
      }}
    >
      <Icon name="close" size={22} color={focused ? colors.primary : "#fff"} />
    </div>
  );
}

function MultiCell({
  index,
  channel,
  active,
  autoFocus,
  onFocus,
  onEnter,
}: {
  index: number;
  channel: LiveStream | null;
  active: boolean;
  autoFocus?: boolean;
  onFocus: () => void;
  onEnter: () => void;
}) {
  const t = useT();
  const containerRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<IPlayerAdapter | null>(null);

  const { ref, focused } = useFocusable<HTMLDivElement>({ autoFocus, onEnter, onFocus });

  // webOS TVs expose a single hardware video plane that anchors to the FIRST
  // live <video> element. Keeping inactive cells' players alive (to freeze
  // their last frame) makes a newly focused cell's stream render on that same
  // plane — i.e. in the WRONG cell. To guarantee every channel opens in its
  // own cell, only the focused cell owns a live player; moving focus tears it
  // down (freeing the plane) so the next cell can claim it at its own position.
  const live = active && !!channel;
  useEffect(() => {
    if (!live || !channel || !containerRef.current) return;
    const client = useSession.getState().client;
    if (!client) return;
    const player = createPlayer();
    playerRef.current = player;
    player.attach(containerRef.current, {});
    player.setMuted?.(false);
    player.setVolume(1);
    player.load({
      url: client.liveUrl(channel.streamId, "m3u8"),
      fallbackUrl: client.liveTsUrl(channel.streamId),
      kind: "live",
      title: channel.name,
    });
    return () => {
      player.destroy();
      playerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [live, channel?.streamId]);

  return (
    <div
      ref={ref}
      onClick={onEnter}
      className="focusable"
      style={{
        gridArea: `c${index}`,
        position: "relative",
        background: "#0a0a0a",
        cursor: "pointer",
        overflow: "hidden",
        border: focused ? "2px solid #FFC107" : "2px solid transparent",
      }}
    >
      <div ref={containerRef} style={{ position: "absolute", inset: 0 }} />

      {/* Empty cell */}
      {!channel && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            color: "rgba(255,255,255,0.4)",
          }}
        >
          <Icon name="add" size={40} color="rgba(255,255,255,0.4)" />
          <span style={{ fontSize: 13, fontWeight: 600 }}>{t("addChannel")}</span>
        </div>
      )}

      {/* Assigned but not focused → channel logo + name (the single video plane
          is freed for the focused cell, so we can't keep a live picture here). */}
      {channel && !live && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 10,
            padding: 12,
          }}
        >
          {channel.streamIcon ? (
            <img
              src={channel.streamIcon}
              alt=""
              style={{ maxWidth: "60%", maxHeight: "55%", objectFit: "contain", opacity: 0.85 }}
              onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
            />
          ) : (
            <Icon name="live_tv" size={44} color="rgba(255,255,255,0.4)" />
          )}
          <span style={{ fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.7)", textAlign: "center", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: "90%" }}>
            {channel.name}
          </span>
          <div style={{ width: 42, height: 42, borderRadius: "50%", background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center", marginTop: 2 }}>
            <Icon name="play_arrow" size={24} color="#fff" />
          </div>
        </div>
      )}

      {/* Focused + playing → name + audio badge. */}
      {live && (
        <div
          style={{
            position: "absolute",
            left: 0,
            right: 0,
            bottom: 0,
            padding: "14px 10px 6px",
            background: "linear-gradient(transparent, rgba(0,0,0,0.7))",
            display: "flex",
            alignItems: "center",
            gap: 6,
          }}
        >
          <Icon name="volume_up" size={14} color="#00E5A8" />
          <span style={{ fontSize: 12, fontWeight: 700, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {channel.name}
          </span>
        </div>
      )}
    </div>
  );
}

const ALL = "ALL";

// Two-step picker overlay (categories → channels), 1:1 with the source's
// multiLiveTVSelectionAlert + multiLiveTVStreamSelectionAlert dialogs.
function ChannelPicker({ onClose, onPick }: { onClose: () => void; onPick: (ch: LiveStream) => void }) {
  const t = useT();
  const layer = useId();
  const categories = useCatalog((s) => s.liveCategories);
  const streams = useCatalog((s) => s.liveStreams);
  const [view, setView] = useState<"cats" | "channels">("cats");
  const [cat, setCat] = useState<string>(ALL);

  useEffect(() => {
    focusManager.pushLayer(layer);
    return () => focusManager.popLayer(layer);
  }, [layer]);

  useBack(() => {
    if (view === "channels") {
      setView("cats");
      return true;
    }
    onClose();
    return true;
  });

  const cats = useMemo(() => {
    const counts = new Map<string, number>();
    for (const s of streams) counts.set(s.categoryId, (counts.get(s.categoryId) || 0) + 1);
    const list: { id: string; name: string; count: number }[] = [
      { id: ALL, name: ALL, count: streams.length },
    ];
    for (const c of categories) {
      list.push({ id: c.categoryId, name: c.categoryName, count: counts.get(c.categoryId) || 0 });
    }
    return list;
  }, [categories, streams]);

  const channels = useMemo(() => {
    const base = cat === ALL ? streams : streams.filter((s) => s.categoryId === cat);
    return base.slice(0, 400);
  }, [cat, streams]);

  return (
    <div onClick={backdropClose(onClose)} style={{ position: "absolute", inset: 0, zIndex: 1000, background: "rgba(0,0,0,0.6)", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div
        style={{
          position: "relative",
          width: 720,
          maxHeight: 600,
          padding: 18,
          borderRadius: 16,
          background: "linear-gradient(135deg, #16203f, #121430)",
          border: "1px solid rgba(255,255,255,0.16)",
          boxShadow: "0 20px 60px rgba(0,0,0,0.6)",
          display: "flex",
          flexDirection: "column",
          gap: 12,
        }}
      >
        <CloseButton onClose={onClose} />
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <Icon name={view === "cats" ? "live_tv" : "subtitles"} size={20} color={colors.btn} />
          <span style={{ fontSize: 17, fontWeight: 800 }}>
            {view === "cats" ? t("liveCategories") : (cats.find((c) => c.id === cat)?.name ?? t("channels"))}
          </span>
        </div>

        <div
          className="scrollable"
          style={{ flex: 1, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, overflow: "auto", minHeight: 0, alignContent: "start" }}
        >
          {view === "cats"
            ? cats.map((c, i) => (
                <PickerRow
                  key={c.id}
                  layer={layer}
                  autoFocus={i === 0}
                  label={c.name}
                  trailing={String(c.count)}
                  onTap={() => {
                    setCat(c.id);
                    setView("channels");
                  }}
                />
              ))
            : channels.map((ch, i) => (
                <PickerRow
                  key={ch.streamId}
                  layer={layer}
                  autoFocus={i === 0}
                  label={ch.name}
                  icon={ch.streamIcon}
                  onTap={() => onPick(ch)}
                />
              ))}
        </div>
      </div>
    </div>
  );
}

function PickerRow({
  layer,
  label,
  trailing,
  icon,
  autoFocus,
  onTap,
}: {
  layer: string;
  label: string;
  trailing?: string;
  icon?: string;
  autoFocus?: boolean;
  onTap: () => void;
}) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ layer, autoFocus, onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 10,
        padding: "10px 12px",
        borderRadius: 10,
        cursor: "pointer",
        minWidth: 0,
        background: focused ? "#3D58BA" : "rgba(255,255,255,0.05)",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      {icon !== undefined &&
        (icon ? (
          <img
            src={icon}
            alt=""
            loading="lazy"
            style={{ width: 30, height: 30, objectFit: "contain", flex: "0 0 auto" }}
            onError={(e) => ((e.target as HTMLImageElement).style.display = "none")}
          />
        ) : (
          <Icon name="live_tv" size={18} color="rgba(255,255,255,0.4)" />
        ))}
      <span style={{ flex: 1, fontSize: 13, fontWeight: focused ? 700 : 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
        {label}
      </span>
      {trailing != null && <span style={{ fontSize: 11, color: "rgba(255,255,255,0.5)" }}>{trailing}</span>}
    </div>
  );
}
