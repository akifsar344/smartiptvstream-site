import { useNavigate } from "react-router-dom";
import { useT } from "../../i18n/I18nProvider";
import { Routes } from "../../routes";
import { ScreenHeader } from "../../components/ScreenHeader";
import { useBack } from "../../navigation/useBack";
import { asset } from "../../platform/asset";

export function AboutScreen() {
  const t = useT();
  const navigate = useNavigate();
  useBack(() => {
    navigate(Routes.home);
    return true;
  });
  const rows: [string, string][] = [
    [t("version"), "1.0.0"],
    [t("developedBy"), "Discover App"],
    [t("copyright"), `© ${new Date().getFullYear()} Discover App`],
  ];
  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
      <ScreenHeader title={t("aboutApp")} onBack={() => navigate(Routes.home)} />
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 20 }}>
        <img src={asset("assets/Logo_inn.png")} alt="logo" style={{ width: 120, height: 120, objectFit: "contain" }} />
        <h1 style={{ fontSize: 28, fontWeight: 800 }}>Smart IPTV Stream</h1>
        <div style={{ width: 420 }}>
          {rows.map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "12px 0", borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
              <span style={{ color: "rgba(255,255,255,0.6)" }}>{k}</span>
              <span style={{ fontWeight: 700 }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
