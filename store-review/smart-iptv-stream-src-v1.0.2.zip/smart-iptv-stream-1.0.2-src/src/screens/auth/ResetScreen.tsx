import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { colors } from "../../styles/theme";
import { Routes } from "../../routes";
import { FocusInput } from "../../components/FocusInput";
import { Button } from "../../components/Button";
import { backend, ApiError } from "../../data/api/backend";
import { useAuth } from "../../store/auth";
import { asset } from "../../platform/asset";

export function ResetScreen() {
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const token = params.get("token") || "";
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError("");
    if (!token) return setError("This reset link is invalid or has expired.");
    if (password.length < 6) return setError("Password must be at least 6 characters.");
    setBusy(true);
    try {
      const { token: sessionToken, access } = await backend.reset(token, password);
      // Log the user straight in with the new password.
      localStorage.setItem("auth.token", sessionToken);
      useAuth.setState({ status: "authed", token: sessionToken, email: access.email, access });
      const { hydrateFromCloud, startCloudSync } = await import("../../store/cloudSync");
      await hydrateFromCloud(sessionToken);
      startCloudSync(sessionToken);
      navigate(Routes.splash, { replace: true });
    } catch (e) {
      setBusy(false);
      setError(e instanceof ApiError ? "This reset link is invalid or has expired." : "Connection problem. Try again.");
    }
  };

  return (
    <div className="authbg">
      <img src={asset("assets/Logo_inn.png")} alt="logo" style={{ width: 84, height: 84, objectFit: "contain" }} />
      <h1 style={{ marginTop: 10, fontSize: 24, fontWeight: 800 }}>Set a new password</h1>
      <div
        className="auth-card"
        style={{
          marginTop: 22,
          padding: 24,
          borderRadius: 18,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.12)",
          display: "flex",
          flexDirection: "column",
          gap: 16,
        }}
      >
        <span style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", fontWeight: 600 }}>New password</span>
        <FocusInput value={password} onChange={setPassword} placeholder="At least 6 characters" type="password" focusKey="reset-pass" fieldNav onSubmit={submit} />
        {error && <div style={{ color: "#FF7043", fontSize: 14, fontWeight: 600 }}>{error}</div>}
        <Button label={busy ? "Please wait..." : "Save new password"} onTap={submit} focusKey="reset-submit" width="100%" />
        <div
          className="focusable"
          onClick={() => navigate(Routes.authLogin, { replace: true })}
          style={{ cursor: "pointer", fontSize: 13, fontWeight: 600, color: colors.accentRing, textDecoration: "underline" }}
        >
          Back to sign in
        </div>
      </div>
    </div>
  );
}
