import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { colors, gradient } from "../../styles/theme";
import { Routes } from "../../routes";
import { FocusInput } from "../../components/FocusInput";
import { Button } from "../../components/Button";
import { useFocusable } from "../../navigation/useFocusable";
import { useAuth } from "../../store/auth";
import { ApiError } from "../../data/api/backend";
import { asset } from "../../platform/asset";

type Mode = "signin" | "signup" | "forgot";

const ERRORS: Record<string, string> = {
  invalid_email: "Please enter a valid email address.",
  weak_password: "Password must be at least 6 characters.",
  email_taken: "An account with this email already exists.",
  invalid_credentials: "Wrong email or password.",
  network: "Connection problem. Please try again.",
};

function msgFor(e: unknown): string {
  if (e instanceof ApiError) return ERRORS[e.code] || "Something went wrong. Please try again.";
  return ERRORS.network;
}

export function AuthScreen() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setError("");
    setInfo("");
    const mail = email.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(mail)) return setError(ERRORS.invalid_email);

    setBusy(true);
    try {
      if (mode === "forgot") {
        const { backend } = await import("../../data/api/backend");
        await backend.forgot(mail);
        setInfo("If that email is registered, a reset link has been sent.");
        setBusy(false);
        return;
      }
      if (password.length < 6) {
        setBusy(false);
        return setError(ERRORS.weak_password);
      }
      if (mode === "signup") await useAuth.getState().signup(mail, password);
      else await useAuth.getState().login(mail, password);
      // Auth state flips to "authed"; the AuthGate + splash take over routing.
      navigate(Routes.splash, { replace: true });
    } catch (e) {
      setBusy(false);
      setError(msgFor(e));
    }
  };

  const title =
    mode === "signup" ? "Create your account" : mode === "forgot" ? "Reset your password" : "Sign in";

  return (
    <div className="authbg">
      <img src={asset("assets/Logo_inn.png")} alt="logo" style={{ width: 84, height: 84, objectFit: "contain" }} />
      <h1 style={{ marginTop: 10, fontSize: 24, fontWeight: 800 }}>Smart IPTV Stream</h1>

      {mode !== "forgot" && (
        <div style={{ display: "flex", gap: 12, marginTop: 22 }}>
          <Tab active={mode === "signin"} label="Sign In" onTap={() => { setMode("signin"); setError(""); }} />
          <Tab active={mode === "signup"} label="Sign Up" onTap={() => { setMode("signup"); setError(""); }} />
        </div>
      )}

      <div
        className="auth-card"
        style={{
          marginTop: 22,
          padding: 24,
          borderRadius: 18,
          background: "rgba(255,255,255,0.04)",
          border: "1px solid rgba(255,255,255,0.12)",
          display: "flex",
          flexDirection: "column",
          gap: 16,
        }}
      >
        <div style={{ fontSize: 18, fontWeight: 700 }}>{title}</div>

        <Field label="Email">
          <FocusInput value={email} onChange={setEmail} placeholder="you@example.com" focusKey="auth-email" fieldNav />
        </Field>

        {mode !== "forgot" && (
          <Field label="Password">
            <FocusInput
              value={password}
              onChange={setPassword}
              placeholder="At least 6 characters"
              type="password"
              focusKey="auth-pass"
              fieldNav
              scrollOnFocus
              onSubmit={submit}
            />
          </Field>
        )}

        {error && <div style={{ color: "#FF7043", fontSize: 14, fontWeight: 600 }}>{error}</div>}
        {info && <div style={{ color: colors.accentRing, fontSize: 14, fontWeight: 600 }}>{info}</div>}

        <Button
          label={busy ? "Please wait..." : mode === "signup" ? "Create account" : mode === "forgot" ? "Send reset link" : "Sign in"}
          onTap={submit}
          focusKey="auth-submit"
          width="100%"
        />

        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 2 }}>
          {mode !== "forgot" ? (
            <LinkText label="Forgot password?" onTap={() => { setMode("forgot"); setError(""); setInfo(""); }} focusKey="auth-forgot" />
          ) : (
            <LinkText label="Back to sign in" onTap={() => { setMode("signin"); setError(""); setInfo(""); }} focusKey="auth-back" />
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <span style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", fontWeight: 600 }}>{label}</span>
      {children}
    </div>
  );
}

function Tab({ active, label, onTap }: { active: boolean; label: string; onTap: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        padding: "10px 26px",
        borderRadius: 10,
        fontSize: 14,
        fontWeight: 700,
        cursor: "pointer",
        color: focused ? colors.primary : "#fff",
        background: focused ? "#fff" : active ? gradient(colors.tiles.live) : "rgba(255,255,255,0.06)",
        border: active ? "2px solid rgba(255,255,255,0.5)" : "1.5px solid rgba(255,255,255,0.15)",
      }}
    >
      {label}
    </div>
  );
}

function LinkText({ label, onTap, focusKey }: { label: string; onTap: () => void; focusKey: string }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ focusKey, onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        cursor: "pointer",
        fontSize: 13,
        fontWeight: 600,
        color: focused ? "#fff" : "rgba(128,222,234,0.9)",
        textDecoration: "underline",
      }}
    >
      {label}
    </div>
  );
}
