import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useI18n, useT } from "../../i18n/I18nProvider";
import { LANGUAGES } from "../../i18n";
import { Routes } from "../../routes";
import { ScreenHeader } from "../../components/ScreenHeader";
import { useFocusable } from "../../navigation/useFocusable";
import { useSettings, StreamFormat } from "../../store/settings";
import { useOpenSubtitles } from "../../store/opensubtitles";
import { useUserData } from "../../store/userdata";
import { useBack } from "../../navigation/useBack";
import { colors, gradient } from "../../styles/theme";
import { Icon } from "../../components/Icon";
import { FocusInput } from "../../components/FocusInput";
import { PinDialog } from "../../components/Overlay";

type Section = "language" | "stream" | "epg" | "clock" | "parental" | "opensubtitles";

export function SettingsScreen() {
  const t = useT();
  const navigate = useNavigate();
  const [section, setSection] = useState<Section>("language");

  useBack(() => {
    navigate(Routes.home);
    return true;
  });

  const menu: { id: Section; label: string; icon: string }[] = [
    { id: "language", label: t("languages"), icon: "language" },
    { id: "stream", label: t("streamFormat"), icon: "tv" },
    { id: "epg", label: t("epgTimeline"), icon: "schedule" },
    { id: "clock", label: t("timeFormat"), icon: "access_time" },
    { id: "parental", label: t("parentalcontrol"), icon: "lock" },
    { id: "opensubtitles", label: t("openSubtitles"), icon: "subtitles" },
  ];

  return (
    <div className="fullbg" style={{ display: "flex", flexDirection: "column" }}>
      <ScreenHeader title={t("settings")} onBack={() => navigate(Routes.home)} />
      <div style={{ flex: 1, display: "flex", minHeight: 0 }}>
        <div style={{ width: 280, padding: 16, background: "rgba(0,0,0,0.25)", borderRight: "1px solid rgba(255,255,255,0.08)" }}>
          {menu.map((m, i) => (
            <MenuItem key={m.id} label={m.label} icon={m.icon} active={section === m.id} onTap={() => setSection(m.id)} autoFocus={i === 0} />
          ))}
        </div>
        <div className="scrollable" style={{ flex: 1, padding: 28 }}>
          {section === "language" && <LanguagePanel />}
          {section === "stream" && <StreamPanel />}
          {section === "epg" && <EpgPanel />}
          {section === "clock" && <ClockPanel />}
          {section === "parental" && <ParentalPanel />}
          {section === "opensubtitles" && <OpenSubtitlesPanel />}
        </div>
      </div>
    </div>
  );
}

function MenuItem({ label, icon, active, onTap, autoFocus }: { label: string; icon: string; active: boolean; onTap: () => void; autoFocus?: boolean }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap, onFocus: onTap, autoFocus });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "14px 16px",
        marginBottom: 6,
        borderRadius: 10,
        cursor: "pointer",
        background: focused ? gradient(colors.tiles.live) : active ? "rgba(255,255,255,0.1)" : "transparent",
        border: focused ? "2px solid #fff" : "2px solid transparent",
      }}
    >
      <Icon name={icon} size={20} color="#fff" />
      <span style={{ fontSize: 15, fontWeight: active || focused ? 700 : 500 }}>{label}</span>
    </div>
  );
}

function LanguagePanel() {
  const { lang, setLang } = useI18n();
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
      {LANGUAGES.map((l) => (
        <LangCard key={l.code} name={l.name} active={lang === l.code} onTap={() => setLang(l.code)} />
      ))}
    </div>
  );
}

function LangCard({ name, active, onTap }: { name: string; active: boolean; onTap: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        padding: "16px 14px",
        borderRadius: 10,
        cursor: "pointer",
        textAlign: "center",
        fontSize: 14,
        fontWeight: active || focused ? 700 : 500,
        background: focused ? "#fff" : active ? gradient(colors.tiles.live) : "rgba(255,255,255,0.05)",
        color: focused ? colors.primary : "#fff",
        border: active ? "2px solid rgba(255,255,255,0.5)" : "1px solid rgba(255,255,255,0.12)",
      }}
    >
      {name}
    </div>
  );
}

function StreamPanel() {
  const t = useT();
  const fmt = useSettings((s) => s.streamFormat);
  const setFmt = useSettings((s) => s.setStreamFormat);
  const opts: { id: StreamFormat; label: string }[] = [
    { id: "default", label: t("defualt") },
    { id: "m3u8", label: "HLS (m3u8)" },
    { id: "ts", label: "MPEG-TS (ts)" },
  ];
  return (
    <div>
      <h2 style={{ fontSize: 20, marginBottom: 18 }}>{t("streamFormat")}</h2>
      <div style={{ display: "flex", gap: 12 }}>
        {opts.map((o) => (
          <Toggle key={o.id} label={o.label} active={fmt === o.id} onTap={() => setFmt(o.id)} />
        ))}
      </div>
    </div>
  );
}

function EpgPanel() {
  const t = useT();
  const showOnly = useSettings((s) => s.showOnlyEpgChannels);
  const setShowOnly = useSettings((s) => s.setShowOnlyEpg);
  return (
    <div>
      <h2 style={{ fontSize: 20, marginBottom: 18 }}>{t("epgTimeline")}</h2>
      <div style={{ display: "flex", gap: 12 }}>
        <Toggle label={t("showAllChannels")} active={!showOnly} onTap={() => setShowOnly(false)} />
        <Toggle label={t("showChannelsOnlyWithEPG")} active={showOnly} onTap={() => setShowOnly(true)} />
      </div>
    </div>
  );
}

function ClockPanel() {
  const t = useT();
  const hour24 = useSettings((s) => s.hour24);
  const setHour24 = useSettings((s) => s.setHour24);
  return (
    <div>
      <h2 style={{ fontSize: 20, marginBottom: 18 }}>{t("timeFormat")}</h2>
      <div style={{ display: "flex", gap: 12 }}>
        <Toggle label={t("h12")} active={!hour24} onTap={() => setHour24(false)} />
        <Toggle label={t("h24")} active={hour24} onTap={() => setHour24(true)} />
      </div>
    </div>
  );
}

function ParentalPanel() {
  const t = useT();
  const pin = useUserData((s) => s.pin);
  const setPin = useUserData((s) => s.setPin);
  const removeParental = useUserData((s) => s.removeParental);
  const [modal, setModal] = useState<React.ReactNode>(null);
  const [msg, setMsg] = useState("");

  const openSet = () =>
    setModal(
      <PinDialog
        title={pin ? t("changePin") : t("setPin")}
        mode="set"
        onSuccess={(p) => {
          setPin(p);
          setMsg("");
        }}
        onClose={() => setModal(null)}
      />
    );

  const openRemove = () =>
    setModal(
      <PinDialog
        title={t("removePinAction")}
        mode="verify"
        expectedPin={pin}
        onSuccess={() => {
          removeParental();
          setMsg(t("pinRemoved"));
        }}
        onClose={() => setModal(null)}
      />
    );

  return (
    <div style={{ maxWidth: 520 }}>
      <h2 style={{ fontSize: 20, marginBottom: 14 }}>{t("parentalcontrol")}</h2>
      <p style={{ color: "rgba(255,255,255,0.6)", fontSize: 14, lineHeight: 1.5, marginBottom: 20 }}>
        {pin ? t("pinActiveInfo") : t("noPinSet")}
      </p>
      <div style={{ display: "flex", gap: 12 }}>
        <Toggle label={pin ? t("changePin") : t("setPin")} active={false} onTap={openSet} />
        {pin && <Toggle label={t("removePinAction")} active={false} onTap={openRemove} />}
      </div>
      {msg && (
        <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 8, color: "#00E5A8", fontSize: 14, fontWeight: 600 }}>
          <Icon name="check_circle" size={18} color="#00E5A8" />
          {msg}
        </div>
      )}
      {modal}
    </div>
  );
}

function OpenSubtitlesPanel() {
  const t = useT();
  const { loggedIn, username, vip, allowedDownloads, loading, error, login, logout } =
    useOpenSubtitles();
  const [user, setUser] = useState(username);
  const [pass, setPass] = useState("");

  if (loggedIn) {
    return (
      <div style={{ maxWidth: 460 }}>
        <h2 style={{ fontSize: 20, marginBottom: 18 }}>{t("openSubtitles")}</h2>
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 10 }}>
          <Icon name="check_circle" size={22} color="#00E5A8" />
          <span style={{ fontSize: 15 }}>
            {t("osLoggedIn")} — <b>{username}</b>
          </span>
          {vip && (
            <span style={{ padding: "2px 8px", borderRadius: 6, background: "#C9A227", color: "#1a1a1a", fontSize: 12, fontWeight: 800 }}>
              VIP
            </span>
          )}
        </div>
        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", marginBottom: 20 }}>
          {allowedDownloads}/day
        </div>
        <Toggle label={t("logout")} active={false} onTap={() => logout()} />
      </div>
    );
  }

  return (
    <div style={{ maxWidth: 460, display: "flex", flexDirection: "column", gap: 14 }}>
      <h2 style={{ fontSize: 20, marginBottom: 4 }}>{t("osLoginTitle")}</h2>
      <FocusInput value={user} onChange={setUser} placeholder={t("userName")} fieldNav />
      <FocusInput value={pass} onChange={setPass} placeholder={t("password")} type="password" fieldNav />
      {error && <div style={{ color: "#FF7043", fontSize: 13 }}>{error}</div>}
      <Toggle
        label={loading ? t("loading") : t("signIn")}
        active
        onTap={() => {
          if (loading) return;
          void login(user, pass);
        }}
      />

      <div
        style={{
          marginTop: 10,
          padding: "14px 16px",
          borderRadius: 12,
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.12)",
          display: "flex",
          flexDirection: "column",
          gap: 10,
        }}
      >
        <div style={{ display: "flex", gap: 10 }}>
          <Icon name="subtitles" size={20} color={colors.btn} />
          <span style={{ fontSize: 13, lineHeight: 1.5, color: "rgba(255,255,255,0.8)" }}>
            {t("osSignupHint")}
          </span>
        </div>
        <span style={{ fontSize: 14, fontWeight: 700, color: "#00E5A8", fontFamily: "monospace", wordBreak: "break-all" }}>
          {OS_SIGNUP_URL}
        </span>
      </div>
    </div>
  );
}

const OS_SIGNUP_URL = "https://www.opensubtitles.com/en/users/sign_up";

function Toggle({ label, active, onTap }: { label: string; active: boolean; onTap: () => void }) {
  const { ref, focused } = useFocusable<HTMLDivElement>({ onEnter: onTap });
  return (
    <div
      ref={ref}
      onClick={onTap}
      className="focusable"
      style={{
        padding: "12px 22px",
        borderRadius: 10,
        cursor: "pointer",
        fontSize: 14,
        fontWeight: 700,
        background: focused ? "#fff" : active ? gradient(colors.tiles.live) : "rgba(255,255,255,0.06)",
        color: focused ? colors.primary : "#fff",
        border: active ? "2px solid rgba(255,255,255,0.5)" : "1px solid rgba(255,255,255,0.15)",
      }}
    >
      {label}
    </div>
  );
}
