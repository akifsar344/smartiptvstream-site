// Design tokens ported 1:1 from the Android TV (Flutter) source so the webOS /
// Tizen build matches pixel-for-pixel. Base design resolution is 1280x720.

export const BASE_WIDTH = 1280;
export const BASE_HEIGHT = 720;

export const colors = {
  primary: "#001D47",
  btn: "#3660F5",
  bgGradient: ["#16213E", "#1A1A40", "#2A0845"],

  headerBg: "rgba(30,30,60,0.20)",
  headerBorder: "rgba(255,255,255,0.10)",

  dividerGradient: [
    "transparent",
    "rgba(138,43,226,0.80)",
    "rgba(75,0,130,0.80)",
    "rgba(138,43,226,0.80)",
    "transparent",
  ],

  bottomBarGradient: ["#1F2333", "#16192A"],

  tiles: {
    live: ["#0B2CFF", "#0016B3"],
    movies: ["#FF2B2B", "#B30000"],
    series: ["#23D12A", "#0B7A10"],
    multiscreen: ["#8E2DE2", "#4A00E0"],
    epg: ["#2B8BFF", "#0D4DB3"],
    catchup: ["#FFA726", "#F57C00"],
    continue: ["#C2185B", "#880E4F"],
  },

  iconFg: {
    premium: "#FFD700",
    account: "#80DEEA",
    download: "#64B5F6",
    tv: "#4FC3F7",
    refresh: "#FFB74D",
    settings: "#FFD54F",
    info: "#81C784",
    logout: "#FF7043",
    power: "#E53935",
  },

  statusDot: {
    live: "#1565C0",
    movies: "#D32F2F",
    series: "#43A047",
    total: "#FFB300",
    loggedIn: "#42A5F5",
    expiryOk: "#4CAF50",
    expiryWarn: "#FFB300",
    expirySoon: "#FF5722",
    expiryExpired: "#D32F2F",
  },

  accentRing: "#00E5A8",
  white: "#FFFFFF",
};

export function gradient(stops: string[], angle = "135deg"): string {
  return `linear-gradient(${angle}, ${stops.join(", ")})`;
}
