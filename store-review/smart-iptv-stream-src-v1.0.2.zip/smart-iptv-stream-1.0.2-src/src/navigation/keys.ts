// Remote-control / keyboard key mapping shared across webOS, Tizen and browser.
// webOS Magic Remote and Tizen remotes emit standard arrow/enter codes, but the
// "Back" and media keys differ per platform, so we normalise them here.

export type NavKey =
  | "up"
  | "down"
  | "left"
  | "right"
  | "enter"
  | "back"
  | "play"
  | "pause"
  | "playpause"
  | "stop"
  | "rewind"
  | "forward"
  | "channelUp"
  | "channelDown"
  | "red"
  | "green"
  | "yellow"
  | "blue"
  | "info"
  | "unknown";

export function resolveKey(e: KeyboardEvent): NavKey {
  switch (e.keyCode) {
    case 37:
      return "left";
    case 38:
      return "up";
    case 39:
      return "right";
    case 40:
      return "down";
    case 13:
      return "enter";
    // Back: webOS = 461, Tizen = 10009, browser Backspace = 8, Esc = 27,
    // Titan OS / Philips (Chromium) also emit BrowserBack = 166.
    case 461:
    case 10009:
    case 166:
    case 8:
    case 27:
      return "back";
    // Media keys (Tizen / webOS)
    case 415: // PLAY
      return "play";
    case 19: // PAUSE
      return "pause";
    case 10252: // PLAY/PAUSE (Tizen)
    case 463:
      return "playpause";
    case 413: // STOP
      return "stop";
    case 412: // REWIND
      return "rewind";
    case 417: // FAST FORWARD
      return "forward";
    case 427: // CHANNEL UP
      return "channelUp";
    case 428: // CHANNEL DOWN
      return "channelDown";
    case 403: // RED
      return "red";
    case 404: // GREEN
      return "green";
    case 405: // YELLOW
      return "yellow";
    case 406: // BLUE
      return "blue";
    case 457: // INFO
      return "info";
    default:
      break;
  }

  switch (e.key) {
    case "ArrowLeft":
      return "left";
    case "ArrowUp":
      return "up";
    case "ArrowRight":
      return "right";
    case "ArrowDown":
      return "down";
    case "Enter":
      return "enter";
    case "Backspace":
    case "Escape":
    case "GoBack":
    case "Back":
    case "BrowserBack":
    case "XF86Back":
      return "back";
    case "MediaPlay":
      return "play";
    case "MediaPause":
      return "pause";
    case "MediaPlayPause":
      return "playpause";
    case "MediaStop":
      return "stop";
    case "MediaRewind":
      return "rewind";
    case "MediaFastForward":
      return "forward";
    default:
      return "unknown";
  }
}
