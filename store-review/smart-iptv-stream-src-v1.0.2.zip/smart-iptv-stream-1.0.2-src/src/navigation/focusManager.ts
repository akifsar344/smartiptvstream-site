import { NavKey, resolveKey } from "./keys";

export type Direction = "up" | "down" | "left" | "right";

export interface FocusableConfig {
  id: string;
  element: HTMLElement;
  /** Larger groups are searched first when resolving overlaps. */
  onEnter?: () => void;
  onFocus?: () => void;
  onBlur?: () => void;
  /** Return true to consume an arrow press (custom handling). */
  onArrow?: (dir: Direction) => boolean;
  /** Disable participation in spatial search. */
  disabled?: boolean;
  /** Optional explicit neighbours by id. */
  neighbors?: Partial<Record<Direction, string>>;
  /** Focus priority used to break ties (higher wins). */
  priority?: number;
  /** Focus layer; only items on the active (top) layer are navigable. */
  layer?: string;
  /** For text inputs: treat on-screen keyboard arrows as field-to-field jumps
   *  (Right/Down → next field, Left/Up → previous field). */
  editArrowsAsFields?: boolean;
}

interface Rect {
  left: number;
  right: number;
  top: number;
  bottom: number;
  cx: number;
  cy: number;
}

type KeyListener = (key: NavKey, e: KeyboardEvent) => boolean | void;

class FocusManager {
  private items = new Map<string, FocusableConfig>();
  private currentId: string | null = null;
  private started = false;
  private keyListeners: KeyListener[] = [];
  private pendingFocusId: string | null = null;
  private lastMoveAt = 0;
  /** Min ms between navigation moves to avoid key-repeat backlog on TVs. */
  private static MOVE_THROTTLE_MS = 70;
  /** Stack of modal/overlay focus layers; "" is the base screen layer. */
  private layerStack: { name: string; prevFocusId: string | null }[] = [];

  /** True while a modal/overlay focus layer is active. */
  hasActiveLayer(): boolean {
    return this.layerStack.length > 0;
  }

  private currentLayer(): string {
    return this.layerStack.length
      ? this.layerStack[this.layerStack.length - 1].name
      : "";
  }

  /** Enter an isolated focus layer (e.g. a modal). */
  pushLayer(name: string) {
    this.layerStack.push({ name, prevFocusId: this.currentId });
    this.currentId = null;
    // Defer first focus until the layer's elements have registered.
    setTimeout(() => {
      if (this.currentLayer() === name && this.currentId === null) {
        this.focusFirst();
      }
    }, 0);
  }

  /** Leave the top focus layer and restore the previous focus. */
  popLayer(name?: string) {
    if (!this.layerStack.length) return;
    if (name && this.currentLayer() !== name) return;
    const top = this.layerStack.pop()!;
    this.currentId = null;
    const prev = top.prevFocusId;
    if (prev && this.items.has(prev)) this.focus(prev);
    else this.focusFirst();
  }

  start() {
    if (this.started) return;
    this.started = true;
    window.addEventListener("keydown", this.handleKeyDown, true);
  }

  stop() {
    this.started = false;
    window.removeEventListener("keydown", this.handleKeyDown, true);
  }

  /** Register a global key listener. Returns an unsubscribe fn. */
  addKeyListener(fn: KeyListener): () => void {
    this.keyListeners.unshift(fn);
    return () => {
      this.keyListeners = this.keyListeners.filter((l) => l !== fn);
    };
  }

  register(config: FocusableConfig) {
    this.items.set(config.id, config);
    if (this.pendingFocusId === config.id) {
      this.pendingFocusId = null;
      this.focus(config.id);
    } else if (this.currentId === null) {
      // Nothing focused yet; defer auto-focus to caller via focusFirst.
    }
  }

  unregister(id: string) {
    const item = this.items.get(id);
    if (item && this.currentId === id) {
      this.currentId = null;
    }
    this.items.delete(id);
  }

  update(id: string, patch: Partial<FocusableConfig>) {
    const item = this.items.get(id);
    if (item) this.items.set(id, { ...item, ...patch });
  }

  getCurrentId() {
    return this.currentId;
  }

  focus(id: string): boolean {
    const item = this.items.get(id);
    if (!item || item.disabled) {
      // Element may not be mounted yet; remember the request.
      this.pendingFocusId = id;
      return false;
    }
    if (this.currentId === id) return true;
    const prev = this.currentId ? this.items.get(this.currentId) : null;
    if (prev) {
      prev.element.classList.remove("focused");
      prev.onBlur?.();
    }
    this.currentId = id;
    item.element.classList.add("focused");
    item.onFocus?.();
    this.scrollIntoView(item.element);
    return true;
  }

  /** Focus the first available focusable (top-left-most). */
  focusFirst(): boolean {
    const all = this.visibleItems();
    if (!all.length) return false;
    all.sort((a, b) => {
      const ra = this.rectOf(a.element);
      const rb = this.rectOf(b.element);
      const pa = b.priority ?? 0;
      const pb = a.priority ?? 0;
      if (pa !== pb) return pa - pb;
      if (Math.abs(ra.top - rb.top) > 12) return ra.top - rb.top;
      return ra.left - rb.left;
    });
    return this.focus(all[0].id);
  }

  private scrollIntoView(el: HTMLElement) {
    try {
      // Instant scroll: smooth scrolling is very expensive on TV GPUs and
      // makes focus movement feel laggy when key repeats stack up.
      el.scrollIntoView({
        block: "nearest",
        inline: "nearest",
        behavior: "auto",
      });
    } catch {
      el.scrollIntoView();
    }
  }

  private visibleItems(): FocusableConfig[] {
    const layer = this.currentLayer();
    const out: FocusableConfig[] = [];
    this.items.forEach((it) => {
      if (it.disabled) return;
      if ((it.layer || "") !== layer) return;
      const el = it.element;
      if (!el.isConnected) return;
      const r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return;
      out.push(it);
    });
    return out;
  }

  private rectOf(el: HTMLElement): Rect {
    const r = el.getBoundingClientRect();
    return {
      left: r.left,
      right: r.right,
      top: r.top,
      bottom: r.bottom,
      cx: r.left + r.width / 2,
      cy: r.top + r.height / 2,
    };
  }

  private isEditingTarget(e: KeyboardEvent): boolean {
    const t = (e.target as HTMLElement) || document.activeElement;
    if (!t) return false;
    const tag = t.tagName;
    return (
      tag === "INPUT" ||
      tag === "TEXTAREA" ||
      (t as HTMLElement).isContentEditable === true
    );
  }

  private handleKeyDown = (e: KeyboardEvent) => {
    // When a text field is focused (on-screen keyboard open), let editing keys
    // reach the input instead of treating them as navigation/back.
    if (this.isEditingTarget(e)) {
      const kc = e.keyCode;
      const isBackspace = kc === 8 || e.key === "Backspace";
      const isDelete = kc === 46 || e.key === "Delete";
      if (isBackspace || isDelete) {
        // Let the field delete characters / handle "clear".
        return;
      }
      // Real remote Back closes the keyboard (blur), it must not edit text.
      const isRealBack =
        kc === 461 || kc === 10009 || kc === 27 || e.key === "Escape";
      if (isRealBack) {
        e.preventDefault();
        e.stopPropagation();
        const el = (e.target as HTMLElement) || document.activeElement;
        (el as HTMLInputElement)?.blur?.();
        return;
      }
      const cur = this.currentId ? this.items.get(this.currentId) : null;
      if (cur?.editArrowsAsFields) {
        // Vertical form fields (e.g. login): the on-screen keyboard's
        // "ileri/geri" (ArrowRight/Left) and Enter/Tab jump between fields.
        const goNext =
          kc === 13 || kc === 39 || kc === 40 || (kc === 9 && !e.shiftKey) ||
          e.key === "Enter" || e.key === "ArrowRight" || e.key === "ArrowDown";
        const goPrev =
          kc === 37 || kc === 38 || (kc === 9 && e.shiftKey) ||
          e.key === "ArrowLeft" || e.key === "ArrowUp";
        if (goNext || goPrev) {
          e.preventDefault();
          e.stopPropagation();
          this.move(goPrev ? "up" : "down");
          return;
        }
        return;
      }
      // Otherwise arrows fall through to normal directional navigation below
      // (so search boxes move in their real left/right/up/down direction).
    }

    const key = resolveKey(e);
    // Let global listeners (player, modals) intercept first.
    for (const fn of this.keyListeners) {
      const consumed = fn(key, e);
      if (consumed) {
        e.preventDefault();
        e.stopPropagation();
        return;
      }
    }

    if (key === "enter") {
      const item = this.currentId ? this.items.get(this.currentId) : null;
      if (item?.onEnter) {
        e.preventDefault();
        item.onEnter();
      }
      return;
    }

    if (
      key === "up" ||
      key === "down" ||
      key === "left" ||
      key === "right"
    ) {
      e.preventDefault();
      // Throttle rapid auto-repeats so held d-pad presses don't pile up and
      // make navigation feel sluggish; single presses are never delayed.
      if (e.repeat) {
        const now = Date.now();
        if (now - this.lastMoveAt < FocusManager.MOVE_THROTTLE_MS) return;
        this.lastMoveAt = now;
      } else {
        this.lastMoveAt = Date.now();
      }
      this.move(key);
    }
  };

  move(dir: Direction) {
    const current = this.currentId ? this.items.get(this.currentId) : null;
    if (!current) {
      this.focusFirst();
      return;
    }
    if (current.onArrow?.(dir)) return;

    const explicit = current.neighbors?.[dir];
    if (explicit && this.items.has(explicit)) {
      this.focus(explicit);
      return;
    }

    const next = this.findNeighbor(current, dir);
    if (next) this.focus(next.id);
  }

  private findNeighbor(
    from: FocusableConfig,
    dir: Direction
  ): FocusableConfig | null {
    const src = this.rectOf(from.element);
    let best: FocusableConfig | null = null;
    let bestScore = Number.POSITIVE_INFINITY;

    for (const cand of this.visibleItems()) {
      if (cand.id === from.id) continue;
      const r = this.rectOf(cand.element);

      let primary: number; // distance along movement axis (must be > 0)
      let cross: number; // misalignment on the other axis

      switch (dir) {
        case "left":
          primary = src.left - r.right;
          if (r.cx >= src.cx) continue;
          cross = Math.abs(src.cy - r.cy);
          break;
        case "right":
          primary = r.left - src.right;
          if (r.cx <= src.cx) continue;
          cross = Math.abs(src.cy - r.cy);
          break;
        case "up":
          primary = src.top - r.bottom;
          if (r.cy >= src.cy) continue;
          cross = Math.abs(src.cx - r.cx);
          break;
        case "down":
          primary = r.top - src.bottom;
          if (r.cy <= src.cy) continue;
          cross = Math.abs(src.cx - r.cx);
          break;
      }

      const primaryDist = Math.max(primary, 0);
      // Weight cross-axis misalignment heavily so we prefer aligned targets.
      const score = primaryDist + cross * 2;
      if (score < bestScore) {
        bestScore = score;
        best = cand;
      }
    }
    return best;
  }
}

export const focusManager = new FocusManager();
