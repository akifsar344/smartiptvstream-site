import { useEffect } from "react";
import { focusManager } from "./focusManager";
import { NavKey } from "./keys";

// Registers a handler for the remote "Back" key (webOS 461 / Tizen 10009 /
// browser Esc/Backspace). Return true from the handler to consume the event.
export function useBack(handler: () => boolean | void, enabled = true) {
  useEffect(() => {
    if (!enabled) return;
    const unsub = focusManager.addKeyListener((key: NavKey) => {
      if (key === "back") {
        const consumed = handler();
        return consumed !== false;
      }
      return false;
    });
    return unsub;
  }, [handler, enabled]);
}
