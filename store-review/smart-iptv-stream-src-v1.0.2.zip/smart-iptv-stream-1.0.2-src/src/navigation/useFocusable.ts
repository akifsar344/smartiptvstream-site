import {
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import { Direction, focusManager } from "./focusManager";

let counter = 0;
function nextId(prefix: string) {
  counter += 1;
  return `${prefix}-${counter}`;
}

export interface UseFocusableOptions {
  focusKey?: string;
  onEnter?: () => void;
  onArrow?: (dir: Direction) => boolean;
  onFocus?: () => void;
  onBlur?: () => void;
  autoFocus?: boolean;
  disabled?: boolean;
  priority?: number;
  neighbors?: Partial<Record<Direction, string>>;
  layer?: string;
  editArrowsAsFields?: boolean;
}

export interface UseFocusableResult<T extends HTMLElement> {
  ref: React.RefObject<T>;
  focused: boolean;
  focusKey: string;
  focusSelf: () => void;
}

export function useFocusable<T extends HTMLElement = HTMLDivElement>(
  options: UseFocusableOptions = {}
): UseFocusableResult<T> {
  const reactId = useId();
  const ref = useRef<T>(null);
  const [focused, setFocused] = useState(false);
  const focusKeyRef = useRef(options.focusKey || nextId(reactId));
  const focusKey = focusKeyRef.current;

  // Keep latest callbacks in refs so the registration stays stable.
  const cbRef = useRef(options);
  cbRef.current = options;

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    focusManager.register({
      id: focusKey,
      element: el,
      disabled: options.disabled,
      priority: options.priority,
      neighbors: options.neighbors,
      layer: options.layer,
      editArrowsAsFields: options.editArrowsAsFields,
      onEnter: () => cbRef.current.onEnter?.(),
      onArrow: (dir) => cbRef.current.onArrow?.(dir) ?? false,
      onFocus: () => {
        setFocused(true);
        cbRef.current.onFocus?.();
      },
      onBlur: () => {
        setFocused(false);
        cbRef.current.onBlur?.();
      },
    });

    if (cbRef.current.autoFocus) {
      focusManager.focus(focusKey);
    }

    // Magic Remote / mouse pointer support: hovering focuses the element so
    // pointer and D-pad share the same focus model.
    const onPointerEnter = () => {
      if (!cbRef.current.disabled) focusManager.focus(focusKey);
    };
    el.addEventListener("mouseenter", onPointerEnter);

    return () => {
      el.removeEventListener("mouseenter", onPointerEnter);
      focusManager.unregister(focusKey);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [focusKey]);

  useEffect(() => {
    focusManager.update(focusKey, {
      disabled: options.disabled,
      priority: options.priority,
      neighbors: options.neighbors,
    });
  }, [focusKey, options.disabled, options.priority, options.neighbors]);

  const focusSelf = useCallback(() => {
    focusManager.focus(focusKey);
  }, [focusKey]);

  return { ref, focused, focusKey, focusSelf };
}
