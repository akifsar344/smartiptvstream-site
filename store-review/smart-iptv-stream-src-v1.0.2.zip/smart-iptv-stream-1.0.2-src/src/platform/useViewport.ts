import { useEffect, useState } from "react";

// The TV UI is a fixed 1280x720 (16:9) landscape canvas, so on phones it only
// looks right in landscape. This hook reports whether we're on a touch device
// and whether it is currently held in portrait, so the app can prompt the user
// to rotate. Desktop browsers (fine pointer) are never treated as mobile, so
// they keep the normal scaled stage regardless of window shape.
export interface ViewportState {
  isMobile: boolean;
  portrait: boolean;
}

function read(): ViewportState {
  if (typeof window === "undefined") return { isMobile: false, portrait: false };
  const coarse = window.matchMedia?.("(pointer: coarse)")?.matches ?? false;
  const portrait = window.innerHeight >= window.innerWidth;
  return { isMobile: coarse, portrait };
}

export function useViewport(): ViewportState {
  const [state, setState] = useState<ViewportState>(read);
  useEffect(() => {
    const on = () => setState(read());
    window.addEventListener("resize", on);
    window.addEventListener("orientationchange", on);
    return () => {
      window.removeEventListener("resize", on);
      window.removeEventListener("orientationchange", on);
    };
  }, []);
  return state;
}

// Best-effort attempt to keep the phone in landscape once the user is inside
// the app. This only succeeds on browsers that support the Screen Orientation
// Lock API (mainly Android Chrome, and usually only in fullscreen/installed
// mode); iOS Safari doesn't support it, so the rotate prompt is the fallback.
export function attemptLandscapeLock(): void {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const o: any = (screen as any).orientation;
    if (o && typeof o.lock === "function") {
      const p = o.lock("landscape");
      if (p && typeof p.catch === "function") p.catch(() => {});
    }
  } catch {
    /* unsupported → rely on the rotate prompt */
  }
}
