// Large-capacity persistent disk cache backed by IndexedDB.
//
// localStorage is only ~5MB and silently drops oversized writes, which is far
// too small for full Xtream catalogs (tens of thousands of streams). IndexedDB
// persists to disk with a much larger quota and stores structured objects
// directly (no JSON serialize/parse), so reloads are fast. Available on both
// webOS and Tizen web runtimes.

const DB_NAME = "sis_cache";
const STORE = "kv";
const VERSION = 1;

let dbPromise: Promise<IDBDatabase | null> | null = null;

function openDb(): Promise<IDBDatabase | null> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve) => {
    try {
      if (typeof indexedDB === "undefined") return resolve(null);
      const req = indexedDB.open(DB_NAME, VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
  return dbPromise;
}

export const diskCache = {
  async get<T = unknown>(key: string): Promise<T | null> {
    try {
      const db = await openDb();
      if (!db) return null;
      return await new Promise<T | null>((resolve) => {
        const tx = db.transaction(STORE, "readonly");
        const req = tx.objectStore(STORE).get(key);
        req.onsuccess = () => resolve((req.result as T) ?? null);
        req.onerror = () => resolve(null);
      });
    } catch {
      return null;
    }
  },

  async set(key: string, value: unknown): Promise<void> {
    try {
      const db = await openDb();
      if (!db) return;
      await new Promise<void>((resolve) => {
        const tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE).put(value, key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
        tx.onabort = () => resolve();
      });
    } catch {
      /* quota / unavailable */
    }
  },

  async remove(key: string): Promise<void> {
    try {
      const db = await openDb();
      if (!db) return;
      await new Promise<void>((resolve) => {
        const tx = db.transaction(STORE, "readwrite");
        tx.objectStore(STORE).delete(key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      });
    } catch {
      /* noop */
    }
  },
};
