export type PlatformType = "webos" | "tizen" | "titanos" | "browser";

declare global {
  interface Window {
    webOS?: any;
    webOSSystem?: any;
    PalmSystem?: any;
    PalmServiceBridge?: any;
    tizen?: any;
    webapis?: any;
    // Titan OS exposes the SDK globally when integrated via the CDN build.
    titan?: any;
    titanOS?: any;
    getTitanSDK?: any;
  }
}

/**
 * This build targets Titan OS (Philips / AOC / Vestel, Chromium-based). Titan
 * apps are hosted HTML5 pages, so the runtime is a plain Chromium browser and
 * there is no reliable native global to sniff. We therefore:
 *   1. still honour webOS / Tizen globals (in case the same URL is ever loaded
 *      on those platforms), then
 *   2. treat Titan OS as the *default* for this dedicated build — so real Titan
 *      devices always get TV behaviour even if their User-Agent is unexpected.
 * A localStorage override (`force.platform`) is supported for QA/testing.
 */
function detectPlatform(): PlatformType {
  try {
    const forced = localStorage.getItem("force.platform");
    if (forced === "webos" || forced === "tizen" || forced === "titanos" || forced === "browser") {
      return forced;
    }
  } catch {
    /* localStorage may be unavailable */
  }

  const ua = navigator.userAgent.toLowerCase();
  if (
    typeof window.webOS !== "undefined" ||
    typeof window.webOSSystem !== "undefined" ||
    typeof window.PalmSystem !== "undefined" ||
    ua.includes("web0s") ||
    ua.includes("webos")
  ) {
    return "webos";
  }
  if (
    typeof window.tizen !== "undefined" ||
    typeof window.webapis !== "undefined" ||
    ua.includes("tizen") ||
    ua.includes("samsung")
  ) {
    return "tizen";
  }
  // Explicit Titan / partner-device hints (best effort — Titan can issue a
  // custom UA per partner, so we also fall through to Titan by default below).
  if (
    typeof window.titan !== "undefined" ||
    typeof window.titanOS !== "undefined" ||
    typeof window.getTitanSDK !== "undefined" ||
    ua.includes("titan") ||
    ua.includes("philips") ||
    ua.includes("aoc") ||
    ua.includes("vestel") ||
    ua.includes("smart-tv")
  ) {
    return "titanos";
  }
  // Dedicated Titan build → default to Titan (real devices behave as a TV;
  // a desktop dev browser degrades gracefully via the same code paths).
  return "titanos";
}

export const PLATFORM: PlatformType = detectPlatform();
export const IS_TV = PLATFORM !== "browser";
export const IS_WEBOS = PLATFORM === "webos";
export const IS_TIZEN = PLATFORM === "tizen";
export const IS_TITAN = PLATFORM === "titanos";

export function exitApp() {
  try {
    if (IS_WEBOS && window.webOS?.platformBack) {
      window.webOS.platformBack();
      return;
    }
    if (IS_TIZEN && window.tizen?.application) {
      window.tizen.application.getCurrentApplication().exit();
      return;
    }
  } catch {
    /* noop */
  }
  // Browser fallback
  window.close();
}

export function getDeviceInfo(): { brand: string; model: string } {
  const ua = navigator.userAgent;
  if (IS_WEBOS) return { brand: "LG", model: ua };
  if (IS_TIZEN) return { brand: "Samsung", model: ua };
  if (IS_TITAN) return { brand: "Titan OS", model: ua };
  return { brand: "Browser", model: ua };
}

const APP_CLIENT_NAME = "com.discoverapp.iptvplayer";
let screenSaverBridge: any = null;

/**
 * Prevents the TV screensaver from activating while the app is open.
 * webOS: subscribes to the screensaver request and replies with ack:false.
 * Tizen: requests a screen power lock / disables the screensaver.
 * Idempotent — safe to call multiple times.
 */
export function keepScreenAwake(): void {
  // Titan OS runs a Chromium browser, which exposes the standard Screen Wake
  // Lock API. Acquire a screen lock and re-acquire it whenever the page becomes
  // visible again (the browser releases the lock on tab/visibility changes).
  if (IS_TITAN) {
    const nav = navigator as any;
    if (!nav?.wakeLock?.request) return;
    let sentinel: any = null;
    const acquire = () => {
      if (document.visibilityState !== "visible") return;
      nav.wakeLock
        .request("screen")
        .then((s: any) => {
          sentinel = s;
        })
        .catch(() => {
          /* denied / unsupported — best effort */
        });
    };
    acquire();
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible" && !sentinel) acquire();
    });
    return;
  }

  if (IS_WEBOS) {
    if (screenSaverBridge) return;
    try {
      const Bridge = window.PalmServiceBridge;
      if (!Bridge) return;
      const bridge = new Bridge();
      screenSaverBridge = bridge;
      bridge.onservicecallback = (msg: string) => {
        let m: any;
        try {
          m = JSON.parse(msg);
        } catch {
          return;
        }
        // When the screensaver is about to start, decline it.
        if (m && m.state === "Active") {
          try {
            const resp = new Bridge();
            resp.onservicecallback = () => {};
            resp.call(
              "luna://com.webos.service.tvpower/power/responseScreenSaverRequest",
              JSON.stringify({
                clientName: APP_CLIENT_NAME,
                ack: false,
                timestamp: m.timestamp,
              })
            );
          } catch {
            /* noop */
          }
        }
      };
      bridge.call(
        "luna://com.webos.service.tvpower/power/registerScreenSaverRequest",
        JSON.stringify({ subscribe: true, clientName: APP_CLIENT_NAME })
      );
    } catch {
      /* noop */
    }
    return;
  }

  if (IS_TIZEN) {
    try {
      window.tizen?.power?.request?.("SCREEN", "SCREEN_NORMAL");
    } catch {
      /* noop */
    }
    try {
      const ac = window.webapis?.appcommon;
      if (ac?.setScreenSaver && ac.AppCommonScreenSaverState) {
        ac.setScreenSaver(ac.AppCommonScreenSaverState.SCREEN_SAVER_OFF);
      }
    } catch {
      /* noop */
    }
  }
}

/** Low-level luna bus call for webOS web apps via PalmServiceBridge. */
function lunaCall<T = any>(uri: string, params: Record<string, unknown>): Promise<T> {
  return new Promise((resolve, reject) => {
    try {
      const Bridge = window.PalmServiceBridge;
      if (!Bridge) {
        reject(new Error("PalmServiceBridge unavailable"));
        return;
      }
      const bridge = new Bridge();
      bridge.onservicecallback = (msg: string) => {
        try {
          resolve(JSON.parse(msg));
        } catch (e) {
          reject(e);
        }
      };
      bridge.call(uri, JSON.stringify(params));
    } catch (e) {
      reject(e);
    }
  });
}

/**
 * Opens the platform app store so the user can rate/review the app.
 * webOS: launches the LG Content Store (deep-linking to our app page is not
 * supported, so it opens the store home). Tizen: launches Samsung Apps.
 * Best-effort — silently no-ops if the launch bus is unavailable.
 */
export function launchAppStore(): void {
  if (IS_WEBOS) {
    // Try the modern then legacy applicationManager bus ids.
    const buses = [
      "luna://com.webos.applicationManager/launch",
      "luna://com.webos.service.applicationManager/launch",
    ];
    for (const uri of buses) {
      void lunaCall(uri, { id: "com.webos.app.discovery", params: {} }).catch(
        () => {}
      );
    }
    return;
  }
  if (IS_TIZEN) {
    try {
      const appControl = new window.tizen.ApplicationControl(
        "http://tizen.org/appcontrol/operation/view",
        "samsungapps://ProductDetail/" + APP_CLIENT_NAME
      );
      window.tizen.application.launchAppControl(appControl, null);
    } catch {
      /* noop */
    }
  }
}

/**
 * Best-effort detection of the TV's UI language.
 * webOS: queries settingsservice (localeInfo.locales.UI).
 * Tizen: queries systeminfo LOCALE.
 * Falls back to synchronous platform props / navigator.language.
 */
export async function getSystemLocale(): Promise<string | null> {
  // Synchronous hints first (fast, often correct).
  const syncHint =
    window.webOSSystem?.locale ||
    window.PalmSystem?.locale ||
    (typeof navigator !== "undefined" ? navigator.language : "") ||
    null;

  if (IS_WEBOS) {
    try {
      const res = await Promise.race([
        lunaCall<any>("luna://com.webos.settingsservice/getSystemSettings", {
          keys: ["localeInfo"],
        }),
        new Promise<null>((r) => setTimeout(() => r(null), 1500)),
      ]);
      const ui = res?.settings?.localeInfo?.locales?.UI;
      if (ui) return ui;
    } catch {
      /* fall through to sync hint */
    }
    return syncHint;
  }

  if (IS_TIZEN) {
    try {
      const locale = await Promise.race([
        new Promise<string | null>((resolve) => {
          try {
            window.tizen?.systeminfo?.getPropertyValue(
              "LOCALE",
              (l: any) => resolve(l?.language || null),
              () => resolve(null)
            );
          } catch {
            resolve(null);
          }
        }),
        new Promise<null>((r) => setTimeout(() => r(null), 1500)),
      ]);
      if (locale) return locale;
    } catch {
      /* fall through */
    }
    return syncHint;
  }

  return syncHint;
}
