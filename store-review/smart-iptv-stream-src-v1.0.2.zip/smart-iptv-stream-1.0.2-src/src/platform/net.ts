// Web-build networking helpers. On smartiptvstream.com the app runs in a plain
// browser, so two browser-only constraints apply that TVs don't have:
//   1. Mixed content: an HTTPS page cannot load http:// resources.
//   2. CORS: cross-origin XHR/fetch (Xtream API, HLS segments) is blocked unless
//      the far server sends CORS headers, which IPTV panels never do.
// Our own backend exposes /api/proxy which fetches server-side and returns the
// bytes same-origin, sidestepping both. Strategy = "HTTPS-first": only route
// through the proxy when we must, to keep server bandwidth down.

// API base for the backend. Empty string = same origin (production, where the
// Node server also serves the static app). In dev the Vite server is on :5173
// while the API is on :8080, so set VITE_API_BASE=http://localhost:8080.
import { IS_EXT } from "./ext";

export function apiBase(): string {
  return (import.meta.env.VITE_API_BASE as string) || "";
}

export function proxyPath(rawUrl: string): string {
  return `${apiBase()}/api/proxy?url=${encodeURIComponent(rawUrl)}`;
}

function isHttp(url: string): boolean {
  return /^http:\/\//i.test(url);
}

/**
 * For cross-origin JSON APIs (Xtream player_api.php) we ALWAYS proxy: even an
 * HTTPS panel would be blocked by CORS from a browser.
 */
export function apiFetchUrl(rawUrl: string): string {
  try {
    const u = new URL(rawUrl, location.href);
    // Same-origin (our own API) → leave untouched.
    if (u.origin === location.origin) return rawUrl;
  } catch {
    /* fall through to proxy */
  }
  // In the browser extension the page holds host permissions, so cross-origin
  // (and http) fetches are allowed directly — no CORS, no proxy, no server load.
  if (IS_EXT) return rawUrl;
  return proxyPath(rawUrl);
}

/**
 * For media (video/HLS): HTTPS-first. https URLs are attempted directly (native
 * <video>/<img> can load cross-origin without CORS); http URLs must be proxied
 * to avoid the mixed-content block.
 */
export function mediaUrl(rawUrl: string): string {
  if (!rawUrl) return rawUrl;
  return isHttp(rawUrl) ? proxyPath(rawUrl) : rawUrl;
}

/**
 * HLS/segment fetches go through hls.js (which uses XHR) so they need CORS as
 * well as http→https. When we already know direct playback failed, callers can
 * force the proxy for any scheme.
 */
export function mediaUrlForced(rawUrl: string): string {
  if (!rawUrl) return rawUrl;
  try {
    const u = new URL(rawUrl, location.href);
    if (u.origin === location.origin) return rawUrl;
  } catch {
    /* fall through */
  }
  // Extension host permissions let hls.js/mpegts.js XHR fetch cross-origin
  // segments directly (the panels' missing CORS headers no longer matter).
  if (IS_EXT) return rawUrl;
  return proxyPath(rawUrl);
}

/** Images: http → proxy (mixed content), https → direct. */
export function imageUrl(rawUrl: string): string {
  if (!rawUrl) return rawUrl;
  return isHttp(rawUrl) ? proxyPath(rawUrl) : rawUrl;
}
