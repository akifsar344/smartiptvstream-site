import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Routes } from "../routes";
import { useAuth } from "../store/auth";
import { IS_EXT } from "./ext";

type PendingPlayback = {
  v: 1;
  handoffCode: string;
  url: string;
  fallbackUrl?: string;
  title: string;
  kind: "live" | "vod";
  createdAt: number;
};

// Safari exposes the extension APIs as `browser`, Chrome/Edge as `chrome`.
const extApi = ((globalThis as { browser?: typeof chrome }).browser ??
  (typeof chrome === "undefined" ? undefined : chrome)) as typeof chrome | undefined;

// Consumes one-shot playback requests forwarded by the extension's content
// script. Account handoff happens before navigation, so Pro and cloud-synced
// profiles always belong to the same user who clicked from the website.
export function useWebPlaybackBridge(): void {
  const navigate = useNavigate();
  const status = useAuth((s) => s.status);
  const consuming = useRef(false);

  useEffect(() => {
    if (!IS_EXT || status === "loading" || !extApi?.storage) return;
    const area = extApi.storage.session || extApi.storage.local;

    const consume = async () => {
      if (consuming.current) return;
      consuming.current = true;
      try {
        const result = await area.get("pendingWebPlayback");
        const pending = result.pendingWebPlayback as PendingPlayback | undefined;
        if (!pending) return;
        await area.remove("pendingWebPlayback");
        if (
          pending.v !== 1 ||
          !pending.handoffCode ||
          !/^https?:\/\//i.test(pending.url) ||
          Date.now() - pending.createdAt > 2 * 60_000
        ) {
          return;
        }
        await useAuth.getState().loginWithExtensionHandoff(pending.handoffCode);
        navigate(Routes.player, {
          state: {
            url: pending.url,
            fallbackUrl: pending.fallbackUrl,
            title: pending.title,
            kind: pending.kind,
            bridgeNonce: pending.createdAt,
          },
        });
      } finally {
        consuming.current = false;
      }
    };

    void consume();
    const onChanged = (
      changes: Record<string, chrome.storage.StorageChange>,
      areaName: string
    ) => {
      if (
        changes.pendingWebPlayback?.newValue &&
        (areaName === "session" || areaName === "local")
      ) {
        void consume();
      }
    };
    extApi.storage.onChanged.addListener(onChanged);
    return () => extApi.storage.onChanged.removeListener(onChanged);
  }, [navigate, status]);
}
