// Stable per-device identifiers used to anchor the free trial server-side so a
// second account on the same device/browser can't farm a fresh trial.
//
// - deviceId: a random value persisted in raw localStorage. Kept OUTSIDE the
//   app's `sis:` namespace so it survives account logout/data clears.
// - fingerprint: a coarse hash of stable browser/device traits, used as a
//   fallback when localStorage is wiped (incognito, "clear site data").

const DEVICE_KEY = "stream.device";

function randomId(): string {
  try {
    const buf = new Uint8Array(16);
    crypto.getRandomValues(buf);
    return Array.from(buf, (b) => b.toString(16).padStart(2, "0")).join("");
  } catch {
    return `${Date.now().toString(16)}${Math.random().toString(16).slice(2)}`;
  }
}

// djb2 string hash → unsigned hex.
function hashString(input: string): string {
  let h = 5381;
  for (let i = 0; i < input.length; i++) {
    h = ((h << 5) + h + input.charCodeAt(i)) >>> 0;
  }
  return h.toString(16);
}

export function getDeviceId(): string {
  try {
    let v = localStorage.getItem(DEVICE_KEY);
    if (!v) {
      v = randomId();
      localStorage.setItem(DEVICE_KEY, v);
    }
    return v;
  } catch {
    return "";
  }
}

export function getFingerprint(): string {
  try {
    const nav = navigator;
    const parts = [
      nav.userAgent,
      nav.language,
      (nav.languages || []).join(","),
      `${screen.width}x${screen.height}x${screen.colorDepth}`,
      String(new Date().getTimezoneOffset()),
      (nav as unknown as { platform?: string }).platform || "",
      String((nav as unknown as { hardwareConcurrency?: number }).hardwareConcurrency || ""),
      String((nav as unknown as { deviceMemory?: number }).deviceMemory || ""),
    ];
    return hashString(parts.join("|"));
  } catch {
    return "";
  }
}

export function getDeviceInfo(): { deviceId: string; fingerprint: string } {
  return { deviceId: getDeviceId(), fingerprint: getFingerprint() };
}
