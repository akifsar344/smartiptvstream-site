// Resolve a bundled public asset (files under /public) to a URL that works no
// matter how deep the current route is. On the web build Vite's BASE_URL is
// "/", so assets resolve to an absolute "/assets/..." (correct whether the app
// is mounted at "/app" or "/app/"). In packaged webOS/Tizen builds BASE_URL is
// "./", keeping the path relative to the app root as those runtimes require.
const BASE = import.meta.env.BASE_URL || "./";

export function asset(path: string): string {
  const clean = path.replace(/^\.?\//, "");
  return `${BASE}${clean}`;
}
