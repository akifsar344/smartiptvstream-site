// The browser app is served under "/app" on smartiptvstream.com (the site root
// hosts the marketing landing page for SEO). These helpers build absolute,
// shareable URLs (QR codes, checkout return URLs) that point back at the app
// regardless of where it is mounted. In local dev the app runs at the root, so
// we mirror the current mount point instead of hard-coding "/app".

import { IS_EXT, siteUrl } from "./ext";

/** Absolute base URL of the app (e.g. "https://smartiptvstream.com/app"). */
export function appBaseUrl(): string {
  // In the extension the page origin is chrome-extension://… which a phone can't
  // open, so shareable links (QR, checkout) must point at the hosted site.
  if (IS_EXT) return siteUrl();
  const { origin, pathname } = window.location;
  return pathname.startsWith("/app") ? `${origin}/app` : origin;
}

/** Absolute hash-route URL, e.g. appHashUrl("/pay", "t=abc"). */
export function appHashUrl(hashPath: string, query = ""): string {
  const q = query ? `?${query}` : "";
  return `${appBaseUrl()}/#${hashPath}${q}`;
}
