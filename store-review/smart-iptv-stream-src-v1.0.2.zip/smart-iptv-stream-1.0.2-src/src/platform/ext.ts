// Browser-extension (Chrome/Edge/Safari) build helpers. The same web app runs
// inside a chrome-extension:// page, so two things differ from the hosted site:
//   1. Attribution/payment links must point back at the hosted site
//      (smartiptvstream.com) because a chrome-extension:// origin isn't a public
//      URL a phone can open, and Cleeng's remote widget script can't load under
//      the extension's MV3 CSP.
//   2. Network requests may go direct to the user's IPTV server because the
//      extension holds broad host permissions (no CORS / proxy needed).
// VITE_EXT is injected only by the extension build (EXT_BUILD=1); everywhere else
// it is undefined, so IS_EXT is false and the web/TV behaviour is untouched.

export const IS_EXT = import.meta.env.VITE_EXT === "1";

/** True inside the Safari build (same bundle, safari-web-extension:// origin).
 *  It ships through the Mac App Store, where App Store guideline 3.1.1 bans
 *  sending users to our own checkout, so Pro is sold by the container app's
 *  StoreKit purchase instead. */
export const IS_SAFARI_EXT =
  IS_EXT && typeof location !== "undefined" && location.protocol === "safari-web-extension:";

/** Public base URL of the hosted app, e.g. "https://smartiptvstream.com/app". */
export function siteUrl(): string {
  return (import.meta.env.VITE_SITE_URL as string) || "https://smartiptvstream.com/app";
}

/** Opens a hash route on the hosted site in a new browser tab (used for the
 *  Cleeng checkout, which can't run inside the extension's CSP). */
export function openHostedTab(hashPath: string, query = ""): void {
  const q = query ? `?${query}` : "";
  const url = `${siteUrl()}/#${hashPath}${q}`;
  window.open(url, "_blank", "noopener,noreferrer");
}
