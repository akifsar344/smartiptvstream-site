// Simple persistent key/value storage. localStorage backs everything. On the
// web build a cloud-sync layer (store/cloudSync.ts) mirrors the whole `sis:`
// namespace to the logged-in user's account, so it also exposes bulk
// export/import and a change subscription.

const PREFIX = "sis:";

type ChangeListener = () => void;
const listeners = new Set<ChangeListener>();
let muted = false; // suppress notifications while importing from the cloud

function notify() {
  if (muted) return;
  for (const cb of listeners) {
    try {
      cb();
    } catch {
      /* listener errors must not break persistence */
    }
  }
}

export const storage = {
  get<T = unknown>(key: string, fallback: T): T {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw == null) return fallback;
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  },

  set(key: string, value: unknown): void {
    try {
      localStorage.setItem(PREFIX + key, JSON.stringify(value));
      notify();
    } catch {
      /* quota / private mode */
    }
  },

  remove(key: string): void {
    try {
      localStorage.removeItem(PREFIX + key);
      notify();
    } catch {
      /* noop */
    }
  },

  getString(key: string, fallback = ""): string {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      return raw == null ? fallback : raw;
    } catch {
      return fallback;
    }
  },

  setString(key: string, value: string): void {
    try {
      localStorage.setItem(PREFIX + key, value);
      notify();
    } catch {
      /* noop */
    }
  },

  // ---- Bulk operations for cloud sync ----

  /** Returns every namespaced entry as { keyWithoutPrefix: rawStringValue }. */
  exportAll(): Record<string, string> {
    const out: Record<string, string> = {};
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const full = localStorage.key(i);
        if (full && full.startsWith(PREFIX)) {
          const v = localStorage.getItem(full);
          if (v != null) out[full.slice(PREFIX.length)] = v;
        }
      }
    } catch {
      /* noop */
    }
    return out;
  },

  /** Clears the namespace and replaces it with `data`. Does not notify. */
  importAll(data: Record<string, unknown>): void {
    muted = true;
    try {
      const toRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const full = localStorage.key(i);
        if (full && full.startsWith(PREFIX)) toRemove.push(full);
      }
      for (const k of toRemove) localStorage.removeItem(k);
      for (const [k, v] of Object.entries(data || {})) {
        localStorage.setItem(PREFIX + k, typeof v === "string" ? v : JSON.stringify(v));
      }
    } catch {
      /* noop */
    } finally {
      muted = false;
    }
  },

  /** Removes the whole namespace (used on logout). Does not notify. */
  clearAll(): void {
    muted = true;
    try {
      const toRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const full = localStorage.key(i);
        if (full && full.startsWith(PREFIX)) toRemove.push(full);
      }
      for (const k of toRemove) localStorage.removeItem(k);
    } catch {
      /* noop */
    } finally {
      muted = false;
    }
  },

  onChange(cb: ChangeListener): () => void {
    listeners.add(cb);
    return () => listeners.delete(cb);
  },
};
