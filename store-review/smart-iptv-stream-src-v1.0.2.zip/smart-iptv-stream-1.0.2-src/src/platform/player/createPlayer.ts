import { IS_TIZEN } from "../device";
import { Html5Player } from "./Html5Player";
import { TizenAvplayPlayer } from "./TizenAvplayPlayer";
import { IPlayerAdapter } from "./types";

// Picks the best media engine for the current platform.
// - Tizen (Samsung): AVPlay (native, robust HLS/TS)
// - webOS (LG) & browser: HTML5 <video> + hls.js
export function createPlayer(): IPlayerAdapter {
  if (IS_TIZEN && (window as any).webapis?.avplay) {
    return new TizenAvplayPlayer();
  }
  return new Html5Player();
}
