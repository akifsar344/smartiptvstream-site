import {
  IPlayerAdapter,
  PlayerEvents,
  PlayerSource,
  PlayerState,
  PlayerTrack,
} from "./types";

// Samsung Tizen AVPlay adapter. AVPlay is the recommended media engine on
// Tizen TVs and handles HLS / MPEG-TS far better than MSE/hls.js.
// Docs: https://docs.tizen.org/application/web/api/latest/device_api/tv/tizen/avplay.html
export class TizenAvplayPlayer implements IPlayerAdapter {
  private obj: HTMLObjectElement | null = null;
  private container: HTMLElement | null = null;
  private events: PlayerEvents = {};
  private duration = 0;
  private ticker: number | null = null;
  private selectedTextId: number | null = null;
  private selectedAudioId: number | null = null;

  private get av(): any {
    return (window as any).webapis?.avplay;
  }

  attach(container: HTMLElement, events: PlayerEvents): void {
    this.container = container;
    this.events = events;
    const obj = document.createElement("object");
    obj.type = "application/avplayer";
    obj.style.width = "100%";
    obj.style.height = "100%";
    obj.style.background = "#000";
    this.obj = obj;
    container.appendChild(obj);
  }

  async load(source: PlayerSource): Promise<void> {
    const av = this.av;
    if (!av) {
      this.events.onError?.("AVPlay unavailable", true);
      return;
    }
    this.emit("loading");
    try {
      try {
        av.stop();
        av.close();
      } catch {
        /* first run */
      }
      av.open(source.url);
      av.setDisplayRect(
        0,
        0,
        window.innerWidth,
        window.innerHeight
      );
      try {
        av.setDisplayMethod("PLAYER_DISPLAY_MODE_AUTO_ASPECT_RATIO");
      } catch {
        /* older firmware */
      }

      av.setListener({
        onbufferingstart: () => this.emit("buffering"),
        onbufferingcomplete: () => this.emit("playing"),
        onstreamcompleted: () => {
          this.emit("ended");
          this.events.onEnded?.();
        },
        oncurrentplaytime: (ms: number) => {
          this.events.onTimeUpdate?.(ms / 1000, this.duration / 1000);
        },
        onerror: (err: string) => {
          this.events.onError?.(String(err), true);
          this.emit("error");
        },
      });

      av.prepareAsync(
        () => {
          try {
            this.duration = av.getDuration();
          } catch {
            this.duration = 0;
          }
          if (source.startPositionSec) {
            try {
              av.jumpForward(Math.floor(source.startPositionSec * 1000));
            } catch {
              /* noop */
            }
          }
          this.events.onReady?.();
          av.play();
          this.emit("playing");
          this.startTicker();
        },
        (err: string) => {
          this.events.onError?.("prepare failed: " + err, true);
          this.emit("error");
        }
      );
    } catch (e) {
      this.events.onError?.("AVPlay load error: " + String(e), true);
      this.emit("error");
    }
  }

  private startTicker() {
    this.stopTicker();
    this.ticker = window.setInterval(() => {
      try {
        const ms = this.av.getCurrentTime();
        this.events.onTimeUpdate?.(ms / 1000, this.duration / 1000);
      } catch {
        /* noop */
      }
    }, 1000);
  }

  private stopTicker() {
    if (this.ticker != null) {
      clearInterval(this.ticker);
      this.ticker = null;
    }
  }

  private emit(s: PlayerState) {
    this.events.onStateChange?.(s);
  }

  play(): void {
    try {
      this.av?.play();
      this.emit("playing");
    } catch {
      /* noop */
    }
  }
  pause(): void {
    try {
      this.av?.pause();
      this.emit("paused");
    } catch {
      /* noop */
    }
  }
  togglePlay(): void {
    try {
      const state = this.av?.getState();
      if (state === "PLAYING") this.pause();
      else this.play();
    } catch {
      /* noop */
    }
  }
  seekTo(sec: number): void {
    try {
      this.av?.seekTo(Math.floor(sec * 1000));
    } catch {
      /* noop */
    }
  }
  seekBy(deltaSec: number): void {
    try {
      if (deltaSec >= 0) this.av?.jumpForward(Math.floor(deltaSec * 1000));
      else this.av?.jumpBackward(Math.floor(-deltaSec * 1000));
    } catch {
      /* noop */
    }
  }
  getCurrentTime(): number {
    try {
      return (this.av?.getCurrentTime() || 0) / 1000;
    } catch {
      return 0;
    }
  }
  getDuration(): number {
    return this.duration / 1000;
  }
  setVolume(_v: number): void {
    // AVPlay volume is controlled via the TV's audio control API; left as noop.
  }

  getAudioTracks(): PlayerTrack[] {
    try {
      const raw = this.av?.getTotalTrackInfo() || [];
      return raw
        .filter((t: any) => t.type === "AUDIO")
        .map((t: any, i: number) => ({
          id: Number(t.index ?? i),
          label: t.extra_info,
        }));
    } catch {
      return [];
    }
  }
  setAudioTrack(id: number): void {
    this.selectedAudioId = id;
    try {
      this.av?.setSelectTrack("AUDIO", id);
    } catch {
      /* noop */
    }
  }
  getTextTracks(): PlayerTrack[] {
    try {
      const raw = this.av?.getTotalTrackInfo() || [];
      return raw
        .filter((t: any) => t.type === "TEXT")
        .map((t: any, i: number) => ({
          id: Number(t.index ?? i),
          label: t.extra_info,
        }));
    } catch {
      return [];
    }
  }
  setTextTrack(id: number | null): void {
    this.selectedTextId = id;
    try {
      if (id == null) {
        // Hide subtitles by disabling the subtitle render path.
        try {
          this.av?.setSilentSubtitle(true);
        } catch {
          /* older firmware */
        }
        return;
      }
      try {
        this.av?.setSilentSubtitle(false);
      } catch {
        /* noop */
      }
      this.av?.setSelectTrack("TEXT", id);
    } catch {
      /* noop */
    }
  }

  getActiveAudioTrack(): number | null {
    return this.selectedAudioId;
  }
  getActiveTextTrack(): number | null {
    return this.selectedTextId;
  }
  setTextScale(): void {
    // AVPlay exposes no portable subtitle font-scale API; left as a noop.
  }

  destroy(): void {
    this.stopTicker();
    try {
      this.av?.stop();
      this.av?.close();
    } catch {
      /* noop */
    }
    if (this.obj && this.container && this.obj.parentNode === this.container) {
      this.container.removeChild(this.obj);
    }
    this.obj = null;
  }
}
