export type StreamKind = "live" | "vod";

export interface PlayerSource {
  url: string;
  kind: StreamKind;
  /** Container hint: "hls" | "ts" | "mp4" | "mkv" | "dash" | "auto" */
  format?: string;
  title?: string;
  startPositionSec?: number;
  /** Alternate URL tried with the native hardware decoder when the primary
   *  (hls.js / MSE) path fails – e.g. HEVC/AC3 channels. */
  fallbackUrl?: string;
}

export interface PlayerTrack {
  id: number;
  language?: string;
  label?: string;
  /** Codec name when known (e.g. "SRT", "AAC"). */
  codec?: string;
}

export type PlayerState =
  | "idle"
  | "loading"
  | "buffering"
  | "playing"
  | "paused"
  | "ended"
  | "error";

export interface PlayerEvents {
  onStateChange?: (state: PlayerState) => void;
  onTimeUpdate?: (currentSec: number, durationSec: number) => void;
  onError?: (message: string, fatal: boolean) => void;
  onReady?: () => void;
  onEnded?: () => void;
}

export interface IPlayerAdapter {
  attach(container: HTMLElement, events: PlayerEvents): void;
  load(source: PlayerSource): Promise<void>;
  play(): void;
  pause(): void;
  togglePlay(): void;
  seekTo(sec: number): void;
  seekBy(deltaSec: number): void;
  getCurrentTime(): number;
  getDuration(): number;
  setVolume(v: number): void;
  /** Mute/unmute at the element level. Muted players can autoplay and coexist
   *  with others (used by multiscreen). Optional. */
  setMuted?(muted: boolean): void;
  /** Snapshot the current video frame as a data URL (used by multiscreen to
   *  freeze the last frame when a cell loses focus and its decoder is freed).
   *  Returns null when no frame is available or the frame is cross-origin
   *  tainted. Optional. */
  captureFrame?(): string | null;
  getAudioTracks(): PlayerTrack[];
  setAudioTrack(id: number): void;
  getTextTracks(): PlayerTrack[];
  setTextTrack(id: number | null): void;
  /** Currently selected track ids (null = off / default). Optional. */
  getActiveAudioTrack?(): number | null;
  getActiveTextTrack?(): number | null;
  /** Scale the subtitle font (1 = default). Optional / best-effort. */
  setTextScale?(scale: number): void;
  /** Attach an external WebVTT subtitle (e.g. from OpenSubtitles) and show it.
   *  Returns the new track id when known. Optional. */
  addExternalSubtitle?(url: string, lang: string, label: string): number | null;
  /** Render an external subtitle from raw WebVTT/SRT text via a custom overlay.
   *  More reliable than native <track> cues on TV browsers. Optional. */
  setExternalSubtitle?(vtt: string, label: string): void;
  /** Remove the custom external-subtitle overlay. Optional. */
  clearExternalSubtitle?(): void;
  /** One-line runtime diagnostics for an on-screen debug HUD. Optional. */
  getDiagnostics?(): string;
  destroy(): void;
}
