import Hls from "hls.js";
import mpegts from "mpegts.js";
import {
  IPlayerAdapter,
  PlayerEvents,
  PlayerSource,
  PlayerState,
  PlayerTrack,
} from "./types";
import { mediaUrl, mediaUrlForced } from "../net";
import { IS_EXT } from "../ext";

// In a browser, MSE engines (hls.js / mpegts.js) need CORS *and* http→https, so
// HLS/TS always go through our same-origin proxy; native VOD (mp4) can load
// cross-origin directly over https and is only proxied when served over http.
function proxifySource(source: PlayerSource): PlayerSource {
  const wrap = (u?: string): string | undefined => {
    if (!u) return u;
    const low = u.toLowerCase();
    if (low.includes(".m3u8") || low.includes(".ts")) return mediaUrlForced(u);
    return mediaUrl(u);
  };
  return { ...source, url: wrap(source.url) as string, fallbackUrl: wrap(source.fallbackUrl) };
}

// HTML5 <video> based player with hls.js for MSE-capable platforms
// (webOS Chromium & desktop browsers). Falls back to native HLS where the
// browser/TV can play m3u8 directly (Safari, some webOS builds).
export class Html5Player implements IPlayerAdapter {
  private video: HTMLVideoElement | null = null;
  private hls: Hls | null = null;
  // Software MPEG-TS demuxer (mpegts.js) over MSE. Used to play raw .ts live
  // streams in Chromium browsers that lack native TS decoding (e.g. desktop
  // Chrome, where hls.js/native <video> both fail on a continuous TS stream).
  private mpegts: mpegts.Player | null = null;
  private events: PlayerEvents = {};
  private container: HTMLElement | null = null;
  private currentSource: PlayerSource | null = null;
  // The original (provider-direct) source before any URL rewriting, plus whether
  // we've already fallen back to routing it through our same-origin proxy. We
  // try the provider directly from the viewer's browser first (dodges the
  // datacenter-IP blocks some Cloudflare-fronted panels apply to our proxy, and
  // saves server bandwidth) and only proxy if the direct attempt fails.
  private rawSource: PlayerSource | null = null;
  private usingProxy = false;
  // Fallback engines are tried at most once each, in an order chosen by the
  // platform's decoding capabilities (native TS on TVs, mpegts.js on desktop).
  private triedNative = false;
  private triedMpegts = false;
  private mediaRecoverCount = 0;
  private hlsNetRetry = 0;
  // Last fallback/error note surfaced in the debug HUD to aid diagnosis.
  private lastNote = "";
  // Watchdog: if a stream never starts (stuck webOS HW decoder after rapid
  // open/close), fall back / error out instead of spinning forever.
  private hasStarted = false;
  private loadTimer: number | null = null;
  // Playback-stall watchdog: detects a frozen picture (currentTime not
  // advancing while playing) and nudges/reloads to recover.
  private stallTimer: number | null = null;
  private lastProgressTime = 0;
  private lastProgressAt = 0;
  private stallNudges = 0;
  // Remembered selections so they survive track lists loading late / re-loads.
  private selectedTextId: number | null = null;
  private selectedAudioId: number | null = null;
  private textScale = 1;
  private cueStyle: HTMLStyleElement | null = null;
  // Custom external-subtitle overlay (reliable on TV browsers where native
  // <track> cue painting is hidden by the hardware video plane).
  private subOverlay: HTMLDivElement | null = null;
  private externalCues: { start: number; end: number; text: string }[] = [];

  attach(container: HTMLElement, events: PlayerEvents): void {
    this.container = container;
    this.events = events;
    const video = document.createElement("video");
    video.setAttribute("playsinline", "true");
    video.style.width = "100%";
    video.style.height = "100%";
    video.style.background = "#000";
    video.style.objectFit = "contain";
    video.autoplay = true;
    this.video = video;
    container.appendChild(video);

    this.bindVideoEvents();
    this.ensureCueStyle();
  }

  // Created lazily only when an external subtitle is actually selected, so the
  // normal playback path is untouched.
  private ensureOverlay(): void {
    if (this.subOverlay || !this.container) return;
    const overlay = document.createElement("div");
    overlay.setAttribute("data-sub-overlay", "1");
    overlay.style.cssText = [
      "position:absolute",
      "left:0",
      "right:0",
      "bottom:8%",
      "padding:0 6%",
      "text-align:center",
      "pointer-events:none",
      // Above the player's on-screen controls (which are a sibling of the video
      // container and would otherwise paint over the cues), below modals.
      "z-index:900",
      "display:none",
      "white-space:pre-line",
      "line-height:1.3",
      "font-weight:700",
      "color:#fff",
      "text-shadow:0 2px 4px rgba(0,0,0,0.95),0 0 6px rgba(0,0,0,0.9)",
    ].join(";");
    // Anchor to the positioned wrapper that also hosts the controls so the cues
    // can stack above them; fall back to the video container itself.
    const host = this.container.parentElement || this.container;
    if (getComputedStyle(host).position === "static") {
      host.style.position = "relative";
    }
    host.appendChild(overlay);
    this.subOverlay = overlay;
    this.applyOverlayScale();
  }

  private applyOverlayScale(): void {
    if (!this.subOverlay) return;
    this.subOverlay.style.fontSize = `${Math.round(28 * this.textScale)}px`;
  }

  private parseTs(s: string): number {
    const clean = s.trim().replace(",", ".");
    const parts = clean.split(":");
    let h = 0,
      m = 0,
      sec = 0;
    if (parts.length === 3) {
      h = parseInt(parts[0], 10) || 0;
      m = parseInt(parts[1], 10) || 0;
      sec = parseFloat(parts[2]) || 0;
    } else if (parts.length === 2) {
      m = parseInt(parts[0], 10) || 0;
      sec = parseFloat(parts[1]) || 0;
    }
    return h * 3600 + m * 60 + sec;
  }

  private parseVtt(text: string): { start: number; end: number; text: string }[] {
    const body = text.replace(/\r/g, "");
    const out: { start: number; end: number; text: string }[] = [];
    for (const block of body.split(/\n{2,}/)) {
      const lines = block.split("\n").filter((l) => l.trim() !== "");
      if (!lines.length) continue;
      const tIdx = lines.findIndex((l) => l.includes("-->"));
      if (tIdx < 0) continue;
      const m = lines[tIdx].match(
        /(\d{1,2}:\d{2}:\d{2}[.,]\d{1,3}|\d{1,2}:\d{2}[.,]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[.,]\d{1,3}|\d{1,2}:\d{2}[.,]\d{1,3})/,
      );
      if (!m) continue;
      const txt = lines
        .slice(tIdx + 1)
        .join("\n")
        .replace(/<[^>]+>/g, "")
        .trim();
      if (!txt) continue;
      out.push({ start: this.parseTs(m[1]), end: this.parseTs(m[2]), text: txt });
    }
    out.sort((a, b) => a.start - b.start);
    return out;
  }

  private renderActiveCue(): void {
    const o = this.subOverlay;
    if (!o) return;
    if (!this.externalCues.length) {
      o.style.display = "none";
      return;
    }
    const t = this.video?.currentTime || 0;
    let cue: { start: number; end: number; text: string } | undefined;
    for (const c of this.externalCues) {
      if (t >= c.start && t <= c.end) {
        cue = c;
        break;
      }
      if (c.start > t) break;
    }
    if (cue) {
      o.textContent = cue.text;
      o.style.display = "block";
    } else {
      o.textContent = "";
      o.style.display = "none";
    }
  }

  setExternalSubtitle(vtt: string, _label: string): void {
    // A custom overlay replaces native tracks: hide them to avoid duplicates.
    this.selectedTextId = null;
    this.applyTextSelection();
    if (this.hls && this.hls.subtitleTracks.length) this.hls.subtitleTrack = -1;
    this.ensureOverlay();
    this.externalCues = this.parseVtt(vtt);
    this.renderActiveCue();
  }

  getDiagnostics(): string {
    const v = this.video;
    if (!v) return "no-video";
    let buf = "0";
    try {
      if (v.buffered.length) buf = v.buffered.end(v.buffered.length - 1).toFixed(0);
    } catch {
      /* noop */
    }
    const err = v.error ? `ERR${v.error.code}` : "";
    return [
      this.mpegts ? "mpegts" : this.hls ? "hls" : "native",
      `net${v.networkState}`,
      `rdy${v.readyState}`,
      `t${(v.currentTime || 0).toFixed(0)}/${(v.duration || 0).toFixed(0)}`,
      `buf${buf}`,
      v.paused ? "paused" : "play",
      this.triedNative || this.triedMpegts ? "FB" : "",
      this.hasStarted ? "" : "nostart",
      `cue${this.externalCues.length}`,
      err,
      this.lastNote,
    ]
      .filter(Boolean)
      .join(" ");
  }

  clearExternalSubtitle(): void {
    this.externalCues = [];
    if (this.subOverlay) {
      this.subOverlay.textContent = "";
      this.subOverlay.style.display = "none";
    }
  }

  // Native (non-HLS VOD) playback exposes the container's embedded subtitle
  // tracks via video.textTracks. They can arrive after loadedmetadata, so we
  // re-assert the desired selection whenever the list changes and default to
  // "off" until the user picks one.
  private applyTextSelection(): void {
    const v = this.video;
    if (!v || this.hls) return;
    const tt = v.textTracks;
    for (let i = 0; i < tt.length; i++) {
      const want = this.selectedTextId != null && i === this.selectedTextId;
      try {
        tt[i].mode = want ? "showing" : "disabled";
      } catch {
        /* noop */
      }
    }
  }

  private ensureCueStyle(): void {
    if (this.cueStyle) return;
    const el = document.createElement("style");
    el.setAttribute("data-player-cue", "1");
    document.head.appendChild(el);
    this.cueStyle = el;
    this.writeCueStyle();
  }

  private writeCueStyle(): void {
    if (!this.cueStyle) return;
    const pct = Math.round(this.textScale * 100);
    // Best-effort: scale native cue text. Honored where the platform renders
    // WebVTT/embedded cues through the standard cue box (webOS Chromium).
    this.cueStyle.textContent =
      `video::cue{font-size:${pct}%;background:rgba(0,0,0,0.5);}`;
  }

  private bindVideoEvents() {
    const v = this.video!;
    v.addEventListener("loadedmetadata", () => {
      this.applyTextSelection();
      this.events.onReady?.();
    });
    // Embedded tracks can register after metadata; keep defaults/selection.
    try {
      v.textTracks.addEventListener?.("addtrack", () => this.applyTextSelection());
    } catch {
      /* older engines */
    }
    v.addEventListener("playing", () => {
      this.hasStarted = true;
      this.clearLoadWatchdog();
      this.startStallWatchdog();
      this.emit("playing");
    });
    v.addEventListener("pause", () => this.emit("paused"));
    v.addEventListener("waiting", () => this.emit("buffering"));
    v.addEventListener("ended", () => {
      this.emit("ended");
      this.events.onEnded?.();
    });
    v.addEventListener("timeupdate", () => {
      this.events.onTimeUpdate?.(v.currentTime || 0, v.duration || 0);
      this.renderActiveCue();
    });
    v.addEventListener("error", () => {
      // mpegts.js drives the element via MSE; let its own ERROR handler manage
      // recovery instead of double-triggering here.
      if (this.mpegts) return;
      // Native decode failed. If a fallback engine is still available (native
      // hardware decoder or mpegts.js software demuxer), try it before erroring.
      if (this.canFallback()) {
        this.runFallback();
        return;
      }
      const err = v.error;
      this.failStream(err ? `Media error ${err.code}` : "Unknown media error");
    });
  }

  private hasFallbackUrl(): boolean {
    const s = this.currentSource;
    return !!s && !!s.fallbackUrl && s.fallbackUrl !== s.url;
  }

  // Does this platform's <video> element natively decode MPEG-TS? True on most
  // TVs (webOS/Titan hardware pipeline), false on desktop Chrome/Firefox.
  private nativeTsSupported(): boolean {
    return !!this.video && this.video.canPlayType("video/mp2t") !== "";
  }

  // Is mpegts.js a viable engine here? It remuxes a raw MPEG-TS stream to fMP4
  // and feeds MSE, so it needs MSE support and an actual .ts URL to target
  // (it cannot play an .m3u8 playlist).
  private mpegtsUsable(): boolean {
    return mpegts.isSupported() && !!this.tsUrl();
  }

  // Any untried fallback engine remaining for the current source?
  private canFallback(): boolean {
    if (!this.hasFallbackUrl()) return false;
    if (!this.triedNative) return true;
    if (!this.triedMpegts && this.mpegtsUsable()) return true;
    return false;
  }

  // Pick the next fallback engine. On desktop Chromium (no native TS) we prefer
  // the mpegts.js software demuxer; on TVs we prefer the native hardware
  // decoder (HEVC/AC3/EAC3) and only use mpegts.js as a last resort.
  private runFallback(): void {
    if (!this.hasFallbackUrl()) {
      this.events.onError?.("no fallback available", true);
      this.emit("error");
      return;
    }
    const preferMpegts =
      this.mpegtsUsable() && !this.triedMpegts && !this.nativeTsSupported();
    if (preferMpegts) {
      this.mpegtsFallback();
      return;
    }
    if (!this.triedNative) {
      this.nativeFallback();
      return;
    }
    if (!this.triedMpegts && this.mpegtsUsable()) {
      this.mpegtsFallback();
      return;
    }
    this.failStream("all fallbacks exhausted");
  }

  // Bypass hls.js/MSE and hand the stream straight to the webOS/native media
  // pipeline, which decodes HEVC/AC3/EAC3 in hardware on most TVs.
  private nativeFallback(): void {
    if (!this.currentSource || !this.video) return;
    this.triedNative = true;
    this.teardownHls();
    this.teardownMpegts();
    const v = this.video;
    // Prefer the raw .ts on the native hardware decoder (TVs decode TS/HEVC/AC3
    // there); otherwise use the alternate/primary URL.
    const url = this.tsUrl() || this.currentSource.fallbackUrl || this.currentSource.url;
    this.emit("loading");
    try {
      v.src = url;
      v.load();
      v.play().catch(() => {});
    } catch {
      // Native failed to even start — try mpegts.js if we haven't yet.
      if (!this.triedMpegts && this.mpegtsUsable()) {
        this.mpegtsFallback();
        return;
      }
      this.failStream("native fallback failed");
    }
  }

  // Software MPEG-TS playback via mpegts.js (MSE). Enables raw .ts live streams
  // to play in desktop Chromium and as an extra safety net on Titan.
  private mpegtsFallback(): void {
    if (!this.currentSource || !this.video) return;
    this.triedMpegts = true;
    this.teardownHls();
    this.teardownMpegts();
    const v = this.video;
    // mpegts.js must be pointed at the raw .ts endpoint, never an .m3u8.
    const url = this.tsUrl() || this.currentSource.fallbackUrl || this.currentSource.url;
    const isLive = this.currentSource.kind === "live";
    this.emit("loading");
    try {
      const player = mpegts.createPlayer(
        { type: "mpegts", isLive, url },
        {
          // Run the demuxer on the main thread. The Web Worker build (spawned
          // from a Blob URL) throws "… is not a constructor" under Vite's dev
          // bundling, which silently kills playback; main-thread mode is robust.
          enableWorker: false,
          // Latency-chasing makes the player seek to the live edge whenever
          // latency grows. Through our proxy that extra latency triggers constant
          // forward seeks → the buffer drains → periodic spinner. Disable it and
          // just play smoothly a few seconds behind the edge instead.
          liveBufferLatencyChasing: false,
          liveBufferLatencyChasingOnPaused: false,
          // Bigger IO stash so brief network/proxy dips don't starve the demuxer.
          stashInitialSize: 1024 * 512, // 512 KB
          lazyLoad: false,
          // IPTV TS streams often have PTS jumps; keep playing through them.
          fixAudioTimestampGap: true,
          reuseRedirectedURL: true,
          // Trim the back-buffer on long live sessions so memory growth doesn't
          // eventually cause GC hitches / stalls.
          autoCleanupSourceBuffer: true,
          autoCleanupMaxBackwardDuration: 30,
          autoCleanupMinBackwardDuration: 15,
        }
      );
      player.attachMediaElement(v);
      player.on(
        mpegts.Events.ERROR,
        (type: string, detail: string, info: unknown) => {
          this.lastNote = `mpegtsErr:${type}/${detail}`;
          if (import.meta.env.DEV) {
            // eslint-disable-next-line no-console
            console.warn("[mpegts]", type, detail, info);
          }
          this.teardownMpegts();
          // mpegts.js couldn't decode (e.g. HEVC/AC3) → try native if untried.
          if (!this.triedNative) {
            this.nativeFallback();
            return;
          }
          this.failStream("mpegts.js error");
        }
      );
      if (import.meta.env.DEV) {
        player.on(mpegts.Events.MEDIA_INFO, (mi: unknown) => {
          // eslint-disable-next-line no-console
          console.log("[mpegts] media info", mi);
        });
      }
      player.load();
      this.mpegts = player;
      v.play().catch(() => {});
    } catch {
      this.teardownMpegts();
      if (!this.triedNative) {
        this.nativeFallback();
        return;
      }
      this.failStream("mpegts fallback failed");
    }
  }

  private emit(s: PlayerState) {
    this.events.onStateChange?.(s);
  }

  private clearLoadWatchdog() {
    if (this.loadTimer) {
      clearTimeout(this.loadTimer);
      this.loadTimer = null;
    }
  }

  private clearStallWatchdog() {
    if (this.stallTimer) {
      clearInterval(this.stallTimer);
      this.stallTimer = null;
    }
  }

  // Polls playback progress. When the picture freezes (currentTime stuck while
  // the element thinks it's playing) we try escalating recoveries: nudge the
  // clock, re-issue play, then restart the hls load. Common on webOS where the
  // HW decoder occasionally wedges on IPTV TS discontinuities.
  private startStallWatchdog() {
    this.clearStallWatchdog();
    this.lastProgressTime = this.video?.currentTime || 0;
    this.lastProgressAt = Date.now();
    this.stallNudges = 0;
    this.stallTimer = window.setInterval(() => {
      const v = this.video;
      if (!v) return;
      if (v.paused || v.ended || v.seeking) {
        this.lastProgressAt = Date.now();
        return;
      }
      const now = Date.now();
      const ct = v.currentTime || 0;
      if (Math.abs(ct - this.lastProgressTime) > 0.05) {
        // Progressing normally.
        this.lastProgressTime = ct;
        this.lastProgressAt = now;
        this.stallNudges = 0;
        return;
      }
      const stalledMs = now - this.lastProgressAt;
      if (stalledMs < 3500) return; // still within normal buffering window

      // How much buffered data is ahead of the playhead?
      let ahead = 0;
      try {
        for (let i = 0; i < v.buffered.length; i++) {
          if (ct >= v.buffered.start(i) - 0.5 && ct <= v.buffered.end(i) + 0.5) {
            ahead = v.buffered.end(i) - ct;
            break;
          }
        }
      } catch {
        /* noop */
      }

      this.stallNudges += 1;
      const isLive = this.currentSource?.kind === "live";
      const nativeVod = !this.hls && !isLive;
      if (ahead > 0.5 && this.stallNudges <= 3) {
        // Decoder wedged but data is buffered → nudge the clock forward.
        try {
          v.currentTime = ct + 0.2;
          v.play().catch(() => {});
        } catch {
          /* noop */
        }
      } else if (this.hls && this.stallNudges <= 4) {
        // Buffer drained or nudging failed → restart the hls fetch loop.
        try {
          this.hls.startLoad();
          v.play().catch(() => {});
        } catch {
          /* noop */
        }
      } else if (nativeVod && this.stallNudges < 8) {
        // Progressive VOD (movie/episode) served through the proxy: a drained
        // buffer just means the network/proxy is momentarily slow. The <video>
        // element re-buffers and resumes on its own, so stay patient and keep
        // trying to resume rather than tearing everything down — a full reload
        // here would restart the fetch AND jump back to the original resume
        // point, which is exactly the stutter/rewind the user was seeing.
        try {
          v.play().catch(() => {});
        } catch {
          /* noop */
        }
      } else if (this.canFallback()) {
        // hls/MSE can't keep up → hand off to another decoding engine.
        this.runFallback();
        this.stallNudges = 0;
      } else if (this.currentSource) {
        // Last resort: reload — but resume from the CURRENT position instead of
        // the original start so VOD doesn't jump backwards.
        const pos = v.currentTime || 0;
        this.stallNudges = 0;
        this.load({ ...this.currentSource, startPositionSec: pos });
      }
      this.lastProgressAt = now;
    }, 1000);
  }

  private isProgressing(): boolean {
    const v = this.video;
    if (!v) return false;
    if (v.readyState >= 2) return true; // HAVE_CURRENT_DATA or better
    try {
      if (v.buffered.length && v.buffered.end(v.buffered.length - 1) > 0) return true;
    } catch {
      /* noop */
    }
    return false;
  }

  private armLoadWatchdog(ms: number) {
    this.clearLoadWatchdog();
    this.loadTimer = window.setTimeout(() => {
      this.loadTimer = null;
      if (this.hasStarted) return;
      // Still receiving/decoding data → give it more time rather than killing a
      // slow-but-valid load.
      if (this.isProgressing()) {
        this.armLoadWatchdog(ms);
        return;
      }
      // Truly stuck: try the next fallback engine once, else surface an error
      // so the UI leaves the infinite "loading" spinner.
      if (this.canFallback()) {
        this.runFallback();
        this.armLoadWatchdog(ms);
        return;
      }
      // Direct attempt never produced a frame → retry via the proxy before
      // giving up (common when a panel blocks our datacenter IP but the direct
      // route also can't start, e.g. no CORS).
      this.failStream("load timeout");
    }, ms);
  }

  private isHlsUrl(source: PlayerSource): boolean {
    if (source.format === "hls") return true;
    const u = source.url.toLowerCase();
    if (u.includes(".m3u8")) return true;
    // A raw MPEG-TS stream (…/live/user/pass/id.ts) is NOT an HLS playlist:
    // routing it through hls.js fails (it can't parse a continuous TS as a
    // manifest). It must go to the native decoder (TV) or mpegts.js (desktop).
    if (u.includes(".ts")) return false;
    // Extension-less live URLs: assume HLS-style.
    return source.kind === "live";
  }

  // The playlist (HLS) URL among url/fallbackUrl, if any — used by hls.js.
  private m3u8Url(): string | undefined {
    const s = this.currentSource;
    if (!s) return undefined;
    if (s.url.toLowerCase().includes(".m3u8")) return s.url;
    if (s.fallbackUrl?.toLowerCase().includes(".m3u8")) return s.fallbackUrl;
    return undefined;
  }

  // The raw MPEG-TS URL among url/fallbackUrl, if any — used by mpegts.js and
  // preferred by the native decoder on TVs.
  private tsUrl(): string | undefined {
    const s = this.currentSource;
    if (!s) return undefined;
    if (s.url.toLowerCase().includes(".ts")) return s.url;
    if (s.fallbackUrl?.toLowerCase().includes(".ts")) return s.fallbackUrl;
    return undefined;
  }

  // Upgrade http→https so an https page can load the stream directly (no mixed
  // content). Cloudflare-fronted panels send `Access-Control-Allow-Origin: *`
  // and only block our datacenter proxy IP, so hitting them straight from the
  // viewer's own IP succeeds where the proxy gets a 456. VOD via native <video>
  // needs no CORS at all. If the direct attempt fails we fall back to the proxy.
  private directify(source: PlayerSource): PlayerSource {
    const up = (u?: string): string | undefined =>
      u ? u.replace(/^http:\/\//i, "https://") : u;
    return { ...source, url: up(source.url) as string, fallbackUrl: up(source.fallbackUrl) };
  }

  async load(source: PlayerSource): Promise<void> {
    // Remember the untouched source so we can retry via the proxy if the direct
    // attempt (below) can't reach the provider from the viewer's browser.
    this.rawSource = source;
    this.usingProxy = false;
    return this.loadResolved(this.directify(source));
  }

  // Reload the current stream through the same-origin proxy after a direct
  // attempt failed. Returns false when there's nothing left to try (already
  // proxying, or no remembered source), so callers can surface a real error.
  private switchToProxyAndReload(): boolean {
    if (!this.rawSource || this.usingProxy) return false;
    this.usingProxy = true;
    this.lastNote = "direct→proxy";
    void this.loadResolved(proxifySource(this.rawSource));
    return true;
  }

  // Terminal failure for a stream: try the proxy fallback first, and only report
  // an error to the UI once even that path is exhausted.
  private failStream(msg: string): void {
    if (this.switchToProxyAndReload()) return;
    this.events.onError?.(msg, true);
    this.emit("error");
  }

  private async loadResolved(source: PlayerSource): Promise<void> {
    // A pending load/retry can fire after the player was disposed on navigation
    // (dispose() nulls the video). Bail quietly instead of throwing on a null.
    const v = this.video;
    if (!v) return;
    this.emit("loading");
    this.teardownHls();
    this.teardownMpegts();
    this.clearStallWatchdog();
    this.currentSource = source;
    this.triedNative = false;
    this.triedMpegts = false;
    this.mediaRecoverCount = 0;
    this.hlsNetRetry = 0;
    this.lastNote = "";
    this.hasStarted = false;
    this.armLoadWatchdog(source.kind === "live" ? 25000 : 30000);

    const useHls = this.isHlsUrl(source);
    const canNativeHls = v.canPlayType("application/vnd.apple.mpegurl") !== "";

    // Raw MPEG-TS on a browser that can't decode TS natively (desktop Chrome/
    // Firefox): go straight to the mpegts.js software demuxer instead of a doomed
    // native <video> attempt that only errors out (or worse, hangs buffering) and
    // wastes the load watchdog. TVs (native TS via HW) skip this and use native.
    if (!useHls && this.tsUrl() && !this.nativeTsSupported() && this.mpegtsUsable()) {
      this.mpegtsFallback();
      return;
    }

    if (useHls && Hls.isSupported() && !canNativeHls) {
      const isLive = source.kind === "live";
      const hls = new Hls({
        lowLatencyMode: false,
        // MV3 extension pages block Blob-URL workers under the default CSP, so
        // run hls.js on the main thread there; the website keeps the worker.
        enableWorker: !IS_EXT,
        backBufferLength: isLive ? 30 : 90,
        // Build a deeper forward buffer so brief network dips / provider
        // hiccups don't immediately drain playback and cause a freeze.
        maxBufferLength: isLive ? 40 : 60,
        maxMaxBufferLength: isLive ? 90 : 120,
        maxBufferSize: 120 * 1000 * 1000, // 120 MB
        // Stall tolerance: skip small gaps in the TS timeline and nudge the
        // currentTime more aggressively instead of stalling forever. IPTV
        // streams frequently contain tiny discontinuities/gaps.
        maxBufferHole: 0.5,
        highBufferWatchdogPeriod: 1,
        nudgeOffset: 0.2,
        nudgeMaxRetry: 8,
        maxFragLookUpTolerance: 0.25,
        // For live, keep a few segments of safety margin behind the live edge
        // so we're not constantly racing the encoder (a common stutter cause).
        liveSyncDurationCount: 4,
        liveMaxLatencyDurationCount: 12,
        // Retry transient segment/manifest load failures rather than erroring.
        manifestLoadingTimeOut: 20000,
        manifestLoadingMaxRetry: 4,
        fragLoadingTimeOut: 30000,
        fragLoadingMaxRetry: 6,
      });
      this.hls = hls;
      hls.loadSource(this.m3u8Url() || source.url);
      hls.attachMedia(v);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        if (source.startPositionSec) v.currentTime = source.startPositionSec;
        v.play().catch(() => {});
      });
      hls.on(Hls.Events.ERROR, (_e, data) => {
        if (!data.fatal) return;
        switch (data.type) {
          case Hls.ErrorTypes.NETWORK_ERROR: {
            // Auth/anti-hotlink rejections (401/403) or 404 on the manifest or
            // segments will never succeed by retrying — many IPTV panels block
            // browser-origin /hls/ segment fetches. Fall back to the raw .ts
            // (native decoder on TV, mpegts.js on desktop) right away.
            const code = (data.response as { code?: number } | undefined)?.code;
            const hardFail = code === 401 || code === 403 || code === 404;
            if ((hardFail || this.hlsNetRetry >= 2) && this.canFallback()) {
              this.lastNote = `hlsNet${code ?? ""}→fb`;
              this.runFallback();
              break;
            }
            this.hlsNetRetry += 1;
            hls.startLoad();
            break;
          }
          case Hls.ErrorTypes.MEDIA_ERROR:
            // A media/codec error usually means MSE can't decode this codec
            // (e.g. HEVC). Try to recover once, otherwise hand off to the
            // native hardware decoder.
            if (this.mediaRecoverCount < 1) {
              this.mediaRecoverCount += 1;
              hls.recoverMediaError();
            } else if (this.canFallback()) {
              this.runFallback();
            } else {
              this.failStream(data.details || "media error");
            }
            break;
          default:
            // Includes manifest/codec-incompatible errors (e.g. an .m3u8 that
            // 302-redirects to a raw TS stream) → hand off to a fallback engine.
            if (this.canFallback()) {
              this.runFallback();
            } else {
              this.failStream(data.details || "fatal hls error");
            }
            break;
        }
      });
    } else {
      // Native decoder path (VOD MP4, or a raw .ts on a TV that decodes TS).
      // This *is* the native attempt, so mark it tried — if it fails on a
      // desktop browser (which can't decode TS), the error handler escalates
      // straight to mpegts.js rather than pointlessly retrying native.
      this.triedNative = true;
      v.src = source.url;
      v.load();
      if (source.startPositionSec) {
        const onMeta = () => {
          v.currentTime = source.startPositionSec || 0;
          v.removeEventListener("loadedmetadata", onMeta);
        };
        v.addEventListener("loadedmetadata", onMeta);
      }
      v.play().catch(() => {});
    }
  }

  private teardownHls() {
    if (this.hls) {
      this.hls.destroy();
      this.hls = null;
    }
  }

  private teardownMpegts() {
    if (this.mpegts) {
      try {
        this.mpegts.destroy();
      } catch {
        /* noop */
      }
      this.mpegts = null;
    }
  }

  play(): void {
    this.video?.play().catch(() => {});
  }
  pause(): void {
    this.video?.pause();
  }
  togglePlay(): void {
    if (!this.video) return;
    if (this.video.paused) this.play();
    else this.pause();
  }
  seekTo(sec: number): void {
    if (this.video) this.video.currentTime = Math.max(0, sec);
  }
  seekBy(deltaSec: number): void {
    if (this.video)
      this.video.currentTime = Math.max(0, this.video.currentTime + deltaSec);
  }
  getCurrentTime(): number {
    return this.video?.currentTime || 0;
  }
  getDuration(): number {
    return this.video?.duration || 0;
  }
  setVolume(vol: number): void {
    if (this.video) this.video.volume = Math.max(0, Math.min(1, vol));
  }
  setMuted(muted: boolean): void {
    if (this.video) this.video.muted = muted;
  }
  captureFrame(): string | null {
    const v = this.video;
    if (!v || !v.videoWidth || !v.videoHeight) return null;
    try {
      const c = document.createElement("canvas");
      c.width = v.videoWidth;
      c.height = v.videoHeight;
      const ctx = c.getContext("2d");
      if (!ctx) return null;
      ctx.drawImage(v, 0, 0, c.width, c.height);
      return c.toDataURL("image/jpeg", 0.7);
    } catch {
      // Cross-origin frame (e.g. native .ts fallback) taints the canvas.
      return null;
    }
  }

  getAudioTracks(): PlayerTrack[] {
    if (this.hls && this.hls.audioTracks.length) {
      return this.hls.audioTracks.map((t, i) => ({
        id: i,
        language: t.lang,
        label: t.name,
      }));
    }
    // Native (VOD) path: embedded audio streams demuxed by the platform.
    const list = (this.video as any)?.audioTracks as
      | { length: number; [i: number]: any }
      | undefined;
    if (list && list.length) {
      const out: PlayerTrack[] = [];
      for (let i = 0; i < list.length; i++) {
        const t = list[i];
        out.push({ id: i, language: t.language, label: t.label });
      }
      return out;
    }
    return [];
  }
  setAudioTrack(id: number): void {
    this.selectedAudioId = id;
    if (this.hls && this.hls.audioTracks.length) {
      this.hls.audioTrack = id;
      return;
    }
    const list = (this.video as any)?.audioTracks as
      | { length: number; [i: number]: any }
      | undefined;
    if (list) {
      for (let i = 0; i < list.length; i++) list[i].enabled = i === id;
    }
  }
  getTextTracks(): PlayerTrack[] {
    if (this.hls && this.hls.subtitleTracks.length) {
      return this.hls.subtitleTracks.map((t, i) => ({
        id: i,
        language: t.lang,
        label: t.name,
      }));
    }
    // Native (VOD) path: embedded subtitle/caption tracks.
    const v = this.video;
    if (!v) return [];
    const tt = v.textTracks;
    const out: PlayerTrack[] = [];
    for (let i = 0; i < tt.length; i++) {
      const t = tt[i];
      if (t.kind && t.kind !== "subtitles" && t.kind !== "captions") continue;
      out.push({ id: i, language: t.language, label: t.label });
    }
    return out;
  }
  setTextTrack(id: number | null): void {
    this.selectedTextId = id;
    if (this.hls && this.hls.subtitleTracks.length) {
      this.hls.subtitleTrack = id == null ? -1 : id;
      return;
    }
    this.applyTextSelection();
  }

  getActiveAudioTrack(): number | null {
    if (this.hls && this.hls.audioTracks.length) return this.hls.audioTrack;
    return this.selectedAudioId;
  }
  getActiveTextTrack(): number | null {
    if (this.hls && this.hls.subtitleTracks.length) {
      return this.hls.subtitleTrack < 0 ? null : this.hls.subtitleTrack;
    }
    return this.selectedTextId;
  }
  setTextScale(scale: number): void {
    this.textScale = scale;
    this.writeCueStyle();
    this.applyOverlayScale();
  }

  // Attach an external WebVTT subtitle (served as a blob: URL) and show it.
  // The browser registers it in video.textTracks, so it also appears in the
  // regular subtitle list afterwards.
  addExternalSubtitle(url: string, lang: string, label: string): number | null {
    const v = this.video;
    if (!v) return null;
    const track = document.createElement("track");
    track.kind = "subtitles";
    track.label = label;
    track.srclang = lang || "und";
    track.src = url;
    v.appendChild(track);

    const apply = () => {
      const tt = v.textTracks;
      for (let i = 0; i < tt.length; i++) {
        if (tt[i] === track.track) {
          tt[i].mode = "showing";
          this.selectedTextId = i;
        } else {
          tt[i].mode = "disabled";
        }
      }
    };
    track.addEventListener("load", apply);
    // track.track is available synchronously; apply after a tick so the new
    // track is registered in the TextTrackList.
    window.setTimeout(apply, 60);
    return this.selectedTextId;
  }

  destroy(): void {
    this.clearLoadWatchdog();
    this.clearStallWatchdog();
    this.teardownHls();
    this.teardownMpegts();
    if (this.subOverlay && this.subOverlay.parentNode) {
      this.subOverlay.parentNode.removeChild(this.subOverlay);
      this.subOverlay = null;
    }
    this.externalCues = [];
    if (this.cueStyle && this.cueStyle.parentNode) {
      this.cueStyle.parentNode.removeChild(this.cueStyle);
      this.cueStyle = null;
    }
    if (this.video) {
      try {
        this.video.pause();
        this.video.removeAttribute("src");
        this.video.src = "";
        this.video.load();
      } catch {
        /* noop */
      }
      if (this.container && this.video.parentNode === this.container) {
        this.container.removeChild(this.video);
      }
      this.video = null;
    }
  }
}
