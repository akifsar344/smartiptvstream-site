import { useEffect, useState } from "react";

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

// Time-of-day string honoring the user's 12/24-hour preference.
export function formatClock(d: Date, hour24 = true): string {
  const mm = d.getMinutes().toString().padStart(2, "0");
  if (hour24) {
    return `${d.getHours().toString().padStart(2, "0")}:${mm}`;
  }
  const ampm = d.getHours() >= 12 ? "PM" : "AM";
  const h12 = ((d.getHours() + 11) % 12) + 1;
  return `${h12.toString().padStart(2, "0")}:${mm} ${ampm}`;
}

export function formatHeaderDate(d: Date, hour24 = true): string {
  const time = formatClock(d, hour24);
  return `${time} ${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

export function useClock(): Date {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return now;
}

// Xtream exp_date is a unix timestamp (seconds) as string. Returns readable date.
export function formatExpiry(expDate: string): string {
  if (!expDate) return "Unlimited";
  const ts = parseInt(expDate, 10);
  if (Number.isNaN(ts)) return expDate;
  const d = new Date(ts * 1000);
  return `${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

export function expiryDaysLeft(expDate: string): number | null {
  const ts = parseInt(expDate, 10);
  if (Number.isNaN(ts)) return null;
  const expiry = new Date(ts * 1000);
  return Math.floor((expiry.getTime() - Date.now()) / 86400000);
}

export function formatDuration(sec: number): string {
  if (!sec || sec <= 0) return "00:00";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const mm = m.toString().padStart(2, "0");
  const ss = s.toString().padStart(2, "0");
  return h > 0 ? `${h}:${mm}:${ss}` : `${mm}:${ss}`;
}
