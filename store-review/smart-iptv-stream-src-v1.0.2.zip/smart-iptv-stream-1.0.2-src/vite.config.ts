import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// webOS & Tizen load the packaged app from the local filesystem, so they MUST
// use relative asset paths (base: "./"). The browser build for
// smartiptvstream.com is served at the "/app" sub-path, so it needs absolute
// asset URLs (base: "/") to resolve regardless of path depth. The WEB_BUILD env
// flag (set only by `npm run build:web`) opts into the browser base; the default
// build used by the webOS/Tizen packaging pipeline is left untouched.
const isWebBuild = process.env.WEB_BUILD === "1";
// The browser-extension build (EXT_BUILD=1) is loaded from chrome-extension://
// pages, so it uses relative asset paths (base "./") like the TV build, but it
// talks to the live smartiptvstream.com backend and unlocks direct streaming via
// the extension's host permissions. VITE_EXT gates the extension-only code paths.
const isExtBuild = process.env.EXT_BUILD === "1";
const SITE_URL = process.env.VITE_SITE_URL || "https://smartiptvstream.com/app";
const API_BASE = process.env.VITE_API_BASE || "https://smartiptvstream.com";

export default defineConfig({
  base: isWebBuild ? "/" : "./",
  plugins: [react()],
  define: isExtBuild
    ? {
        "import.meta.env.VITE_EXT": JSON.stringify("1"),
        "import.meta.env.VITE_API_BASE": JSON.stringify(API_BASE),
        "import.meta.env.VITE_SITE_URL": JSON.stringify(SITE_URL),
      }
    : {},
  build: {
    outDir: isExtBuild ? "dist-ext" : "dist",
    target: "es2015",
    cssTarget: "chrome50",
    chunkSizeWarningLimit: 2000,
  },
  server: {
    host: true,
    port: 5173,
  },
});
